# @coreds/ui

Shared React UI component library + design system tokens cho tất cả các frontend projects trong team.

## 📦 Cài đặt

Không cần token. Thêm một dòng vào `.npmrc` ở gốc app (commit cùng code, file không chứa bí mật) rồi cài:

```ini
@coreds:registry=https://gitlab.ikameglobal.com/api/v4/projects/2163/packages/npm/
```

```bash
npm install @coreds/ui
```

Muốn có cả UI và icon trong một gói thì cài `@coreds/react`.

**Peer dependencies:** React 18 hoặc React 19

## 🚀 Quick Start

### 1. Import CSS (bắt buộc)

Import một lần duy nhất trong entry file của app (`main.tsx`, `_app.tsx`, `layout.tsx`):

```tsx
import "@coreds/ui/style.css";
```

### 2. Thêm provider vào root app

```tsx
import { Toaster, TooltipProvider } from "@coreds/ui";

function App() {
  return (
    <TooltipProvider>
      {/* rest of app */}
      <Toaster />
    </TooltipProvider>
  );
}
```

`TooltipProvider` cần thiết khi dùng `Tooltip`; `Toaster` cần thiết khi gọi `toast()`.

### 3. Sử dụng components

```tsx
import { Button, Input, Badge, Modal, Select, toast } from "@coreds/ui";
```

### 4. Dark mode

Thêm class `.dark` vào root element để enable dark mode:

```tsx
<html className="dark">...</html>
```

Hoặc dùng hook đi kèm:

```tsx
import { useDarkMode } from "@coreds/ui";

function ThemeToggle() {
  const { isDark, toggle } = useDarkMode();
  return <button onClick={toggle}>{isDark ? "Light" : "Dark"}</button>;
}
```

---

## 🧩 Components

| Component | Mô tả |
|-----------|-------|
| `Button`, `Badge`, `Chip`, `Avatar`, `Spinner` | Core display/action primitives |
| `Input`, `InputPinCode`, `Textarea`, `Select`, `FileUpload` | Form inputs |
| `Checkbox`, `RadioGroup`, `Switch`, `SegmentedControl`, `Slider` | Form controls |
| `Modal`, `Drawer`, `Tooltip`, `Popover`, `DropdownMenu` | Overlay primitives |
| `Tabs`, `Card`, `Accordion`, `ScrollArea`, `VirtualList` | Layout/content primitives |
| `Breadcrumb`, `Pagination`, `Steps`, `Sidebar`, `SimpleSidebar` | Navigation primitives |
| `Alert`, `Progress`, `Skeleton`, `Toaster` / `toast` | Feedback primitives |
| `Calendar`, `DatePicker`, `DateRangePicker`, `DataTable` | Data/date components |

---

## 🎨 Design Tokens

Sử dụng các CSS class được generate từ design system để style element bất kỳ:

```tsx
<div className="bg_primary border_secondary border radius_8 shadow_m p-4">
  <h2 className="text_primary font-bold">Heading</h2>
  <p className="text_tertiary">Description</p>
</div>
```

### Backgrounds
```
bg_primary · bg_secondary · bg_tertiary · bg_quaternary
bg_canvas_primary · bg_canvas_secondary · bg_canvas_tertiary · bg_canvas_quaternary
bg_interactive_primary · bg_interactive_secondary · bg_interactive_tertiary
bg_overlay · bg_inverse · bg_backdrop
bg_button_primary · bg_button_secondary · bg_button_tertiary
bg_input_fill · bg_input_fill_dim · bg_input_light
bg_accent_primary · bg_accent_primary_subtle · bg_accent_secondary · bg_accent_secondary_subtle
bg_success · bg_success_contrast · bg_error · bg_error_contrast
bg_warning · bg_warning_contrast · bg_info · bg_info_contrast
```

### Extended Color Palette (19 hues)

Hues: `orange` · `amber` · `yellow` · `lime` · `green` · `emerald` · `teal` · `cyan` · `sky` · `blue` · `indigo` · `violet` · `purple` · `fuchsia` · `pink` · `red` · `slate` · `gray` · `zinc`

| Pattern | CSS property | Ví dụ |
|---------|-------------|-------|
| `bg_{hue}_subtle` | background-color | `bg_blue_subtle` — nền nhạt cho tag, badge |
| `bg_{hue}_medium` | background-color | `bg_green_medium` — nền đậm hơn cho chart, progress |
| `fg_{hue}_strong` | color | `fg_red_strong` — text/icon đậm trên nền subtle |
| `fg_{hue}_accent` | color | `fg_blue_accent` — text/icon mid-tone cho link, icon |
| `border_{hue}` | border-color | `border_indigo` — viền theo hue |

```tsx
{/* Tag xanh lá */}
<span className="bg_green_subtle fg_green_strong border border_green radius_6 px-2 py-0.5 text-xs">
  Active
</span>

{/* Badge tím */}
<span className="bg_violet_subtle fg_violet_strong border border_violet radius_round px-2 py-0.5 text-xs">
  Beta
</span>
```

### Text & Icon
```
text_primary · text_secondary · text_tertiary · text_contrast
text_inverse_primary · text_inverse_secondary
icon_primary · icon_secondary · icon_tertiary
fg_accent_primary · fg_accent_secondary · fg_on_accent · fg_on_contrast
fg_link · fg_success · fg_error · fg_warning · fg_info
light_fixed · dim_fixed
```

### Border & Radius
```
border_primary · border_secondary · border_tertiary · border_contrast
border_input · border_input_opacity · border_button · border_dim_button
border_secondary_button · border_error_button
border_accent_primary · border_accent_primary_contrast
border_accent_secondary · border_accent_secondary_contrast
border_success · border_error
radius_2 · radius_4 · radius_6 · radius_8 · radius_12 · radius_16 · radius_24 · radius_round
```

### Shadows & Effects
```
shadow_xxs · shadow_xs · shadow_m · shadow_l · shadow_xl · shadow_xxl
backdrop_blur · outline_blue_focus · outline_orange_focus
```

### Interactive States (hover/active)
```tsx
<button className="bg_button_tertiary hover:state_bg_button_tertiary_soft active:state_bg_button_tertiary_medium">
  Hover me
</button>
```

Pattern: `hover:state_bg_{token}_{subtle|soft|medium|strong}`

### CSS Variables

Dùng trong inline styles hoặc custom CSS:

```tsx
style={{ backgroundColor: "var(--ds-bg-primary)", borderRadius: "var(--ds-radius-8)" }}
```

### TypeScript Token Map

`src/token-map.ts` là artifact nội bộ dùng khi phát triển package và hiện không được export
trong public package API. Ứng dụng consumer sử dụng token qua CSS classes hoặc CSS variables ở trên.

---

## 🛠️ Development Scripts

```bash
npm run dev              # Khởi động docs site dev server
npm run build            # TypeScript check + Vite build
npm run docs:generate    # Đồng bộ markdown component public + metadata docs site
npm run build:docs       # Đồng bộ docs rồi build docs site
npm run tokens           # Regenerate CSS từ design-tokens.json
npm run test             # Chạy tất cả tests
npm run test:watch       # Test ở watch mode
npm run test:coverage    # Test với báo cáo coverage
npm run type-check       # TypeScript check only
npm run lint             # ESLint
```

---

## 🔄 Quy trình khi Designer cập nhật token

1. Designer export file `design-tokens.json` mới từ Figma
2. Replace file cũ tại root repo: `design-tokens.json`
3. Chạy `npm run tokens` để regenerate CSS và token map
4. Kiểm tra trong docs site: `npm run dev`
5. Commit thay đổi (gồm `src/styles/theme.css`, `src/styles/utilities.css`, `src/token-map.ts`)
6. Publish theo quy trình bên dưới

---

## 🚢 Phát hành

Phát hành dùng Changesets ở gốc monorepo. Xem `README.md` ở gốc repo.

## 📁 Cấu trúc dự án

```
ui-kit/
├── src/
│   ├── index.ts              # Public exports
│   ├── style.css             # CSS entry point cho consumers
│   ├── components/ui/        # Tất cả components
│   ├── component-docs/       # Nguồn chuẩn cho từng trang component
│   ├── docs-site/             # Ứng dụng documentation
│   ├── hooks/                # Custom hooks (useDarkMode)
│   ├── lib/                  # Utilities (cn, toast)
│   ├── styles/
│   │   ├── theme.css         # [Auto-generated] CSS variables
│   │   └── utilities.css     # [Auto-generated] Utility classes
│   └── token-map.ts          # [Auto-generated] TypeScript token map
├── scripts/
│   ├── build-tokens.js       # Token generation script
│   └── gen_docs_assets.cjs   # Đồng bộ component docs + metadata site
├── design-tokens.json        # Source of truth từ Figma
├── state-mix.config.json     # Config cho state utility classes
└── TODO.md                   # Backlog kỹ thuật + cần phối hợp designer
```

## 📝 Thêm Component Mới

1. Tạo file trong `src/components/ui/`:
   - `{name}.tsx` — component + props interface
   - `{name}-variants.ts` — CVA variant definitions
   - `{name}.test.tsx` — Vitest + RTL tests
2. Dùng `cn()` từ `@/lib/utils` để merge classes
3. Dùng `cva()` cho variants — không hardcode colors/spacing, dùng token classes
4. Export từ `src/index.ts`
5. Thêm tài liệu vào `src/component-docs/{name}.md` và demo vào `src/docs-site/demos/`
6. Đăng ký trang/demo trên docs site và chạy `npm run docs:generate`

## 📄 License

MIT

## 🔗 Links

- **GitLab Registry:** `https://gitlab.ikameglobal.com/api/v4/projects/1311/packages/npm/`
- **Version History:** Xem `CHANGELOG.md` hoặc git tags

---

## ⚠️ Radix phải chỉ có một bản

ui-kit import mọi primitive từ gói tổng `radix-ui`, không bao giờ từ `@radix-ui/*` lẻ. Giữ nguyên nếp đó trong app.

Radix ghim phiên bản chính xác chứ không dùng dải `^`, nên chỉ cần một specifier thứ hai là npm cài thêm một bản `react-dismissable-layer`. Khi đó Dialog và Popover nằm ở hai layer context khác nhau: popover mở trong modal không được coi là lồng nhau, focus bị kéo về nên nó tự đóng, và `pointer-events` có thể kẹt trên `body` sau khi đóng modal. Lỗi chỉ xuất hiện trên một số máy vì bản nào thắng phụ thuộc thứ tự cài.

`@coreds/tiptap` hiện ghim `@radix-ui/react-dismissable-layer` 1.1.11 trong khi `radix-ui` resolve 1.1.15. App dùng cả hai phải tự thêm vào `package.json` của mình — `overrides` của thư viện **không** tới được consumer:

```json
"overrides": { "@radix-ui/react-dismissable-layer": "1.1.15" }
```

Đừng chữa bằng CSS ép `pointer-events` — nó che triệu chứng và phá cơ chế khoá tương tác của Dialog.

