# @coreds/react

Core DS trong một gói: toàn bộ component của `@coreds/ui`, cộng hai bộ icon của `@coreds/icons`.

## Cài đặt

Không cần token. Thêm một dòng vào `.npmrc` ở gốc app (commit cùng code, file không chứa bí mật):

```ini
@coreds:registry=https://gitlab.ikameglobal.com/api/v4/projects/2163/packages/npm/
```

```bash
npm install @coreds/react
```

## Sử dụng

```tsx
import "@coreds/react/style.css"
import { Button, Modal, toast } from "@coreds/react"
import { WalletIcon } from "@coreds/react/icons"
import { WalletIcon as VsWallet } from "@coreds/react/icons/iconsax"
```

Icon nằm ở đường dẫn phụ `/icons`, không export từ gốc. Gần 2.500 icon trong một barrel sẽ làm dev server chậm, và Phosphor với Iconsax có tên trùng nhau.

Cần editor thì cài thêm `@coreds/tiptap`.

## Cho AI agent

Gói kèm agent skill `coreds`: quy tắc dùng Core DS và toàn bộ docs dạng Markdown, khớp với version đang cài. Cài vào `.claude/skills/coreds` của app:

```bash
npx @coreds/react skill
```

`--global` cài vào `~/.claude/skills` cho mọi project, `--dir <path>` cho agent đọc skill ở chỗ khác (vd `.agents/skills`). Nâng version thì chạy lại lệnh. Agent không hỗ trợ skill vẫn đọc được thẳng `node_modules/@coreds/react/skills/coreds/SKILL.md`.
