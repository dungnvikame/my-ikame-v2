# Progress

> Thanh tiến trình khi biết hoặc chưa biết thời gian còn lại.

```tsx
import { Progress } from "@coreds/react"
```

## Examples

### Determinate — interactive

```tsx
const [value, setValue] = useState(35)

<Progress value={value} showLabel />
<div className="flex gap-2">
  <Button variant="border" size="sm" onClick={() => setValue((v) => Math.max(0, v - 10))}>
    -10
  </Button>
  <Button size="sm" onClick={() => setValue((v) => Math.min(100, v + 10))}>
    +10
  </Button>
</div>
```

### Variants — default / success / warning / error

```tsx
<Progress value={65} variant="default" showLabel />
<Progress value={65} variant="success" showLabel />
<Progress value={65} variant="warning" showLabel />
<Progress value={65} variant="error" showLabel />
```

### Sizes — sm / md / lg

```tsx
<Progress value={50} size="sm" />
<Progress value={50} size="md" />
<Progress value={50} size="lg" />
```

### With label (showLabel)

```tsx
<Progress value={72} showLabel />
<Progress value={72} showLabel variant="success" />
<Progress value={72} showLabel variant="warning" />
<Progress value={72} showLabel variant="error" />
```

### Custom label

```tsx
<Progress value={3} max={10} showLabel label="3 / 10 tasks" />
<Progress value={2400} max={5000} showLabel label="2,400 / 5,000 MB" />
```

### Custom max value

```tsx
<Progress value={7} max={10} showLabel />
<Progress value={350} max={500} showLabel />
<Progress value={1} max={4} showLabel />
```

### Indeterminate

```tsx
<Progress indeterminate />
<Progress indeterminate variant="success" />
<Progress indeterminate size="lg" />
```

### Edge cases — 0% and 100%

```tsx
<Progress value={0} showLabel />
<Progress value={100} variant="success" showLabel />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `value` | `number` | — |
| `max` | `number` | — |
| `indeterminate` | `boolean` | — |
| `size` | `"lg" \| "md" \| "sm"` | — |
| `variant` | `"default" \| "emerald" \| "error" \| "success" \| "warning"` | — |
| `showLabel` | `boolean` | — |

Bảng chỉ liệt kê prop riêng của `ProgressProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
