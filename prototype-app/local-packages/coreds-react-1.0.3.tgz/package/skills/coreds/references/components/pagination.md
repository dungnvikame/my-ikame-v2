# Pagination

> Chuyển trang cho danh sách hoặc bảng dài.

```tsx
import { Pagination } from "@coreds/react"
```

## Examples

### Interactive — with size selector

```tsx
const [pageIndex, setPageIndex] = useState(0)
const [pageSize, setPageSize] = useState(10)

<Pagination
  total={243}
  pageSize={pageSize}
  pageIndex={pageIndex}
  onPageChange={setPageIndex}
  onPageSizeChange={(next) => {
    setPageSize(next)
    setPageIndex(0)
  }}
  showSizeSelector
/>
```

### siblingCount={2} — more page buttons visible

```tsx
<Pagination
  total={500}
  pageSize={10}
  pageIndex={4}
  onPageChange={setPageIndex}
  siblingCount={2}
/>
```

### Without total count label

```tsx
<Pagination
  total={120}
  pageSize={20}
  pageIndex={0}
  onPageChange={setPageIndex}
  showTotal={false}
/>
```

### Custom pageSizeOptions

```tsx
<Pagination
  total={1000}
  pageSize={25}
  pageIndex={0}
  onPageChange={() => {}}
  onPageSizeChange={() => {}}
  pageSizeOptions={[25, 50, 100, 250]}
  showSizeSelector
/>
```

### Small dataset — few pages

```tsx
<Pagination
  total={30}
  pageSize={10}
  pageIndex={0}
  onPageChange={() => {}}
/>
```

### With page size suffix

```tsx
<Pagination
  total={243}
  pageSize={20}
  pageIndex={0}
  onPageChange={() => {}}
  onPageSizeChange={() => {}}
  pageSizeSuffix="/ trang"
  showSizeSelector
/>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `total` (required) | `number` | — |
| `pageSize` (required) | `number` | — |
| `pageIndex` (required) | `number` | — |
| `onPageChange` (required) | `function` | — |
| `onPageSizeChange` | `((size: number) => void)` | — |
| `pageSizeSuffix` | `string` | — |
| `pageSizeOptions` | `number[]` | — |
| `showSizeSelector` | `boolean` | — |
| `showTotal` | `boolean` | — |
| `siblingCount` | `number` | — |
| `renderTotal` | `((start: number, end: number, total: number) => ReactNode)` | — |

Bảng chỉ liệt kê prop riêng của `PaginationProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
