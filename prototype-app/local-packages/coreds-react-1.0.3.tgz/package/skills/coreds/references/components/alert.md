# Alert

> Thông báo nổi bật trong trang: thông tin, thành công, cảnh báo hoặc lỗi.

```tsx
import { Alert } from "@coreds/react"
```

## Examples

### All variants

```tsx
<Alert variant="default" title="Default" description="General informational message." />
<Alert variant="success" title="Success" description="Your changes were saved." />
<Alert variant="warning" title="Warning" description="Some fields require attention." />
<Alert variant="error" title="Error" description="Unable to complete this action." />
<Alert variant="info" title="Info" description="A new version is available." />
```

### Title only (no description)

```tsx
<Alert variant="success" title="All systems operational." />
<Alert variant="warning" title="Scheduled maintenance on Sunday." />
<Alert variant="error" title="Service disruption detected." />
```

### Description only (no title)

```tsx
<Alert variant="info" description="You have 3 unread notifications in your inbox." />
<Alert variant="warning" description="Your API key will expire in 7 days. Renew it to avoid disruption." />
```

### Dismissible (onClose)

```tsx
const [show, setShow] = useState(true)

{show ? (
  <Alert
    variant="info"
    title="Dismiss me"
    description="This alert can be closed by the user."
    onClose={() => setShow(false)}
  />
) : (
  <button onClick={() => setShow(true)}>Show alert again</button>
)}
```

### With action button

```tsx
const [show, setShow] = useState(true)

{show && (
  <Alert
    variant="warning"
    title="Upgrade required"
    description="Some features are unavailable on your current plan."
    action={
      <Button size="sm" variant="border">
        View plans
      </Button>
    }
    onClose={() => setShow(false)}
  />
)}
```

### Custom icon

```tsx
import { LightningIcon as Zap } from "@coreds/icons"

<Alert
  variant="default"
  title="Custom icon"
  description="You can pass any React node as the icon."
  icon={<Zap size="s" className="text_accent_primary" aria-hidden="true" />}
/>
```

### With children (custom body)

```tsx
<Alert variant="error" title="Validation failed">
  <ul className="list-disc list-inside text-sm mt-1 space-y-0.5">
    <li>Email is required.</li>
    <li>Password must be at least 8 characters.</li>
    <li>Username is already taken.</li>
  </ul>
</Alert>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `variant` | `"default" \| "error" \| "info" \| "success" \| "warning"` | — |
| `description` | `string` | — |
| `icon` | `ReactNode` | — |
| `onClose` | `(() => void)` | — |
| `action` | `ReactNode` | — |

Bảng chỉ liệt kê prop riêng của `AlertProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
