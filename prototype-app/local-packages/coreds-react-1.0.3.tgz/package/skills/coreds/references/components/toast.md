# Toast

> Thông báo ngắn hiện ở góc màn hình, gọi bằng hàm `toast()`. Cần `Toaster` ở gốc app.

```tsx
import { toast, Toaster } from "@coreds/react"
```

## Examples

### Variants — default / error / warning / info

```tsx
<Button onClick={() => toast("Saved successfully")}>Default</Button>
<Button variant="border" onClick={() => toast.error("Something went wrong")}>Error</Button>
<Button variant="secondary" onClick={() => toast.warning("Check your input")}>Warning</Button>
<Button variant="subtle" onClick={() => toast.info("New update available")}>Info</Button>
```

### Thông báo thường — nền trắng, không có icon

```tsx
toast("Thông tin đã được cập nhật")
toast("Thông tin của kỳ hiện tại đã được đồng bộ. Bạn có thể mở báo cáo để xem chi tiết.")
```

### Success toast

```tsx
<Button onClick={() => toast.success("Lưu trạng thái thành công")}>Success</Button>
```

### Success toast — chiều rộng theo nội dung, tối đa 356px

```tsx
toast.success("Đã lưu")
toast.success("Lưu trạng thái thành công")
toast.success("Đã cập nhật tiến độ của mục tiêu và đồng bộ thay đổi cho tất cả thành viên trong nhóm.")
toast.success("Báo cáo kỳ vọng của bạn đã được lưu thành công. Những thay đổi mới nhất sẽ hiển thị trong trang tổng quan và được chia sẻ với các thành viên có quyền truy cập vào mục tiêu này.")
```

### Error toast — mặt buồn chuyển thành dấu X

```tsx
toast.error("Lưu trạng thái không thành công")
toast.error("Không thể lưu trạng thái. Vui lòng kiểm tra kết nối và thử lại sau.")
```

### Warning / alert toast — tia sét chuyển thành cảnh báo

```tsx
toast.warning("Có thay đổi cần bạn kiểm tra")
toast.warning("Một số thông tin chưa được cập nhật. Vui lòng kiểm tra lại trước khi tiếp tục.")
```

### Info toast — mặt trung tính chuyển thành biểu tượng thông tin

```tsx
toast.info("Dữ liệu mới đã sẵn sàng")
toast.info("Thông tin của kỳ hiện tại đã được đồng bộ. Bạn có thể mở báo cáo để xem chi tiết.")
```

### With description

```tsx
<Button
  onClick={() =>
    toast("Project created", {
      description: "Your new project has been set up and is ready to use.",
    })
  }
>
  With description
</Button>
```

### With action button

```tsx
<Button
  onClick={() =>
    toast("File deleted", {
      description: "The file has been moved to the trash.",
      action: {
        label: "Undo",
        onClick: () => toast("Undo successful"),
      },
    })
  }
>
  With action
</Button>
```

### Custom duration

```tsx
<Button
  variant="border"
  onClick={() =>
    toast("Quick toast (1 s)", { duration: 1000 })
  }
>
  1 second
</Button>

<Button
  variant="border"
  onClick={() =>
    toast("Long toast (8 s)", { duration: 8000 })
  }
>
  8 seconds
</Button>

<Button
  variant="border"
  onClick={() =>
    toast("Persistent toast", { duration: Infinity })
  }
>
  Persistent
</Button>
```

### Promise toast

```tsx
<Button
  variant="border"
  onClick={() => {
    const promise = new Promise<{ name: string }>((resolve) =>
      setTimeout(() => resolve({ name: "Deploy #42" }), 2000)
    )
    toast.promise(promise, {
      loading: "Deploying...",
      success: (data) => `${data.name} deployed successfully!`,
      error: "Deployment failed",
    })
  }}
>
  Promise toast
</Button>
```

### Error with action

```tsx
<Button
  variant="border"
  onClick={() =>
    toast.error("Upload failed", {
      description: "The file exceeded the 10 MB limit.",
      action: {
        label: "Retry",
        onClick: () => toast.info("Retrying upload..."),
      },
    })
  }
>
  Error with action
</Button>
```

### Position config

```tsx
// In your app root:
<Toaster position="top-right" />

// Available positions:
// "top-left" | "top-center" | "top-right"
// "bottom-left" | "bottom-center" | "bottom-right"

// Default: "top-right"
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `position` | `"bottom-center" \| "bottom-left" \| "bottom-right" \| "top-center" \| "top-left" \| "top-right"` | — |
| `expand` | `boolean` | — |
| `richColors` | `boolean` | — |
| `closeButton` | `boolean` | — |
| `duration` | `number` | — |

Bảng chỉ liệt kê prop riêng của `ToasterProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

`toast` là hàm của [Sonner](https://sonner.emilkowal.ski): `toast.success()`, `toast.error()`, `toast.promise()`… đều dùng được.
