# ScrollArea

> Vùng cuộn với thanh cuộn theo style của design system.

```tsx
import { ScrollArea } from "@coreds/react"
```

## Examples

### Vertical scroll (100 items)

```tsx
<ScrollArea className="h-64 border border_secondary radius_8">
  {Array.from({ length: 100 }, (_, i) => (
    <div
      key={i}
      className="px-4 py-2 border-b border_secondary text_secondary text-sm last:border-0"
    >
      Item {i + 1}
    </div>
  ))}
</ScrollArea>
```

### Horizontal scroll

```tsx
<ScrollArea
  orientation="horizontal"
  overflowFade
  className="w-80 border border_secondary radius_8"
>
  <div className="flex gap-3 p-4" style={{ width: "900px" }}>
    {Array.from({ length: 20 }, (_, i) => (
      <div
        key={i}
        className="shrink-0 w-24 h-16 bg_secondary radius_6 flex items-center justify-center text_tertiary text-sm"
      >
        Col {i + 1}
      </div>
    ))}
  </div>
</ScrollArea>
```

### Both axes — orientation="both"

```tsx
<ScrollArea orientation="both" className="h-48 w-72 border border_secondary radius_8">
  <div style={{ width: "600px", height: "400px" }} className="p-4">
    <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(10, 80px)" }}>
      {Array.from({ length: 80 }, (_, i) => (
        <div
          key={i}
          className="h-10 bg_secondary radius_4 flex items-center justify-center text_tertiary text-xs"
        >
          {i + 1}
        </div>
      ))}
    </div>
  </div>
</ScrollArea>
```

### VirtualList — 10,000 items (high performance)

```tsx
const items = Array.from({ length: 10000 }, (_, i) => ({ id: i, name: `Item #${i + 1}` }))

<VirtualList
  items={items}
  estimateSize={40}
  className="h-64 border border_secondary radius_8"
  getItemKey={(item) => item.id}
  renderItem={(item, index) => (
    <div className="px-4 py-2.5 border-b border_secondary text_secondary text-sm flex items-center gap-3">
      <span className="text_tertiary text-xs font-mono w-16 shrink-0">#{index + 1}</span>
      {item.name}
    </div>
  )}
/>
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `orientation` | `"both" \| "horizontal" \| "vertical"` | — |  |
| `viewportClassName` | `string` | — |  |
| `overflowFade` | `"both" \| boolean` | — | Fades the content out at the edge it can still scroll towards. `true` fades the trailing edge only; `"both"` also fades the leading edge once the viewport has scrolled away from it, so content disappears under both ends instead of being cut off. |
| `overflowFadeClassName` | `string` | — | Customizes the trailing gradient, including its color or size. |
| `type` | `"always" \| "auto" \| "hover" \| "scroll"` | — | When the scrollbar exists. `hover` (default) mounts it only while the pointer is over the area, so there is nothing in the DOM to style at rest; `always` keeps it mounted. |
| `asChild` | `boolean` | — |  |
| `dir` | `"ltr" \| "rtl"` | — |  |
| `scrollHideDelay` | `number` | — |  |

Bảng chỉ liệt kê prop riêng của `ScrollAreaProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
