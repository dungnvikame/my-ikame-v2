# Calendar

> Lịch chọn ngày hoặc khoảng ngày, có thể đánh dấu những ngày đặc biệt.

```tsx
import { Calendar } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Flag` là `FlagIcon` (import từ `@coreds/react/icons`).

### Single mode — uncontrolled

```tsx
<Calendar defaultValue={new Date()} />
```

### Single mode — controlled with selected date display

```tsx
const [date, setDate] = useState<Date>(new Date())

<div className="space-y-3">
  <Calendar value={date} onValueChange={setDate} />
  <p className="text_tertiary text-xs">Selected: {date.toLocaleDateString("en-GB")}</p>
</div>
```

### Range mode — controlled with range display

```tsx
const [range, setRange] = useState<DateRange>({})

<div className="space-y-3 overflow-x-auto">
  <Calendar mode="range" value={range} onValueChange={setRange} />
  <p className="text_tertiary text-xs">
    From: {range.from?.toLocaleDateString("en-GB") ?? "--"} |
    To: {range.to?.toLocaleDateString("en-GB") ?? "--"}
  </p>
</div>
```

### Range mode — uncontrolled

```tsx
<Calendar mode="range" defaultValue={{ from: new Date() }} />
```

### minDate / maxDate constraints (±15 days from today)

```tsx
const today = new Date()
const minDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 15)
const maxDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 15)

<Calendar minDate={minDate} maxDate={maxDate} defaultValue={today} />
```

### disabledDates — specific dates array

```tsx
const today = new Date()
const disabledDates = [
  new Date(today.getFullYear(), today.getMonth(), today.getDate() + 2),
  new Date(today.getFullYear(), today.getMonth(), today.getDate() + 5),
]

<Calendar mode="range" disabledDates={disabledDates} />
```

### disabledDates — function (weekends)

```tsx
<Calendar
  mode="range"
  disabledDates={(date) => date.getDay() === 0 || date.getDay() === 6}
/>
```

### disabledDates — function (past dates)

```tsx
<Calendar
  disabledDates={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
/>
```

### dayDecorators - weekly weekends (Sat/Sun dot)

```tsx
const weekendDecorators: DayDecoratorRule[] = [
  {
    type: "weekly",
    weekdays: [0, 6],
    icon: <span className="h-1.5 w-1.5 radius_round bg_accent_secondary" />,
  },
]

<Calendar dayDecorators={weekendDecorators} />
```

### dayDecorators - yearly national holidays

```tsx
const holidayDecorators: DayDecoratorRule[] = [
  { type: "yearly", month: 0, day: 1, icon: <Flag className="h-2.5 w-2.5 fg_warning" /> },
  { type: "yearly", month: 3, day: 30, icon: <Flag className="h-2.5 w-2.5 fg_warning" /> },
  { type: "yearly", month: 4, day: 1, icon: <Flag className="h-2.5 w-2.5 fg_warning" /> },
  { type: "yearly", month: 8, day: 2, icon: <Flag className="h-2.5 w-2.5 fg_warning" /> },
]

<Calendar dayDecorators={holidayDecorators} />
```

### minDate only (no earlier than today)

```tsx
<Calendar minDate={new Date()} />
```

### maxDate only (no later than today)

```tsx
<Calendar maxDate={new Date()} />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `mode` | `"range" \| "single"` | — |
| `value` | `Date \| DateRange` | — |
| `defaultValue` | `Date \| DateRange` | — |
| `onValueChange` | `((date: Date) => void) \| ((range: DateRange) => void)` | — |
| `minDate` | `Date` | — |
| `maxDate` | `Date` | — |
| `disabledDates` | `Date[] \| ((date: Date) => boolean)` | — |
| `dayDecorators` | `DayDecoratorRule[]` | — |
| `weekDayLabels` | `[string, string, string, string, string, string, string]` | — |

Bảng chỉ liệt kê prop riêng của `CalendarProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
