# Popover

> Khung nổi gắn với một phần tử, chứa nội dung tương tác nhỏ.

```tsx
import { Popover } from "@coreds/react"
```

## Examples

### Basic

```tsx
<Popover trigger={<Button variant="border">Open popover</Button>}>
  <div className="space-y-1">
    <p className="text_primary text-sm font-medium">Quick actions</p>
    <p className="text_secondary text-sm">
      Use this area for filters, shortcuts, and contextual actions.
    </p>
  </div>
</Popover>
```

### Side — top / right / bottom / left

```tsx
<Popover trigger={<Button variant="border">Top</Button>} side="top">
  <p className="text_secondary text-sm">Opens above the trigger.</p>
</Popover>

<Popover trigger={<Button variant="border">Right</Button>} side="right">
  <p className="text_secondary text-sm">Opens to the right.</p>
</Popover>

<Popover trigger={<Button variant="border">Bottom</Button>} side="bottom">
  <p className="text_secondary text-sm">Opens below the trigger.</p>
</Popover>

<Popover trigger={<Button variant="border">Left</Button>} side="left">
  <p className="text_secondary text-sm">Opens to the left.</p>
</Popover>
```

### Alignment — start / center / end

```tsx
<Popover trigger={<Button variant="border">Align start</Button>} side="bottom" align="start">
  <p className="text_secondary text-sm">Aligned to start of trigger.</p>
</Popover>

<Popover trigger={<Button variant="border">Align center</Button>} side="bottom" align="center">
  <p className="text_secondary text-sm">Centered on trigger.</p>
</Popover>

<Popover trigger={<Button variant="border">Align end</Button>} side="bottom" align="end">
  <p className="text_secondary text-sm">Aligned to end of trigger.</p>
</Popover>
```

### sideOffset — custom spacing from trigger

```tsx
<Popover
  trigger={<Button variant="border">4 px offset</Button>}
  side="bottom"
  sideOffset={4}
>
  <p className="text_secondary text-sm">4 px gap from trigger.</p>
</Popover>

<Popover
  trigger={<Button variant="border">16 px offset</Button>}
  side="bottom"
  sideOffset={16}
>
  <p className="text_secondary text-sm">16 px gap from trigger.</p>
</Popover>
```

### With form content

```tsx
<Popover
  trigger={<Button>Filter results</Button>}
  side="bottom"
  align="start"
>
  <div className="space-y-3 w-56">
    <p className="text_primary text-sm font-medium">Filter options</p>
    <Input placeholder="Search by name" />
    <div className="flex justify-end gap-2">
      <Button variant="subtle" size="sm">Reset</Button>
      <Button size="sm">Apply</Button>
    </div>
  </div>
</Popover>
```

### Popover + Select (nested floating layers)

```tsx
const [team, setTeam] = useState<string | string[]>("")
const [portalContainer, setPortalContainer] = useState<HTMLElement | null>(null)

<Popover trigger={<Button variant="border">Open popover with select</Button>} side="bottom" align="start">
  <div ref={setPortalContainer} className="space-y-3 w-64">
    <p className="text_primary text-sm font-medium">Assign team</p>
    <Select
      options={teamOptions}
      value={team}
      onValueChange={setTeam}
      searchable
      portalContainer={portalContainer}
      placeholder="Choose team"
    />
  </div>
</Popover>
```

### Popover inside Drawer

```tsx
<Drawer>
  <DrawerTrigger asChild>
    <Button variant="border">Open drawer popover</Button>
  </DrawerTrigger>
  <DrawerContent side="right" size="m">
    <DrawerHeader>
      <div>
        <DrawerTitle>Assign user</DrawerTitle>
        <DrawerDescription>Popover content stays inside the drawer layer.</DrawerDescription>
      </div>
    </DrawerHeader>
    <DrawerBody>
      <Popover
        trigger={<Button variant="border">Choose assignee</Button>}
        portal={false}
        side="bottom"
        align="start"
        className="w-72"
      >
        <div className="max-h-64 overflow-y-auto pr-1">
          {assignees.map((name) => (
            <button key={name} type="button" className="block w-full px-3 py-2 text-left text-sm text_primary hover:state_neutral_soft">
              {name}
            </button>
          ))}
        </div>
      </Popover>
    </DrawerBody>
  </DrawerContent>
</Drawer>
```

### Controlled open state

```tsx
const [open, setOpen] = useState(false)

<div className="flex items-center gap-3">
  <Popover
    open={open}
    onOpenChange={setOpen}
    trigger={<Button variant="border">Controlled popover</Button>}
  >
    <div className="space-y-1">
      <p className="text_primary text-sm font-medium">Controlled</p>
      <p className="text_secondary text-sm">This popover's open state is managed externally.</p>
    </div>
  </Popover>
  <Button size="sm" variant="subtle" onClick={() => setOpen((v) => !v)}>
    Toggle ({open ? "open" : "closed"})
  </Button>
</div>
```

## Props

### PopoverProps

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `trigger` (required) | `ReactNode` | — |  |
| `onOpenChange` | `((open: boolean) => void)` | — |  |
| `side` | `"bottom" \| "left" \| "right" \| "top"` | — |  |
| `align` | `"center" \| "end" \| "start"` | — |  |
| `sideOffset` | `number` | — |  |
| `portal` | `boolean` | — |  |
| `portalContainer` | `HTMLElement \| null` | — | Where the portalled content mounts. Defaults to `document.body`, which puts it outside any Dialog — the Dialog's focus trap then pulls focus back and the popover closes on its own, and what is left of it sits outside the Dialog's interaction layer. Pass the Dialog's own element to keep it inside. Mirrors `Select`. |

Bảng chỉ liệt kê prop riêng của `PopoverProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

### PopoverContentProps

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `portal` | `boolean` | — |  |
| `portalContainer` | `HTMLElement \| null` | — |  |
| `asChild` | `boolean` | — |  |
| `deferPointerDownOutside` | `boolean` | — | When `true`, a `'pointerdown'` event outside of the layered element will wait for the interaction's click event before dispatching, allowing third-party code to stop propagation of later events and cancel dismissal. |
| `onEscapeKeyDown` | `((event: KeyboardEvent) => void)` | — | Event handler called when the escape key is down. Can be prevented. |
| `onPointerDownOutside` | `((event: PointerDownOutsideEvent) => void)` | — | Event handler called when the a `pointerdown` event happens outside of the `DismissableLayer`. Can be prevented. |
| `onFocusOutside` | `((event: FocusOutsideEvent) => void)` | — | Event handler called when the focus moves outside of the `DismissableLayer`. Can be prevented. |
| `onInteractOutside` | `((event: PointerDownOutsideEvent \| FocusOutsideEvent) => void)` | — | Event handler called when an interaction happens outside the `DismissableLayer`. Specifically, when a `pointerdown` event happens outside or focus moves outside of it. Can be prevented. |
| `side` | `"bottom" \| "left" \| "right" \| "top"` | — |  |
| `sideOffset` | `number` | — |  |
| `align` | `"center" \| "end" \| "start"` | — |  |
| `alignOffset` | `number` | — |  |
| `arrowPadding` | `number` | — |  |
| `avoidCollisions` | `boolean` | — |  |
| `collisionBoundary` | `Boundary[] \| Boundary` | — |  |
| `collisionPadding` | `number \| Partial<Record<"bottom" \| "left" \| "right" \| "top", number>>` | — |  |
| `sticky` | `"always" \| "partial"` | — |  |
| `hideWhenDetached` | `boolean` | — |  |
| `updatePositionStrategy` | `"always" \| "optimized"` | — |  |
| `forceMount` | `true` | — | Used to force mounting when more control is needed. Useful when controlling animation with React animation libraries. |
| `onOpenAutoFocus` | `((event: Event) => void)` | — | Event handler called when auto-focusing on open. Can be prevented. |
| `onCloseAutoFocus` | `((event: Event) => void)` | — | Event handler called when auto-focusing on close. Can be prevented. |

Bảng chỉ liệt kê prop riêng của `PopoverContentProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
