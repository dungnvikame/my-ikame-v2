# Steps

> Các bước của một quy trình và bước đang làm.

```tsx
import { Steps } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Briefcase` là `BriefcaseIcon`, `CheckCircle` là `CheckCircleIcon`, `FileText` là `FileTextIcon`, `Mail` là `EnvelopeIcon`, `Send` là `PaperPlaneTiltIcon`, `UserCheck` là `UserCheckIcon` (import từ `@coreds/react/icons`).

### variant="number" — horizontal (default)

```tsx
<Steps
  steps={[
    { content: <><p className="text-sm font-medium text_primary">Details</p><p className="text-xs text_tertiary">Enter project information</p></> },
    { content: <><p className="text-sm font-medium text_primary">Review</p><p className="text-xs text_tertiary">Confirm and validate</p></> },
    { content: <><p className="text-sm font-medium text_primary">Publish</p><p className="text-xs text_tertiary">Release to production</p></> },
  ]}
  currentStep={1}
/>
```

### variant="number" — all completed

```tsx
<Steps steps={steps} currentStep={3} />
```

### variant="dot" — horizontal

```tsx
<Steps steps={steps} currentStep={2} variant="dot" />
```

### variant="icon" — horizontal

```tsx
<Steps
  variant="icon"
  steps={[
    { icon: <FileText size="s" />, content: ... },
    ...
  ]}
  currentStep={2}
/>
```

### variant="number" — vertical

```tsx
<div className="max-w-xs">
  <Steps
    steps={steps}
    currentStep={1}
    orientation="vertical"
  />
</div>
```

### variant="dot" — vertical (recruitment pipeline)

```tsx
<div className="max-w-xs">
  <Steps steps={dotSteps} currentStep={2} orientation="vertical" variant="dot" />
</div>
```

### variant="icon" + secondaryContent — vertical timeline

```tsx
<div className="max-w-sm">
  <Steps
    steps={[
      {
        secondaryContent: <span className="text-xs text_tertiary">21:54</span>,
        icon: <Mail size="s" />,
        content: <div><p className="text-sm font-medium text_primary">Email du?c c?p nh?t</p><p className="text-xs text_tertiary">B?i Nguy?n Phuong Anh</p></div>,
      },
      ...
    ]}
    currentStep={1}
    orientation="vertical"
    variant="icon"
  />
</div>
```

### Clickable steps (controlled)

```tsx
const [currentStep, setCurrentStep] = useState(1)

<Steps steps={steps} currentStep={currentStep} />
<button onClick={() => setCurrentStep(s => Math.max(0, s - 1))}>Back</button>
<button onClick={() => setCurrentStep(s => Math.min(steps.length, s + 1))}>Next</button>
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `steps` (required) | `array` | — |  |
| `currentStep` (required) | `number` | — |  |
| `orientation` | `"horizontal" \| "vertical"` | — |  |
| `variant` | `"dot" \| "icon" \| "number"` | — | "number" = numbered circles (default), "dot" = small dots, "icon" = custom icon per step |

Bảng chỉ liệt kê prop riêng của `StepsProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
