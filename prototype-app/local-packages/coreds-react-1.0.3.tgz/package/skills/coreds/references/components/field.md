# Field

> Bọc một ô nhập với nhãn, mô tả và thông báo lỗi.

```tsx
import { Field } from "@coreds/react"
```

## Examples

### Input field

```tsx
<Field label="Email" required supportingText="Use your work email.">
  <Input type="email" placeholder="you@example.com" />
</Field>
```

### Error

```tsx
<Field label="Username" error="Username can only contain letters and numbers.">
  <Input defaultValue="bad user!" />
</Field>
```

### Select field

```tsx
<Field label="Role" supportingText="Choose the closest match.">
  <Select options={roleOptions} placeholder="Select role" />
</Field>
```

### Textarea field

```tsx
<Field label="Notes" supportingText="Add context for reviewers.">
  <Textarea placeholder="Write notes..." />
</Field>
```

### Disabled

```tsx
<Field label="Company" disabled supportingText="Synced from your workspace.">
  <Input defaultValue="Ikame Global" />
</Field>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `label` | `ReactNode` | — |
| `supportingText` | `ReactNode` | — |
| `error` | `string` | — |
| `children` (required) | `object` | — |

Bảng chỉ liệt kê prop riêng của `FieldProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
