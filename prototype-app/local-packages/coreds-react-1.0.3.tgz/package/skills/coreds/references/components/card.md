# Card

> Khung gom một nhóm nội dung liên quan: tiêu đề, mô tả, nội dung và chân.

```tsx
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Bell` là `BellIcon`, `BarChart2` là `ChartBarIcon` (import từ `@coreds/react/icons`).

### Basic — header, content, footer

```tsx
<Card className="max-w-md">
  <CardHeader>
    <CardTitle>Project summary</CardTitle>
    <CardDescription>Short overview of project health and milestones.</CardDescription>
  </CardHeader>
  <CardContent>
    <p className="text_secondary text-sm">All critical tasks are on track this sprint.</p>
  </CardContent>
  <CardFooter>
    <Button size="sm" variant="border">Details</Button>
    <Button size="sm">Open</Button>
  </CardFooter>
</Card>
```

### Content only (no header/footer)

```tsx
<Card className="max-w-sm p-6">
  <CardContent className="p-0">
    <p className="text_secondary text-sm">A simple card with only content — no header or footer slots needed.</p>
  </CardContent>
</Card>
```

### With icon and badge in header

```tsx
<Card className="max-w-md">
  <CardHeader>
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Bell size="s" className="icon_secondary" />
        <CardTitle>Notifications</CardTitle>
      </div>
      <Badge variant="error" size="sm">12</Badge>
    </div>
    <CardDescription>Unread alerts from your integrations.</CardDescription>
  </CardHeader>
  <CardContent>
    <p className="text_secondary text-sm">Review and dismiss incoming notifications.</p>
  </CardContent>
</Card>
```

### Shadow variants

```tsx
<div className="flex flex-wrap gap-4">
  <Card shadow="none" className="w-40 p-4">
    <p className="text_secondary text-xs font-medium">shadow: none</p>
  </Card>
  <Card shadow="xs" className="w-40 p-4">
    <p className="text_secondary text-xs font-medium">shadow: xs (default)</p>
  </Card>
  <Card shadow="sm" className="w-40 p-4">
    <p className="text_secondary text-xs font-medium">shadow: sm</p>
  </Card>
  <Card shadow="md" className="w-40 p-4">
    <p className="text_secondary text-xs font-medium">shadow: md</p>
  </Card>
  <Card shadow="lg" className="w-40 p-4">
    <p className="text_secondary text-xs font-medium">shadow: lg</p>
  </Card>
  <Card shadow="xl" className="w-40 p-4">
    <p className="text_secondary text-xs font-medium">shadow: xl</p>
  </Card>
</div>
```

### Hoverable

```tsx
<div className="flex gap-4">
  <Card hoverable className="max-w-xs">
    <CardHeader>
      <CardTitle>Hover me</CardTitle>
      <CardDescription>Shadow elevates on hover.</CardDescription>
    </CardHeader>
    <CardContent>
      <p className="text_secondary text-sm">Useful for clickable card patterns.</p>
    </CardContent>
  </Card>
  <Card className="max-w-xs">
    <CardHeader>
      <CardTitle>Static card</CardTitle>
      <CardDescription>No hover effect.</CardDescription>
    </CardHeader>
    <CardContent>
      <p className="text_secondary text-sm">Default behavior without hoverable prop.</p>
    </CardContent>
  </Card>
</div>
```

### Stats card — content-only layout

```tsx
<div className="flex gap-4">
  <Card className="w-48">
    <CardContent>
      <div className="flex items-center justify-between mb-2">
        <p className="text_secondary text-sm">Revenue</p>
        <BarChart2 size={14} className="icon_tertiary" />
      </div>
      <p className="text_primary text-2xl font-bold">$48,230</p>
      <p className="text_tertiary text-xs mt-1">+12% from last month</p>
    </CardContent>
  </Card>
</div>
```

## Props

Các phần của Card là thẻ `div` có sẵn style, nhận mọi thuộc tính HTML của `div`.
