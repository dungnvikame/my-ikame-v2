# FileUpload

> Vùng kéo-thả hoặc bấm để chọn file, kèm danh sách file đã chọn.

```tsx
import { FileUpload } from "@coreds/react"
```

## Examples

### Basic (uncontrolled)

```tsx
<FileUpload
  placeholder="Upload a file"
  description="Drag and drop or click to browse"
  onFileAdd={(files) => console.log("new files:", files)}
/>
```

### Image upload with 4MB limit

```tsx
<FileUpload
  accept="image/*"
  multiple
  maxSize={4 * 1024 * 1024}
  placeholder="Upload a project image"
  description="or, click to browse (4MB max)"
/>
```

### Controlled — with progress

```tsx
// Controlled mode: manage files with progress externally
<FileUpload
  files={controlled}
  onFileRemove={(id) => setControlled(prev => prev.filter(f => f.id !== id))}
  placeholder="Upload files"
/>
```

### Disabled

```tsx
<FileUpload disabled placeholder="Upload disabled" />
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `maxSize` | `number` | — | Max file size in bytes |
| `maxFiles` | `number` | — | Max number of files (only applied in uncontrolled mode) |
| `files` | `FileEntry[]` | — | Controlled file list |
| `onFilesChange` | `((files: FileEntry[]) => void)` | — | Fires when files list changes (uncontrolled mode) |
| `onFileAdd` | `((files: File[]) => void)` | — | Fires when new valid File objects are added — use this to start uploads |
| `onFileRemove` | `((id: string) => void)` | — | Fires when a file is removed |
| `description` | `string` | — | Drop zone sub-text |

Bảng chỉ liệt kê prop riêng của `FileUploadProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
