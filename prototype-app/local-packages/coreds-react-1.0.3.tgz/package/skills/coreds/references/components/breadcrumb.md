# Breadcrumb

> Đường dẫn cho biết trang hiện tại nằm ở đâu trong cấu trúc.

```tsx
import { Breadcrumb } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Home` là `HouseIcon` (import từ `@coreds/react/icons`).

### Basic (no truncation)

```tsx
<Breadcrumb
  items={[
    { label: "Home", href: "#", icon: <Home size={14} /> },
    { label: "Components", href: "#" },
    { label: "Demo" },
  ]}
/>
```

### maxItems={4} — collapses middle items

```tsx
<Breadcrumb
  items={[
    { label: "Home", href: "#", icon: <Home size={14} /> },
    { label: "Components", href: "#" },
    { label: "Form", href: "#" },
    { label: "Select", href: "#" },
    { label: "Demo" },
  ]}
  maxItems={4}
/>
```

### maxItems={3} — aggressive collapse

```tsx
<Breadcrumb
  items={[
    { label: "Home", href: "#", icon: <Home size={14} /> },
    { label: "Components", href: "#" },
    { label: "Form", href: "#" },
    { label: "Select", href: "#" },
    { label: "Demo" },
  ]}
  maxItems={3}
/>
```

### maxItems={2} — minimum visible

```tsx
<Breadcrumb
  items={[
    { label: "Home", href: "#", icon: <Home size={14} /> },
    { label: "Components", href: "#" },
    { label: "Form", href: "#" },
    { label: "Select", href: "#" },
    { label: "Demo" },
  ]}
  maxItems={2}
/>
```

### Custom separator

```tsx
<Breadcrumb
  items={[
    { label: "Home", href: "#" },
    { label: "Settings", href: "#" },
    { label: "Profile" },
  ]}
  separator={<span aria-hidden="true">/</span>}
/>
```

### Short path (no truncation needed)

```tsx
<Breadcrumb
  items={[
    { label: "Home", href: "#", icon: <Home size={14} /> },
    { label: "Profile" },
  ]}
  maxItems={4}
/>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `items` (required) | `array` | — |
| `separator` | `ReactNode` | — |
| `maxItems` | `number` | — |

Bảng chỉ liệt kê prop riêng của `BreadcrumbProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
