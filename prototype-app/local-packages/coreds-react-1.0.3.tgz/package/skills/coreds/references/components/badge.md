# Badge

> Nhãn nhỏ cho trạng thái, phân loại hoặc số đếm. NotiBadge là chấm hoặc số thông báo gắn lên phần tử khác.

```tsx
import { Badge, NotiBadge } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Bell` là `BellIcon`, `Check` là `CheckIcon`, `X` là `XIcon` (import từ `@coreds/react/icons`).

### Semantic variants

```tsx
<Badge>Default</Badge>
<Badge variant="primary">Primary</Badge>
<Badge variant="success">Success</Badge>
<Badge variant="warning">Warning</Badge>
<Badge variant="error">Error</Badge>
<Badge variant="info">Info</Badge>
<Badge variant="outline">Outline</Badge>
```

### Rounded (default)

```tsx
<Badge>Default</Badge>
<Badge variant="primary">Primary</Badge>
<Badge color="blue">Blue</Badge>
```

### Square corners

```tsx
<Badge rounded={false}>Default</Badge>
<Badge rounded={false} variant="primary">Primary</Badge>
<Badge rounded={false} color="blue">Blue</Badge>
<Badge rounded={false} color="red">Red</Badge>
```

### Sizes

```tsx
<Badge size="xs" variant="primary">XS</Badge>
<Badge size="s" variant="primary">S</Badge>
<Badge size="m" variant="primary">M</Badge>
<Badge size="l" variant="primary">L</Badge>
<Badge size="xl" variant="primary">XL</Badge>
```

### Color palette (bordered)

```tsx
<Badge color="light">Light</Badge>
<Badge color="gray">Gray</Badge>
<Badge color="orange">Orange</Badge>
<Badge color="amber">Amber</Badge>
<Badge color="yellow">Yellow</Badge>
<Badge color="lime">Lime</Badge>
<Badge color="green">Green</Badge>
<Badge color="emerald">Emerald</Badge>
<Badge color="teal">Teal</Badge>
<Badge color="cyan">Cyan</Badge>
<Badge color="sky">Sky</Badge>
<Badge color="blue">Blue</Badge>
<Badge color="indigo">Indigo</Badge>
<Badge color="violet">Violet</Badge>
<Badge color="purple">Purple</Badge>
<Badge color="fuchsia">Fuchsia</Badge>
<Badge color="pink">Pink</Badge>
<Badge color="red">Red</Badge>
```

### Color palette (no border)

```tsx
<Badge color="orange" bordered={false}>Orange</Badge>
<Badge color="blue" bordered={false}>Blue</Badge>
<Badge color="green" bordered={false}>Green</Badge>
<Badge color="red" bordered={false}>Red</Badge>
<Badge color="purple" bordered={false}>Purple</Badge>
```

### Dot indicator

```tsx
<Badge variant="success" dot>Active</Badge>
<Badge variant="warning" dot>Pending</Badge>
<Badge variant="error" dot>Offline</Badge>
<Badge variant="info" dot>Syncing</Badge>
<Badge color="blue" dot>In progress</Badge>
<Badge color="gray" dot>Archived</Badge>
```

### Dot with sizes

```tsx
<Badge size="xs" variant="success" dot>XS</Badge>
<Badge size="s" variant="success" dot>S</Badge>
<Badge size="m" variant="success" dot>M</Badge>
<Badge size="l" variant="success" dot>L</Badge>
<Badge size="xl" variant="success" dot>XL</Badge>
```

### Icon slots

```tsx
<Badge color="green" iconLeft={<Check size="xs" />}>Approved</Badge>
<Badge color="red" iconRight={<X size="xs" />}>Needs review</Badge>
<Badge color="blue" iconLeft={<Bell size="xs" />} iconRight={<X size="xs" />}>
  Watching
</Badge>
```

### NotiBadge

```tsx
<NotiBadge count={7} />
<NotiBadge size="m" count={12} />
<NotiBadge size="s" aria-label="Unread notifications" />
<NotiBadge count={128} />
<NotiBadge color="blue" count={4} />
```

## Props

### BadgeProps

| Prop | Type | Default |
| --- | --- | --- |
| `size` | `"l" \| "lg" \| "m" \| "md" \| "s" \| "sm" \| "xl" \| "xs"` | — |
| `rounded` | `boolean` | — |
| `dot` | `boolean` | — |
| `iconLeft` | `ReactNode` | — |
| `iconRight` | `ReactNode` | — |
| `variant` | `"default" \| "error" \| "info" \| "outline" \| "primary" \| "success" \| "warning" \| null` | — |
| `color` | `"amber" \| "blue" \| "cyan" \| "emerald" \| "fuchsia" \| "gray" \| "green" \| "indigo" \| "light" \| "lime" \| "orange" \| "pink" \| "purple" \| "red" \| "sky" \| "teal" \| "violet" \| "white" \| "yellow" \| null` | — |
| `bordered` | `boolean \| null` | — |

Bảng chỉ liệt kê prop riêng của `BadgeProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

### NotiBadgeProps

| Prop | Type | Default |
| --- | --- | --- |
| `count` | `number` | — |
| `max` | `number` | — |
| `overflowLabel` | `ReactNode` | — |
| `size` | `"l" \| "m" \| "s" \| null` | — |
| `color` | `"amber" \| "blue" \| "cyan" \| "emerald" \| "fuchsia" \| "gray" \| "green" \| "indigo" \| "lime" \| "orange" \| "pink" \| "purple" \| "red" \| "sky" \| "teal" \| "violet" \| "yellow" \| null` | — |

Bảng chỉ liệt kê prop riêng của `NotiBadgeProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
