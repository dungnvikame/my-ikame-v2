# InputPinCode

> Ô nhập mã PIN hoặc OTP theo từng ký tự.

```tsx
import { InputPinCode } from "@coreds/react"
```

## Examples

### Basic

```tsx
<InputPinCode />
```

### Lengths

```tsx
<InputPinCode length={4} />
<InputPinCode length={6} />
<InputPinCode length={8} />
```

### Variants

```tsx
<InputPinCode variant="light" />
<InputPinCode variant="fill" />
<InputPinCode variant="dim" />
```

### Sizes

```tsx
<InputPinCode size="s" />
<InputPinCode size="m" />
<InputPinCode size="l" />
```

### Masked

```tsx
<InputPinCode mask />
```

### With separator

```tsx
<InputPinCode length={6} separatorAfter={[3]} />
<InputPinCode length={6} separatorAfter={[2]} />
```

### Alphanumeric

```tsx
<InputPinCode length={6} numericOnly={false} />
```

### States

```tsx
<InputPinCode disabled />
<InputPinCode aria-invalid />
<p className="text-sm fg_error">Verification code is invalid.</p>
```

### Controlled with onComplete

```tsx
const [value, setValue] = useState("")

<InputPinCode
  length={6}
  value={value}
  onChange={setValue}
  onComplete={(nextValue) => toast.success(`Completed: ${nextValue}`)}
/>

<Button variant="border" size="s" onClick={() => setValue("")}>
  Reset
</Button>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `length` | `number` | — |
| `value` | `string` | — |
| `onChange` | `((value: string) => void)` | — |
| `onComplete` | `((value: string) => void)` | — |
| `numericOnly` | `boolean` | — |
| `mask` | `boolean` | — |
| `separatorAfter` | `number[]` | — |
| `variant` | `"dim" \| "fill" \| "light" \| null` | — |
| `size` | `"l" \| "m" \| "s" \| null` | — |

Bảng chỉ liệt kê prop riêng của `InputPinCodeProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
