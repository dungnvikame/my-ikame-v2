# Tooltip

> Chú thích ngắn hiện khi rê chuột hoặc focus vào phần tử. Cần `TooltipProvider` ở gốc app.

```tsx
import { Tooltip } from "@coreds/react"
```

## Examples

### Positions — top / right / bottom / left

```tsx
<Tooltip content="Top tooltip" side="top">
  <Button variant="border">Top</Button>
</Tooltip>

<Tooltip content="Right tooltip" side="right">
  <Button variant="border">Right</Button>
</Tooltip>

<Tooltip content="Bottom tooltip" side="bottom">
  <Button variant="border">Bottom</Button>
</Tooltip>

<Tooltip content="Left tooltip" side="left">
  <Button variant="border">Left</Button>
</Tooltip>
```

### Alignment — start / center / end

```tsx
<Tooltip content="Aligned to start" side="bottom" align="start">
  <Button variant="border">Align start</Button>
</Tooltip>

<Tooltip content="Aligned to center" side="bottom" align="center">
  <Button variant="border">Align center</Button>
</Tooltip>

<Tooltip content="Aligned to end" side="bottom" align="end">
  <Button variant="border">Align end</Button>
</Tooltip>
```

### Title + content

```tsx
<Tooltip title="Deployment" content="The deployment was completed successfully.">
  <Button>Show details</Button>
</Tooltip>
```

### Delay duration — instant (0 ms) vs default (400 ms) vs slow (1000 ms)

```tsx
<Tooltip content="No delay" delayDuration={0}>
  <Button variant="border">Instant</Button>
</Tooltip>

<Tooltip content="Default 400 ms delay" delayDuration={400}>
  <Button variant="border">Default</Button>
</Tooltip>

<Tooltip content="1 second delay" delayDuration={1000}>
  <Button variant="border">Slow (1 s)</Button>
</Tooltip>
```

### Disabled tooltip (renders trigger as-is)

```tsx
<Tooltip content="You won't see this" disabled>
  <Button variant="border">Disabled tooltip</Button>
</Tooltip>
```

### Controlled open state

```tsx
const [open, setOpen] = useState(false)

<div className="flex items-center gap-3">
  <Tooltip content="Controlled tooltip" open={open} onOpenChange={setOpen}>
    <Button variant="border">Hover me</Button>
  </Tooltip>
  <Button size="sm" variant="subtle" onClick={() => setOpen((v) => !v)}>
    Toggle ({open ? "open" : "closed"})
  </Button>
</div>
```

### Rich content inside tooltip

```tsx
<Tooltip
  title="Keyboard shortcut"
  content={
    <span>
      Press <kbd className="font-mono bg_secondary text_primary px-1 radius_4">Ctrl</kbd> +{" "}
      <kbd className="font-mono bg_secondary text_primary px-1 radius_4">K</kbd> to open the command palette.
    </span>
  }
>
  <Button variant="border">Rich tooltip</Button>
</Tooltip>
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title` | `ReactNode` | — |  |
| `content` (required) | `ReactNode` | — |  |
| `children` (required) | `object` | — |  |
| `side` | `"bottom" \| "left" \| "right" \| "top"` | — |  |
| `align` | `"center" \| "end" \| "start"` | — |  |
| `sideOffset` | `number` | — | Gap between the tooltip and the element it describes. |
| `delayDuration` | `number` | — |  |
| `avoidCollisions` | `boolean` | — |  |
| `onOpenChange` | `((open: boolean) => void)` | — |  |

Bảng chỉ liệt kê prop riêng của `TooltipProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
