# Switch

> Công tắc bật/tắt, có hiệu lực ngay khi gạt.

```tsx
import { Switch } from "@coreds/react"
```

## Examples

### Sizes

```tsx
<Switch size="sm" checked={enabled} onCheckedChange={setEnabled} label="Small (sm)" />
<Switch size="md" checked={enabled} onCheckedChange={setEnabled} label="Medium (md) — default" />
<Switch size="lg" checked={enabled} onCheckedChange={setEnabled} label="Large (lg)" />
```

### Label positions

```tsx
<Switch checked={enabled} onCheckedChange={setEnabled} label="Right label" labelPosition="right" />
<Switch checked={enabled} onCheckedChange={setEnabled} label="Left label" labelPosition="left" />
<Switch
  checked={enabled}
  onCheckedChange={setEnabled}
  label="With description"
  description="Sends alerts to your email."
/>
```

### Disabled

```tsx
<Switch disabled label="Disabled off" />
<Switch disabled checked label="Disabled on" />
```

### Without label

```tsx
<Switch checked={enabled} onCheckedChange={setEnabled} aria-label="Toggle feature" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `description` | `string` | — |
| `size` | `"lg" \| "md" \| "sm"` | — |
| `labelPosition` | `"left" \| "right"` | — |
| `type` | `"button" \| "reset" \| "submit"` | — |
| `onCheckedChange` | `((checked: boolean) => void)` | — |

Bảng chỉ liệt kê prop riêng của `SwitchProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
