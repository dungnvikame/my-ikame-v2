# IconToggle

> Nút icon có trạng thái bật/tắt, dùng cho thanh công cụ và hành động nhanh.

```tsx
import { IconToggle, IconDropdown } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Bold` là `TextBIcon`, `Italic` là `TextItalicIcon`, `List` là `ListIcon`, `MoreHorizontal` là `DotsThreeIcon`, `Paperclip` là `PaperclipIcon`, `Send` là `PaperPlaneTiltIcon`, `Smile` là `SmileyIcon` (import từ `@coreds/react/icons`).

### IconToggle

```tsx
const [bold, setBold] = useState(true)

<IconToggle aria-label="Bold" pressed={bold} onPressedChange={setBold}>
  <Bold />
</IconToggle>
```

### Sizes

```tsx
{sizes.map((size) => <IconToggle size={size} />)}
```

### Styles

```tsx
{variants.map((variant) => <IconToggle variant={variant} />)}
```

### IconDropdown

```tsx
<IconDropdown aria-label="More actions" icon={<MoreHorizontal />} variant="border">
  <DropdownMenuItem>Edit</DropdownMenuItem>
  <DropdownMenuItem>Duplicate</DropdownMenuItem>
</IconDropdown>
```

### CommentInput

```tsx
<CommentInput
  value={comment}
  onValueChange={setComment}
  onSubmit={(value) => console.log(value)}
  avatar={<Avatar fallback="NA" size="s" />}
  actionIcons={
    <>
      <Button variant="borderlessSubtle" size="icon-s" aria-label="Emoji"><Smile /></Button>
      <Button variant="borderlessSubtle" size="icon-s" aria-label="Attach"><Paperclip /></Button>
      <Button variant="borderlessSubtle" size="icon-s" aria-label="Send"><Send /></Button>
    </>
  }
/>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `pressed` | `boolean` | — |
| `defaultPressed` | `boolean` | — |
| `onPressedChange` | `((pressed: boolean) => void)` | — |
| `type` | `"button" \| "reset" \| "submit"` | — |
| `variant` | `"border" \| "borderless" \| "borderlessSubtle" \| "dim" \| null` | — |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs" \| null` | — |

Bảng chỉ liệt kê prop riêng của `IconToggleProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
