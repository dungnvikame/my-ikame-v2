# Button

> Nút bấm cho hành động chính, phụ và nguy hiểm, có trạng thái đang tải. Kèm DropdownButton và SplitDropdownButton cho nút mở menu.

```tsx
import { Button, DropdownButton, SplitDropdownButton } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Plus` là `PlusIcon`, `Trash2` là `TrashIcon`, `Download` là `DownloadIcon`, `ArrowRight` là `ArrowRightIcon` (import từ `@coreds/react/icons`).

### Variants

```tsx
<Button>Primary</Button>
<Button variant="primary2">Primary 2</Button>
<Button variant="secondary">Secondary</Button>
<Button variant="secondary2">Secondary 2</Button>
<Button variant="dim">Dim</Button>
<Button variant="border">Border</Button>
<Button variant="subtle">Subtle</Button>
<Button variant="danger">Danger</Button>
```

### Sizes

```tsx
<Button size="xs">XS</Button>
<Button size="s">S</Button>
<Button size="m">M</Button>
<Button size="l">L</Button>
<Button size="xl">XL</Button>
```

### What a size changes

Một prop đổi cùng lúc ba thứ — chiều cao, padding ngang và bo góc — lấy thẳng từ thang kích cỡ. Đừng dùng px-* hay h-* để chỉnh lại hình dáng nút; hãy chọn kích cỡ có sẵn số đo bạn cần.

```tsx
// height / padding / radius, from the Size 5 scale
<Button size="xs">XS</Button>   // 24px / 8px  / 4px
<Button size="s">S</Button>     // 28px / 10px / 6px
<Button size="m">M</Button>     // 32px / 12px / 6px
<Button size="l">L</Button>     // 40px / 16px / 8px
<Button size="xl">XL</Button>   // 48px / 18px / 8px
```

### Sizes with an icon

Nút tự đặt kích cỡ cho icon — 12, 14, 16, 18 rồi 20px — nên ở đây bạn không cần đặt khung. Prop size của chính icon vẫn quyết định độ dày nét, và nên chọn cho khớp: xs vẽ nét 0.9px, s và m vẽ nét 1.25px. Icon 12px dùng size="xs", lớn hơn thì dùng size="s" hoặc "m", nếu không nét sẽ trông quá mảnh so với khung chứa nó. Icon có sẵn class size-* riêng thì không theo nút mà giữ khung của mình.

```tsx
// The button sets the box; size here only sets the stroke weight.
<Button size="xs"><Plus size="xs" /> Add</Button>   // 12px box, 0.9 stroke
<Button size="s"><Plus size="s" /> Add</Button>     // 14px box, 1.25
<Button size="m"><Plus size="s" /> Add</Button>     // 16px box, 1.25
<Button size="l"><Plus size="s" /> Add</Button>     // 18px box, 1.25
<Button size="xl"><Plus size="m" /> Add</Button>    // 20px box, 1.25
```

### Size holds across variants

Kích cỡ và biến thể độc lập với nhau: các nút cùng kích cỡ luôn thẳng hàng dù mỗi nút dùng cho việc gì, nên nút hành động chính có thể đặt cạnh một nút kín đáo mà hàng nút không bị lệch.

```tsx
<Button size="m">Save</Button>
<Button size="m" variant="secondary">Save as draft</Button>
<Button size="m" variant="border">Cancel</Button>
<Button size="m" variant="danger">Delete</Button>
```

### Icon sizes

```tsx
<Button size="icon-xs" aria-label="Add item"><Plus size="xs" /></Button>
<Button size="icon-s" aria-label="Add item"><Plus size={14} /></Button>
<Button size="icon-m" aria-label="Add item"><Plus size="s" /></Button>
<Button size="icon-l" aria-label="Add item"><Plus size={18} /></Button>
<Button size="icon-xl" aria-label="Add item"><Plus size="m" /></Button>
<Button size="icon-mini-m" aria-label="Add item"><Plus size="xs" /></Button>
<Button size="icon-mini-s" aria-label="Add item"><Plus size="xs" /></Button>
```

### Icon borderless subtle

```tsx
<Button variant="borderlessSubtle" size="icon-m" aria-label="Download">
  <Download size="s" />
</Button>
<Button variant="borderlessSubtle" size="icon-mini-m" aria-label="Download">
  <Download size="xs" />
</Button>
<Button variant="borderlessSubtle" size="icon-mini-s" aria-label="Download">
  <Download size="xs" />
</Button>
```

### With icons

```tsx
<Button><Plus size="s" /> Create new</Button>
<Button variant="secondary"><Download size="s" /> Export</Button>
<Button variant="danger"><Trash2 size="s" /> Delete</Button>
<Button variant="border">Continue <ArrowRight size="s" /></Button>
```

### DropdownButton

```tsx
<DropdownButton label="Primary 1">
  <DropdownMenuItem>Create task</DropdownMenuItem>
</DropdownButton>
<DropdownButton label="Primary 2" variant="primary2">
  <DropdownMenuItem>Create task</DropdownMenuItem>
</DropdownButton>
<DropdownButton label="Secondary 1" variant="secondary1">
  <DropdownMenuItem>Export CSV</DropdownMenuItem>
</DropdownButton>
<DropdownButton label="Secondary 2" variant="secondary2">
  <DropdownMenuItem>Export CSV</DropdownMenuItem>
</DropdownButton>
<DropdownButton label="Outline" variant="outline">
  <DropdownMenuItem>Duplicate</DropdownMenuItem>
</DropdownButton>
<DropdownButton label="Border" variant="border">
  <DropdownMenuItem>Archive</DropdownMenuItem>
</DropdownButton>
```

### SplitDropdownButton

```tsx
<SplitDropdownButton label="Create" onClick={handleCreate}>
  <DropdownMenuItem>Create</DropdownMenuItem>
  <DropdownMenuItem>Import</DropdownMenuItem>
</SplitDropdownButton>
```

### Loading state

```tsx
<Button loading>Saving...</Button>
<Button variant="secondary" loading>Loading</Button>
<Button size="icon-m" loading aria-label="Loading" />
```

### Disabled state

```tsx
<Button disabled>Primary</Button>
<Button variant="secondary" disabled>Secondary</Button>
<Button variant="dim" disabled>Dim</Button>
<Button variant="border" disabled>Border</Button>
<Button variant="subtle" disabled>Subtle</Button>
<Button variant="danger" disabled>Danger</Button>
```

### asChild — render as link

```tsx
<Button asChild variant="secondary">
  <a href="#">Go to docs</a>
</Button>
<Button asChild variant="border" size="s">
  <a href="#">Learn more</a>
</Button>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `size` | `"default" \| "icon-l" \| "icon-lg" \| "icon-m" \| "icon-md" \| "icon-mini-m" \| "icon-mini-s" \| "icon-s" \| "icon-sm" \| "icon-xl" \| "icon-xs" \| "l" \| "lg" \| "m" \| "s" \| "sm" \| "xl" \| "xs"` | — |
| `asChild` | `boolean` | — |
| `loading` | `boolean` | — |
| `type` | `"button" \| "reset" \| "submit"` | — |
| `variant` | `"border" \| "borderlessSubtle" \| "danger" \| "dim" \| "primary" \| "primary2" \| "secondary" \| "secondary2" \| "subtle" \| null` | — |

Bảng chỉ liệt kê prop riêng của `ButtonProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
