# DatePicker

> Ô chọn ngày, mở lịch trong popover.

```tsx
import { DatePicker } from "@coreds/react"
```

## Examples

### mode="date" (default)

```tsx
const [date, setDate] = useState<Date | null>(null)

<DatePicker
  value={date}
  onValueChange={setDate}
/>
```

### mode="time"

```tsx
<DatePicker mode="time" value={time} onValueChange={setTime} />
```

### mode="datetime" — Date & Time picker

```tsx
const [datetime, setDatetime] = useState<Date | null>(null)

<DatePicker
  mode="datetime"
  value={datetime}
  onValueChange={setDatetime}
/>
```

### Date + Time side by side

```tsx
<div className="flex gap-3">
  <DatePicker value={date} onValueChange={setDate} />
  <DatePicker mode="time" value={time} onValueChange={setTime} />
</div>
```

### Custom placeholder

```tsx
<DatePicker placeholder="Chọn ngày sinh" />
<DatePicker mode="time" placeholder="Chọn giờ họp" />
```

### Sizes

```tsx
<DatePicker size="xs" />
<DatePicker size="s" />
<DatePicker size="m" />
<DatePicker size="l" />
```

### Disabled

```tsx
<DatePicker disabled />
```

### Date Range — default with built-in presets

```tsx
const [range, setRange] = useState<DateRange>({})

<div className="space-y-3 overflow-x-auto">
  <DateRangePicker value={range} onValueChange={setRange} />
  <p className="text_tertiary text-xs">
    From: {range.from?.toLocaleDateString("en-GB") ?? "--"} |
    To: {range.to?.toLocaleDateString("en-GB") ?? "--"}
  </p>
</div>
```

### Date Range — custom presets (fiscal quarters)

```tsx
const quarterPresets = [
  { label: "Q1 2026", range: { from: new Date(2026, 0, 1), to: new Date(2026, 2, 31) } },
  { label: "Q2 2026", range: { from: new Date(2026, 3, 1), to: new Date(2026, 5, 30) } },
  { label: "Q3 2026", range: { from: new Date(2026, 6, 1), to: new Date(2026, 8, 30) } },
  { label: "Q4 2026", range: { from: new Date(2026, 9, 1), to: new Date(2026, 11, 31) } },
]

<DateRangePicker
  value={range}
  onValueChange={setRange}
  presets={quarterPresets}
/>
```

### Date Range — no presets (showPresets={false})

```tsx
<DateRangePicker
  showPresets={false}
  value={range}
  onValueChange={setRange}
/>
```

### Date Range — with min/max date (±1 month from today)

```tsx
const today = new Date()
const minDate = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate())
const maxDate = new Date(today.getFullYear(), today.getMonth() + 1, today.getDate())

<DateRangePicker
  value={range}
  onValueChange={setRange}
  minDate={minDate}
  maxDate={maxDate}
/>
```

### Date Range — disabledDates (specific dates array)

```tsx
const today = new Date()
const disabledDates = [
  new Date(today.getFullYear(), today.getMonth(), today.getDate() + 3),
  new Date(today.getFullYear(), today.getMonth(), today.getDate() + 7),
]

<DateRangePicker
  value={range}
  onValueChange={setRange}
  disabledDates={disabledDates}
/>
```

### Date Range — disabledDates (function, weekends disabled)

```tsx
<DateRangePicker
  value={range}
  onValueChange={setRange}
  disabledDates={(date) => date.getDay() === 0 || date.getDay() === 6}
/>
```

### Date Range — uncontrolled with defaultValue

```tsx
<DateRangePicker
  defaultValue={{
    from: new Date(2026, 0, 1),
    to: new Date(2026, 0, 31),
  }}
/>
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `mode` | `"date" \| "datetime" \| "time"` | — | "date" shows calendar, "time" shows time columns, "datetime" shows both |
| `value` | `Date \| null` | — |  |
| `defaultValue` | `Date \| null` | — |  |
| `onValueChange` | `((value: Date \| null) => void)` | — |  |
| `minDate` | `Date` | — |  |
| `maxDate` | `Date` | — |  |
| `disabledDates` | `Date[] \| ((date: Date) => boolean)` | — |  |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs"` | — |  |
| `variant` | `"borderless" \| "dim" \| "fill" \| "light"` | — |  |

Bảng chỉ liệt kê prop riêng của `DatePickerProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
