# DropdownMenu

> Menu thả xuống cho các hành động, có menu con, mục checkbox, radio và phím tắt.

```tsx
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
} from "@coreds/react"
```

## Examples

### Basic

```tsx
<DropdownMenu>
  <DropdownMenuTrigger asChild>
    <Button variant="border">Open menu</Button>
  </DropdownMenuTrigger>
  <DropdownMenuContent className="w-56">
    <DropdownMenuLabel>My Account</DropdownMenuLabel>
    <DropdownMenuSeparator />
    <DropdownMenuItem>Profile</DropdownMenuItem>
    <DropdownMenuItem>Billing</DropdownMenuItem>
    <DropdownMenuItem>Settings</DropdownMenuItem>
    <DropdownMenuSeparator />
    <DropdownMenuItem>Log out</DropdownMenuItem>
  </DropdownMenuContent>
</DropdownMenu>
```

### Keyboard shortcuts

```tsx
<DropdownMenu>
  <DropdownMenuTrigger asChild>
    <Button variant="border">Open shortcuts</Button>
  </DropdownMenuTrigger>
  <DropdownMenuContent className="w-56">
    <DropdownMenuItem>
      Profile
      <DropdownMenuShortcut>Shift+Cmd+P</DropdownMenuShortcut>
    </DropdownMenuItem>
    <DropdownMenuItem>
      Billing
      <DropdownMenuShortcut>Cmd+B</DropdownMenuShortcut>
    </DropdownMenuItem>
  </DropdownMenuContent>
</DropdownMenu>
```

### Submenu

```tsx
<DropdownMenu>
  <DropdownMenuTrigger asChild>
    <Button variant="border">Invite</Button>
  </DropdownMenuTrigger>
  <DropdownMenuContent className="w-56">
    <DropdownMenuSub>
      <DropdownMenuSubTrigger>Invite users</DropdownMenuSubTrigger>
      <DropdownMenuSubContent className="w-48">
        <DropdownMenuItem>Email</DropdownMenuItem>
        <DropdownMenuItem>Message</DropdownMenuItem>
        <DropdownMenuItem>Slack</DropdownMenuItem>
      </DropdownMenuSubContent>
    </DropdownMenuSub>
  </DropdownMenuContent>
</DropdownMenu>
```

### Checkbox items

```tsx
const [showToolbar, setShowToolbar] = useState(true)

<DropdownMenuCheckboxItem
  checked={showToolbar}
  onCheckedChange={(checked) => setShowToolbar(checked === true)}
>
  Show toolbar
</DropdownMenuCheckboxItem>
```

### Radio items

```tsx
const [theme, setTheme] = useState("system")

<DropdownMenuRadioGroup value={theme} onValueChange={setTheme}>
  <DropdownMenuRadioItem value="light">Light</DropdownMenuRadioItem>
  <DropdownMenuRadioItem value="dark">Dark</DropdownMenuRadioItem>
  <DropdownMenuRadioItem value="system">System</DropdownMenuRadioItem>
</DropdownMenuRadioGroup>
```

## Props

DropdownMenu bọc trực tiếp Radix DropdownMenu, nên nhận đúng các props của Radix. Xem [tài liệu Radix](https://www.radix-ui.com/primitives/docs/components/dropdown-menu).
