# App header

> Hàng tiêu đề trên nội dung của app, ghép từ Breadcrumb, Select, Input, Button và Tabs. Là cách ghép component để tham khảo, không phải component xuất từ thư viện.

Dựa trên app header của iGoal. Dùng khi app cần các điều khiển toàn cục phía trên nội dung trang. App điều hướng hoàn toàn bằng sidebar thì có thể bỏ.

## Preview

Đổi nội dung góc trái và bật, tắt hàng tab để so sánh.

## Anatomy

1. **Hàng tiện ích:** bên trái là người dùng, workspace, hoặc Breadcrumb cho trang có đường dẫn cha.
2. **Điều khiển toàn cục bên phải:** Select ngữ cảnh (vd. kỳ báo cáo), Input tìm kiếm cho cả app, và Button icon mở thông báo khi cần.
3. **Hàng Tabs (tuỳ chọn):** nằm dưới hàng tiện ích, chỉ dùng cho các vùng ngang cấp thật sự của app.
4. **Ranh giới với nội dung:** `border-b border_secondary` trên nền `bg_secondary`. Không thêm bóng trang trí.

Nội dung trong ví dụ (tên người, `Dự án / My iKame`, kỳ báo cáo, các tab) chỉ để minh hoạ. Thay bằng thông tin và điều hướng thật của app.

## Layout rules

- Header nằm trong vùng nội dung của app; sidebar có thể nằm bên cạnh.
- Dùng Breadcrumb ở góc trái khi trang có đường dẫn cha thật: các mục cha là link, mục cuối là trang hiện tại, không có link. Không có đường dẫn cha thì dùng tên người dùng hoặc workspace. Không đặt cả hai cùng chỗ.
- Các điều khiển trong cùng hàng phải cao bằng nhau. `Select size="xs"`, `Input size="xs"` và `Button size="icon-m"` cùng cao 32px trước khi nhân [hệ số X](../docs/foundations/x-factor.md). Button có chữ đặt cạnh thì chọn cùng một cỡ. Chỉnh bằng prop `size`, không ép chiều cao bằng CSS.
- Select kỳ báo cáo, Input tìm kiếm và Select thay tab trên màn hẹp dùng `variant="dim"`.
- Giới hạn độ rộng ở phần tử bọc ngoài (`w-32`, `max-w-sm`), không ghi đè bên trong component.
- Màn hẹp: để các điều khiển tự xuống dòng. Ô tìm kiếm có thể thu thành Button icon mở tìm kiếm, nhưng phải hoạt động được. Button icon nào cũng có `aria-label`.
- Màn rộng: Tabs nằm ở hàng riêng. Màn hẹp: đổi thành Select cho cùng các vùng đó, không để thanh cuộn ngang trong header.
- Trang không có vùng ngang cấp thì bỏ cả hàng Tabs lẫn Select thay thế; viền dưới của header nằm ngay dưới hàng tiện ích.
- Chữ của tab đầu và gạch chân của tab đang chọn thẳng mép trái với nội dung hàng tiện ích: bỏ padding trái của tab đầu (`first:pl-0`), và khi header đã có viền dưới thì bỏ viền của Tabs (`tabsListClassName="border-b-0"`, `triggerClassName="mb-0"`).
- Màu, bo góc và X đến từ theme đang dùng. Không viết cứng màu iGoal, logo hay dòng phụ đề.
- Giải thích thêm thì đặt trong Tooltip của một icon Info nhận được focus, chỉ khi thật cần. Hướng dẫn và lỗi phải hiện cạnh điều khiển của nó.
- Mọi Select, ô tìm kiếm, thông báo và tab đều nối với state hoặc route thật. Hành động chưa có thì ẩn hoặc tắt, không để nút bấm không làm gì.

## Usage

```tsx
import { useState } from "react"
import { Breadcrumb, Button, Input, Select, Tabs } from "@coreds/react"
import { BellIcon, MagnifyingGlassIcon } from "@coreds/react/icons"

const TABS = [
  { value: "overview", label: "Tổng quan" },
  { value: "checkpoints", label: "Checkpoint" },
  { value: "feedback", label: "Góp ý" },
]

export function AppHeader({ onNotifications }: { onNotifications: () => void }) {
  const [period, setPeriod] = useState("h2-2026")
  const [query, setQuery] = useState("")
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <header className="border-b border_secondary bg_secondary">
      <div className="flex min-h-11 flex-wrap items-center gap-3 px-6 py-2">
        {/* Không có đường dẫn cha thì thay bằng tên người dùng hoặc workspace. */}
        <Breadcrumb
          items={[{ label: "Dự án", href: "/projects" }, { label: "My iKame" }]}
          separator="/"
        />
        <div className="ml-auto flex w-full flex-wrap items-center gap-2 sm:w-auto">
          <div className="w-32">
            <Select
              aria-label="Kỳ báo cáo"
              size="xs"
              variant="dim"
              options={[
                { value: "h1-2026", label: "H1 2026" },
                { value: "h2-2026", label: "H2 2026" },
              ]}
              value={period}
              onValueChange={(value) => setPeriod(String(value))}
            />
          </div>
          <div className="w-full sm:w-72">
            <Input
              aria-label="Tìm kiếm trong ứng dụng"
              size="xs"
              variant="dim"
              leftIcon={<MagnifyingGlassIcon size="s" aria-hidden="true" />}
              placeholder="Tìm kiếm"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </div>
          <Button
            size="icon-m"
            variant="borderlessSubtle"
            aria-label="Mở thông báo"
            onClick={onNotifications}
          >
            <BellIcon aria-hidden="true" />
          </Button>
        </div>
      </div>
      <div className="px-6 pb-3 sm:hidden">
        <Select
          aria-label="Khu vực"
          size="xs"
          variant="dim"
          options={TABS}
          value={activeTab}
          onValueChange={(value) => setActiveTab(String(value))}
        />
      </div>
      <div className="hidden px-6 sm:block">
        <Tabs
          items={TABS}
          value={activeTab}
          onValueChange={setActiveTab}
          variant="underline"
          color="primary"
          tabHeight={48}
          triggerClassName="mb-0 first:pl-0"
          tabsListClassName="border-b-0"
        />
      </div>
    </header>
  )
}
```

`NotiBadge` cho số thông báo chưa đọc là tuỳ chọn, chỉ dùng khi có dữ liệu thật.
