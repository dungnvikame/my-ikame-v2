# Avatar

> Ảnh đại diện của người dùng hoặc nhóm, nhiều kích thước và hình dạng.

```tsx
import { Avatar } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Settings2` là `GearSixIcon`, `User` là `UserIcon`, `Star` là `StarIcon`, `Bell` là `BellIcon` (import từ `@coreds/react/icons`).

### Types

```tsx
{/* Image avatar */}
<Avatar type="image" size="l" src="https://example.com/photo.jpg" alt="Jane Doe" />

{/* Text / initials avatar */}
<Avatar type="text" size="l" fallback="UI" alt="UI Kit" />

{/* Icon avatar */}
<Avatar type="icon" size="l" icon={<Settings2 size="s" />} alt="Settings" />

{/* Image with broken src — falls back to initials */}
<Avatar type="image" size="l" src="broken-url" fallback="BR" alt="Broken" />
```

### Sizes

```tsx
<Avatar type="text" size="xxs" fallback="AB" alt="xxs" />
<Avatar type="text" size="xs" fallback="AB" alt="xs" />
<Avatar type="text" size="s" fallback="AB" alt="s" />
<Avatar type="text" size="m" fallback="AB" alt="m" />
<Avatar type="text" size="l" fallback="AB" alt="l" />
<Avatar type="text" size="xl" fallback="AB" alt="xl" />
```

### Icon sizes

```tsx
<Avatar type="icon" size="xxs" icon={<User size={8} />} alt="xxs" />
<Avatar type="icon" size="xs" icon={<User size={10} />} alt="xs" />
<Avatar type="icon" size="s" icon={<User size="xs" />} alt="s" />
<Avatar type="icon" size="m" icon={<User size="s" />} alt="m" />
<Avatar type="icon" size="l" icon={<User size="m" />} alt="l" />
<Avatar type="icon" size="xl" icon={<User size="l" />} alt="xl" />
```

### Image sizes

```tsx
<Avatar
  type="image"
  size="xs"
  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop"
  alt="User"
/>
<Avatar
  type="image"
  size="m"
  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop"
  alt="User"
/>
<Avatar
  type="image"
  size="xl"
  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop"
  alt="User"
/>
```

### Interactive (clickable)

```tsx
<Avatar
  type="text"
  size="l"
  fallback="JD"
  alt="Jane Doe"
  onClick={() => console.log("avatar clicked")}
/>
```

### Avatar group example

```tsx
<div className="flex -space-x-2">
  <Avatar type="image" size="m" src="https://..." alt="User 1" />
  <Avatar type="image" size="m" src="https://..." alt="User 2" />
  <Avatar type="text" size="m" fallback="AB" alt="User 3" />
  <Avatar type="text" size="m" fallback="+5" alt="5 more" />
</div>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `asChild` | `boolean` | — |
| `fallback` | `string` | — |
| `icon` | `ReactNode` | — |
| `imageProps` | `DetailedHTMLProps<ImgHTMLAttributes<HTMLImageElement>, HTMLImageElement>` | — |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs" \| "xxs" \| null` | — |
| `type` | `"icon" \| "image" \| "text" \| null` | — |

Bảng chỉ liệt kê prop riêng của `AvatarProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
