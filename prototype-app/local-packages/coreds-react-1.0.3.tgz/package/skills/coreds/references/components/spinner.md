# Spinner

> Vòng quay báo đang xử lý.

```tsx
import { Spinner } from "@coreds/react"
```

## Examples

### Sizes

```tsx
<Spinner size="xs" />
<Spinner size="sm" />
<Spinner size="md" />
<Spinner size="lg" />
<Spinner size="xl" />
```

### Variants

```tsx
{/* default — uses text_secondary token */}
<Spinner variant="default" size="lg" />

{/* primary — uses fg_accent_primary token (brand orange) */}
<Spinner variant="primary" size="lg" />

{/* white — always white, for dark backgrounds */}
<Spinner variant="white" size="lg" />

{/* inherit — inherits text color from parent */}
<span className="text-purple-600">
  <Spinner variant="inherit" size="lg" />
</span>
```

### Custom label (accessibility)

```tsx
{/* label prop sets aria-label on the svg role="status" element */}
<Spinner label="Fetching data..." />
<Spinner label="Uploading file..." variant="primary" />
<Spinner label="Processing..." size="xl" />
```

### In context — inline with text

```tsx
<div className="flex items-center gap-2 text-sm text_secondary">
  <Spinner size="sm" />
  <span>Loading your data…</span>
</div>

<div className="flex items-center gap-2 text-sm fg_accent_primary font-medium">
  <Spinner size="sm" variant="primary" />
  <span>Syncing changes…</span>
</div>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `size` | `"lg" \| "md" \| "sm" \| "xl" \| "xs" \| null` | — |
| `variant` | `"default" \| "inherit" \| "primary" \| "white" \| null` | — |

Bảng chỉ liệt kê prop riêng của `SpinnerProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
