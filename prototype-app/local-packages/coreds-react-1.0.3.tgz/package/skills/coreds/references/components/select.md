# Select

> Ô chọn một hoặc nhiều giá trị từ danh sách.

```tsx
import { Select } from "@coreds/react"
```

## Examples

### Single — searchable + clearable

```tsx
<Select
  options={frameworkOptions}
  value={single}
  onValueChange={setSingle}
  searchable
  clearable
  placeholder="Choose framework"
/>
```

### Multiple

```tsx
<Select
  options={frameworkOptions}
  value={multi}
  onValueChange={setMulti}
  multiple
  searchable
  placeholder="Choose frameworks"
/>
```

### Sizes

```tsx
<Select options={frameworkOptions} size="xs" placeholder="xs — 32px" />
<Select options={frameworkOptions} size="s"  placeholder="s  — 36px" />
<Select options={frameworkOptions} size="m"  placeholder="m  — 40px (default)" />
<Select options={frameworkOptions} size="l"  placeholder="l  — 48px" />
<Select options={frameworkOptions} size="xl" placeholder="xl — 56px" />
```

### Variants

```tsx
<Select options={frameworkOptions} variant="light" placeholder="light — default" />
<Select options={frameworkOptions} variant="fill" placeholder="fill" />
<Select options={frameworkOptions} variant="dim" placeholder="dim" />
<Select options={frameworkOptions} variant="borderless" placeholder="borderless" />
```

### Clearable

```tsx
<Select
  options={frameworkOptions}
  value={value}
  onValueChange={setValue}
  clearable
  placeholder="Select then clear"
/>
```

### Disabled

```tsx
<Select
  options={frameworkOptions}
  disabled
  placeholder="Disabled select"
/>
```

### Validation

```tsx
<Field label="Team" error="Choose a team before continuing.">
  <Select options={frameworkOptions} placeholder="Choose team" />
</Field>

<Select options={frameworkOptions} validation="error" placeholder="Choose framework" />
```

### With option descriptions and disabled option

```tsx
<Select
  options={[
    { value: "free", label: "Free", description: "Up to 3 projects" },
    { value: "pro", label: "Pro", description: "Unlimited projects" },
    { value: "enterprise", label: "Enterprise", description: "Contact sales", disabled: true },
  ]}
  placeholder="Choose plan"
/>
```

### Grouped options

```tsx
const options = [
  { value: "react", label: "React", group: "frontend" },
  { value: "vue", label: "Vue", group: "frontend" },
  { value: "express", label: "Express", group: "backend" },
  { value: "fastify", label: "Fastify", group: "backend" },
]
const groups = [
  { key: "frontend", label: "Frontend" },
  { key: "backend", label: "Backend" },
]

<Select
  options={options}
  groups={groups}
  value={value}
  onValueChange={setValue}
  placeholder="Choose technology"
/>
```

### Select user — single (long list with search)

```tsx
const userOptions = users.map((user) => ({
  value: user.id,
  label: user.name,
  description: user.email,
  icon: <Avatar size="xs" type="text" fallback={user.avatar} alt={user.name} />,
}))

<Select
  options={userOptions}
  value={selectedUser}
  onValueChange={setSelectedUser}
  searchable
  clearable
  placeholder="Chọn người dùng..."
  searchPlaceholder="Tìm kiếm theo tên hoặc email..."
  emptyMessage="Không tìm thấy người dùng"
/>
```

### Select users — multiple (long list with search)

```tsx
<Select
  options={userOptions}
  value={selectedUsers}
  onValueChange={setSelectedUsers}
  multiple
  searchable
  clearable
  placeholder="Chọn nhiều người dùng..."
  searchPlaceholder="Tìm kiếm theo tên hoặc email..."
  emptyMessage="Không tìm thấy người dùng"
  maxDisplayedTags={3}
/>
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `options` (required) | `array` | — |  |
| `groups` | `SelectGroup[]` | — |  |
| `value` | `string \| string[]` | — |  |
| `defaultValue` | `string \| string[]` | — |  |
| `onValueChange` | `((value: string \| string[]) => void)` | — |  |
| `searchable` | `boolean` | — |  |
| `clearable` | `boolean` | — |  |
| `searchPlaceholder` | `string` | — |  |
| `emptyMessage` | `string` | — |  |
| `loadingMessage` | `string` | — |  |
| `preparingMessage` | `string` | — |  |
| `onSearch` | `((query: string) => Promise<SelectOption[]>)` | — |  |
| `maxDisplayedTags` | `number` | — |  |
| `loading` | `boolean` | — |  |
| `overflowLabel` | `((count: number) => string)` | — |  |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs"` | — |  |
| `variant` | `"borderless" \| "dim" \| "fill" \| "light"` | — |  |
| `validation` | `"error"` | — |  |
| `portalContainer` | `HTMLElement \| null` | — |  |
| `menu` | `ReactNode` | — | Replaces the option list with your own content, keeping the trigger, the popup shell and its dismiss behaviour. For menus an `options` array cannot express — a tree, grouped headers, anything with its own interaction. `options` is then only used for the trigger's label. |
| `menuClassName` | `string` | — | Classes for the popup. Set a width here rather than fighting the popper from outside; the popup otherwise matches the trigger's width. |

Bảng chỉ liệt kê prop riêng của `SelectProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
