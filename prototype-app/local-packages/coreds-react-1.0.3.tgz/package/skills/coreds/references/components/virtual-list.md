# VirtualList

> Danh sách rất dài nhưng chỉ render phần đang nhìn thấy.

```tsx
import { VirtualList } from "@coreds/react"
```

## Examples

### Default virtualized list

Khi cuộn, chỉ những hàng đang hiển thị mới được mount và render.

```tsx
const items = Array.from({ length: 300 }, (_, index) => ({
+  id: "item-" + (index + 1),
+  value: "Virtual item " + (index + 1),
+}))
+
+<VirtualList
+  items={items}
+  estimateSize={48}
+  getItemKey={(item) => item.id}
+  renderItem={(item, index) => (
+    <div className="h-12 px-3 border-b border_secondary flex items-center justify-between text_tertiary text-xs">
+      <span>{item.value}</span>
+      <span>#{index + 1}</span>
+    </div>
+  )}
+/>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `items` (required) | `array` | — |
| `estimateSize` (required) | `number \| ((index: number) => number)` | — |
| `renderItem` (required) | `function` | — |
| `overscan` | `number` | — |
| `getItemKey` | `((item: T, index: number) => string \| number)` | — |

Bảng chỉ liệt kê prop riêng của `VirtualListProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
