# DateRangePicker

> Ô chọn khoảng ngày từ – đến.

```tsx
import { DateRangePicker } from "@coreds/react"
```

## Examples

### Default with built-in presets

```tsx
const [range, setRange] = useState<DateRange>({})

<div className="space-y-3 overflow-x-auto">
  <DateRangePicker value={range} onValueChange={setRange} />
  <p className="text_tertiary text-xs">
    From: {range.from?.toLocaleDateString("en-GB") ?? "--"} |
    To: {range.to?.toLocaleDateString("en-GB") ?? "--"}
  </p>
</div>
```

### Custom presets (fiscal quarters)

```tsx
const quarterPresets = [
  { label: "Q1 2026", range: { from: new Date(2026, 0, 1), to: new Date(2026, 2, 31) } },
  { label: "Q2 2026", range: { from: new Date(2026, 3, 1), to: new Date(2026, 5, 30) } },
  { label: "Q3 2026", range: { from: new Date(2026, 6, 1), to: new Date(2026, 8, 30) } },
  { label: "Q4 2026", range: { from: new Date(2026, 9, 1), to: new Date(2026, 11, 31) } },
]

<DateRangePicker
  value={range}
  onValueChange={setRange}
  presets={quarterPresets}
/>
```

### No presets — calendar only (showPresets={false})

```tsx
<DateRangePicker
  showPresets={false}
  value={range}
  onValueChange={setRange}
/>
```

### With min/max date (±1 month from today)

```tsx
const today = new Date()
const minDate = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate())
const maxDate = new Date(today.getFullYear(), today.getMonth() + 1, today.getDate())

<DateRangePicker
  value={range}
  onValueChange={setRange}
  minDate={minDate}
  maxDate={maxDate}
/>
```

### disabledDates — specific dates array

```tsx
const today = new Date()
const disabledDates = [
  new Date(today.getFullYear(), today.getMonth(), today.getDate() + 3),
  new Date(today.getFullYear(), today.getMonth(), today.getDate() + 7),
]

<DateRangePicker
  value={range}
  onValueChange={setRange}
  disabledDates={disabledDates}
/>
```

### disabledDates — function (weekends disabled)

```tsx
<DateRangePicker
  value={range}
  onValueChange={setRange}
  disabledDates={(date) => date.getDay() === 0 || date.getDay() === 6}
/>
```

### Uncontrolled with defaultValue

```tsx
<DateRangePicker
  defaultValue={{
    from: new Date(2026, 0, 1),
    to: new Date(2026, 0, 31),
  }}
/>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `value` | `DateRange` | — |
| `defaultValue` | `DateRange` | — |
| `onValueChange` | `((range: DateRange) => void)` | — |
| `presets` | `DateRangePreset[]` | — |
| `showPresets` | `boolean` | — |
| `minDate` | `Date` | — |
| `maxDate` | `Date` | — |
| `disabledDates` | `Date[] \| ((date: Date) => boolean)` | — |

Bảng chỉ liệt kê prop riêng của `DateRangePickerProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
