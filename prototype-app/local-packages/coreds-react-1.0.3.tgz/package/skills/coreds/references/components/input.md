# Input

> Ô nhập văn bản một dòng. NumberInput dành cho số, có định dạng hàng nghìn.

```tsx
import { Input, NumberInput } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `CheckCircle` là `CheckCircleIcon`, `Mail` là `EnvelopeIcon`, `Search` là `MagnifyingGlassIcon` (import từ `@coreds/react/icons`).

### Variants

```tsx
<Input variant="light" placeholder="light" />
<Input variant="fill" placeholder="fill" />
<Input variant="dim" placeholder="dim" />
<Input variant="borderless" placeholder="borderless" />
```

### Sizes

```tsx
<Input size="xs" placeholder="xs" />
<Input size="s" placeholder="s" />
<Input size="m" placeholder="m" />
<Input size="l" placeholder="l" />
<Input size="xl" placeholder="xl" />
```

### States

```tsx
<Input placeholder="Normal" />
<Input defaultValue="With value" />
<Input type="password" defaultValue="secret" />
<Input disabled placeholder="Disabled" />
```

### Validation

```tsx
<Input validation="error" placeholder="Enter email" />
<Input validation="success" defaultValue="you@example.com" />
<Input aria-invalid defaultValue="bad-value" />
```

### With field

```tsx
<Field label="Email address" supportingText="We will never share your email.">
  <Input placeholder="you@example.com" type="email" />
</Field>

<Field label="Username" error="Username can only contain letters and numbers.">
  <Input defaultValue="bad user!" />
</Field>
```

### Adornments

```tsx
<Input leftIcon={<Search />} placeholder="Search..." />
<Input rightIcon={<CheckCircle />} defaultValue="Available" validation="success" />
<Input leftIcon={<Mail />} unit="@ikameglobal.com" placeholder="username" />
```

### NumberInput

```tsx
const [amount, setAmount] = useState<number | null>(24000000)

<NumberInput value={amount} onValueChange={setAmount} />
<NumberInput variant="fill" size="s" unit="/ 24.000.000" min={0} max={24000000}
  value={progress} onValueChange={setProgress} />
```

## Props

### InputProps

| Prop | Type | Default |
| --- | --- | --- |
| `leftIcon` | `ReactNode` | — |
| `rightIcon` | `ReactNode` | — |
| `unit` | `ReactNode` | — |
| `autoComplete` | `HTMLInputAutoCompleteAttribute` | — |
| `type` | `HTMLInputTypeAttribute` | — |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs" \| null` | — |
| `variant` | `"borderless" \| "dim" \| "fill" \| "light" \| null` | — |
| `validation` | `"error" \| "success" \| null` | — |

Bảng chỉ liệt kê prop riêng của `InputProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

### NumberInputProps

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `value` (required) | `number \| null` | — | The number shown; `null` for an empty field. |
| `onValueChange` (required) | `function` | — | Called with every parsable change, and `null` when the field is cleared. |
| `locale` | `string` | — | Decides the group and decimal marks. Default `"vi-VN"`: 24.000.000,5 |
| `maximumFractionDigits` | `number` | — | Decimals the author may type; `0` allows whole numbers only. Default `2`. |
| `min` | `number` | — | Applied when the field is left, so a half-typed number is never cut short. |
| `max` | `number` | — |  |
| `autoComplete` | `HTMLInputAutoCompleteAttribute` | — |  |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs" \| null` | — |  |
| `variant` | `"borderless" \| "dim" \| "fill" \| "light" \| null` | — |  |
| `validation` | `"error" \| "success" \| null` | — |  |
| `leftIcon` | `ReactNode` | — |  |
| `rightIcon` | `ReactNode` | — |  |
| `unit` | `ReactNode` | — |  |

Bảng chỉ liệt kê prop riêng của `NumberInputProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
