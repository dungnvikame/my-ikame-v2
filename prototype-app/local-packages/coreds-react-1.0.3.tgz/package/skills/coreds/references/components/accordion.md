# Accordion

> Các mục thu gọn và mở rộng, để chứa nội dung dài trong không gian hẹp.

```tsx
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@coreds/react"
```

## Examples

### Single — collapsible

```tsx
<Accordion type="single" collapsible defaultValue="item-1">
  <AccordionItem value="item-1">
    <AccordionTrigger>What is included?</AccordionTrigger>
    <AccordionContent>Core components, tokens, and composable primitives.</AccordionContent>
  </AccordionItem>
  <AccordionItem value="item-2">
    <AccordionTrigger>How do updates work?</AccordionTrigger>
    <AccordionContent>New versions are published through semantic release workflows.</AccordionContent>
  </AccordionItem>
</Accordion>
```

### Multiple open at once

```tsx
<Accordion type="multiple" defaultValue={["multi-1", "multi-3"]}>
  <AccordionItem value="multi-1">
    <AccordionTrigger>Design tokens</AccordionTrigger>
    <AccordionContent>Tokenized CSS classes keep visuals consistent across all apps.</AccordionContent>
  </AccordionItem>
  <AccordionItem value="multi-2">
    <AccordionTrigger>Accessibility baseline</AccordionTrigger>
    <AccordionContent>Components ship with keyboard and screen-reader friendly behavior.</AccordionContent>
  </AccordionItem>
  <AccordionItem value="multi-3">
    <AccordionTrigger>Theming</AccordionTrigger>
    <AccordionContent>Light and dark modes are supported via CSS variable overrides.</AccordionContent>
  </AccordionItem>
</Accordion>
```

### Card variant

```tsx
<Accordion type="multiple" variant="card" defaultValue={["card-1"]}>
  <AccordionItem value="card-1">
    <AccordionTrigger>Design system alignment</AccordionTrigger>
    <AccordionContent>Tokenized classes keep visuals consistent across apps.</AccordionContent>
  </AccordionItem>
  <AccordionItem value="card-2">
    <AccordionTrigger>Accessibility baseline</AccordionTrigger>
    <AccordionContent>Components ship with keyboard and screen-reader friendly behavior.</AccordionContent>
  </AccordionItem>
</Accordion>
```

### Disabled item

```tsx
<Accordion type="single" collapsible>
  <AccordionItem value="enabled-1">
    <AccordionTrigger>Available feature</AccordionTrigger>
    <AccordionContent>This item can be expanded and collapsed.</AccordionContent>
  </AccordionItem>
  <AccordionItem value="disabled-item" disabled>
    <AccordionTrigger>Restricted feature</AccordionTrigger>
    <AccordionContent>This content is not reachable.</AccordionContent>
  </AccordionItem>
  <AccordionItem value="enabled-2">
    <AccordionTrigger>Another available feature</AccordionTrigger>
    <AccordionContent>This item is also interactive.</AccordionContent>
  </AccordionItem>
</Accordion>
```

### Controlled accordion

```tsx
const [value, setValue] = useState("controlled-1")

<div className="space-y-3">
  <p className="text_tertiary text-xs">Open item: <span className="font-mono">{value ?? "none"}</span></p>
  <Accordion type="single" collapsible value={value} onValueChange={setValue}>
    <AccordionItem value="controlled-1">
      <AccordionTrigger>First section</AccordionTrigger>
      <AccordionContent>Controlled by external state.</AccordionContent>
    </AccordionItem>
    <AccordionItem value="controlled-2">
      <AccordionTrigger>Second section</AccordionTrigger>
      <AccordionContent>Toggle this from outside too.</AccordionContent>
    </AccordionItem>
  </Accordion>
</div>
```

## Props

Accordion bọc trực tiếp Radix Accordion, nên nhận đúng các props của Radix. Xem [tài liệu Radix](https://www.radix-ui.com/primitives/docs/components/accordion).
