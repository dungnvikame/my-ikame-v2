# Checkbox

> Ô đánh dấu cho lựa chọn bật/tắt hoặc chọn nhiều mục.

```tsx
import { Checkbox } from "@coreds/react"
```

## Examples

### Basic

```tsx
<Checkbox label="Uncontrolled" />
<Checkbox label="Controlled" checked={checked} onCheckedChange={(v) => setChecked(v === true)} />
<Checkbox label="Indeterminate" checked="indeterminate" />
<Checkbox label="Disabled unchecked" disabled />
<Checkbox label="Disabled checked" checked disabled />
```

### Sizes

```tsx
<Checkbox size="sm" label="Small (sm)" />
<Checkbox size="md" label="Medium (md) — default" />
<Checkbox size="lg" label="Large (lg)" />
```

### With description

```tsx
<Checkbox
  label="Email notifications"
  description="Receive updates about your projects and releases."
  checked={checked}
  onCheckedChange={(v) => setChecked(v === true)}
/>
```

### Indeterminate — parent / children pattern

```tsx
{/* Parent uses checked="indeterminate" when children are partially selected */}
<Checkbox
  label="Select all"
  checked="indeterminate"
  onCheckedChange={() => {}}
/>
<div className="ml-6 space-y-2">
  <Checkbox label="Option A" checked />
  <Checkbox label="Option B" />
</div>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `description` | `string` | — |
| `size` | `"lg" \| "md" \| "sm"` | — |
| `type` | `"button" \| "reset" \| "submit"` | — |
| `checked` | `CheckboxPrimitive.CheckedState` | — |
| `defaultChecked` | `CheckboxPrimitive.CheckedState` | — |
| `onCheckedChange` | `((checked: CheckboxPrimitive.CheckedState) => void)` | — |

Bảng chỉ liệt kê prop riêng của `CheckboxProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
