# DataTable

> Bảng dữ liệu có sắp xếp, lọc, chọn hàng, mở rộng hàng và phân trang.

```tsx
import { DataTable } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Pencil` là `PencilIcon`, `Trash2` là `TrashIcon` (import từ `@coreds/react/icons`).

### Basic

Cấu hình tối thiểu: data, columns, getRowKey.

```tsx
<DataTable
  data={employees.slice(0, 5)}
  columns={columns}
  getRowKey={(row) => row.id}
/>
```

### Sorting

Bấm vào tiêu đề cột có bật sắp xếp để sắp xếp theo cột đó. Bấm lần hai để đảo chiều, lần ba để bỏ sắp xếp.

```tsx
const columns = [
  { id: "name",   accessorKey: "name",   sortable: true },
  { id: "salary", accessorKey: "salary", sortable: true },
]

<DataTable
  data={employees}
  columns={columns}
  defaultSort={{ key: "salary", direction: "desc" }}
  getRowKey={(row) => row.id}
/>
```

### Controlled Sort

Quản lý trạng thái sắp xếp từ bên ngoài. Hữu ích cho nút đặt lại và điều hướng bằng code.

```tsx
const [sort, setSort] = useState(null)

<div className="flex gap-2">
  <Button onClick={() => setSort({ key: "name", direction: "asc" })}>Name A→Z</Button>
  <Button onClick={() => setSort({ key: "salary", direction: "desc" })}>Salary High→Low</Button>
  <Button onClick={() => setSort(null)} disabled={!sort}>Clear</Button>
</div>

<DataTable
  data={employees}
  columns={columns}
  sort={sort}
  onSortChange={setSort}
  getRowKey={(row) => row.id}
/>
```

### Filtering

Cột Name và Role lọc theo chữ, cột Department và Status lọc bằng select.

```tsx
const columns = [
  { id: "name",       accessorKey: "name",       filterable: true, filterType: "text" },
  { id: "department", accessorKey: "department", filterable: true, filterType: "select", filters: [...] },
]

<DataTable data={employees} columns={columns} getRowKey={(row) => row.id} />
```

### Row Selection - Checkbox

Chọn nhiều hàng, có ô chọn tất cả. Các hàng ở trạng thái Inactive và Probation không chọn được.

```tsx
<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  rowSelection={{
    selectedRowKeys,
    onChange: (keys) => setSelectedKeys(keys),
    getCheckboxProps: (row) => ({
      disabled: row.status === "inactive" || row.status === "probation",
    }),
  }}
/>
```

### Row Selection - Radio

Chọn một hàng bằng nút radio.

```tsx
<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  rowSelection={{ type: "radio" }}
/>
```

### Custom Cell Rendering

Trong ô có badge, số tiền đã định dạng, avatar chữ cái viết tắt và các nút thao tác.

```tsx
const columns = [
  {
    id: "name",
    header: "Employee",
    accessorKey: "name",
    cell: (row) => (
      <div className="flex items-center gap-3">
        <Avatar>{getInitials(row.name)}</Avatar>
        <span>{row.name}</span>
      </div>
    ),
  },
  {
    id: "status",
    header: "Status",
    accessorKey: "status",
    cell: (row) => <Badge variant={STATUS_META[row.status].variant}>{row.status}</Badge>,
  },
]
```

### Clickable Rows

onRow trả về các hàm xử lý sự kiện gắn vào từng tr. Hỗ trợ click, dblclick, contextmenu, mouseenter, mouseleave.

```tsx
<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  onRow={(row) => ({
    onClick: () => setClickedId(row.id),
  })}
/>
```

### Pagination

Phân trang có sẵn, kèm ô chọn số hàng mỗi trang và tổng số bản ghi.

```tsx
<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  pagination={{
    pageIndex,
    pageSize,
    total: 20,
    onChange: (page, size) => setPagination({ pageIndex: page, pageSize: size }),
    pageSizeOptions: [5, 10, 20],
    showSizeSelector: true,
    showTotal: true,
  }}
/>
```

### Server-side (Remote) Data

manual: true tắt phân trang phía client. Dữ liệu và trạng thái loading do bên ngoài điều khiển.

```tsx
<DataTable
  data={rows}
  columns={columns}
  getRowKey={(row) => row.id}
  loading={loading}
  pagination={{
    pageIndex,
    pageSize,
    total,
    onChange,
    manual: true,
  }}
/>
```

### Fixed Header + Scroll

stickyHeader giữ header luôn hiển thị. scroll.y đặt chiều cao của khung chứa.

```tsx
<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  stickyHeader
  scroll={{ y: 300 }}
/>
```

### Column Pinning

pin: left / right giữ cột cố định khi cuộn ngang.

```tsx
const columns = [
  { id: "name",   accessorKey: "name",   pin: "left",  width: 200 },
  { id: "salary", accessorKey: "salary", pin: "right", width: 160 },
  // ... middle columns scroll freely
]

<DataTable data={employees} columns={columns} getRowKey={(row) => row.id} scroll={{ x: 1200 }} />
```

### Summary Row

summary hiển thị một hàng tfoot chứa các giá trị tổng hợp.

```tsx
<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  summary={(rows) => (
    <tr>
      <td>Total:</td>
      <td>{new Set(rows.map((r) => r.department)).size} depts</td>
      <td className="text-right">{formatSalary(rows.reduce((s, r) => s + r.salary, 0))}</td>
    </tr>
  )}
/>
```

### Expandable Rows

expandedRowRender hiển thị nội dung chi tiết. rowExpandable quyết định hàng nào được mở rộng.

```tsx
<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  expandable={{
    expandedRowRender: (row) => <EmployeeDetails row={row} />,
    rowExpandable: (row) => row.status !== "inactive",
  }}
/>
```

### Column Visibility

Truyền columnVisibility để quyết định cột nào được hiển thị. Bật/tắt bằng các nút điều khiển bên ngoài.

```tsx
const [columnVisibility, setColumnVisibility] = useState({
  name: true, role: true, salary: false,
})

<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  columnVisibility={columnVisibility}
/>
```

### Virtual Scroll (1000 rows)

virtual chỉ render những hàng đang hiển thị, phù hợp với tập dữ liệu lớn. Cần có scroll.y.

```tsx
<DataTable
  data={virtualData}   // 1000 rows
  columns={columns}
  getRowKey={(row) => row.id}
  virtual
  stickyHeader
  scroll={{ y: 400 }}
/>
```

### Loading and Empty States

loading hiện spinner phủ lên bảng. emptyMessage tùy chỉnh nội dung khi không có kết quả.

```tsx
<DataTable data={[]} columns={columns} loading getRowKey={(row) => row.id} />

<DataTable
  data={[]}
  columns={columns}
  getRowKey={(row) => row.id}
  emptyMessage="No employees found matching your search."
/>
```

### Size and Visual Variants

So sánh các kiểu compact, bordered, striped và mặc định đặt cạnh nhau.

```tsx
<DataTable size="compact" bordered ... />
<DataTable striped stickyHeader ... />
<DataTable ... />
```

### Grouped Headers + Tree Data

columns.columns tạo các nhóm header lồng nhau. getSubRows + expandTrigger hiển thị các hàng dạng cây có thể mở rộng.

```tsx
const quarterGroup = (label, q) => ({
  id: q,
  header: label,
  columns: [
    { id: `${q}_target`, header: "Target", accessorKey: `${q}_target` },
    { id: `${q}_actual`, header: "Actual", accessorKey: `${q}_actual` },
    { id: `${q}_need`,   header: "Need",   accessorKey: `${q}_need`,   groupBorder: true },
  ],
})

const columns = [
  { id: "position", header: "Position", expandTrigger: true, pin: "left" },
  quarterGroup("Q1", "q1"),
  quarterGroup("Q2", "q2"),
]

<DataTable
  data={hiringData}
  columns={columns}
  getSubRows={(row) => row.subRows}
  getRowKey={(row) => row.id}
  defaultExpandedRowIds={["ikame-games", "ikame-apps"]}
  bordered
/>
```

### Grouped Headers

Nhóm cột lồng nhau, không mở rộng hàng — so sánh ngân sách theo quý.

```tsx
const columns = [
  { id: "department", header: "Department", pin: "left", sortable: true },
  {
    id: "q1", header: "Q1",
    columns: [
      { id: "q1_plan",   header: "Plan",   accessorKey: "q1_plan",   align: "right" },
      { id: "q1_actual", header: "Actual", accessorKey: "q1_actual", align: "right" },
      { id: "q1_delta",  header: "Delta",  accessorKey: "q1_delta",  align: "right", cell: deltaCell },
    ],
  },
  // Q2, Q3, Q4 ...
]
```

### Deep Tree (Org Chart)

getSubRows hiển thị các hàng lồng nhau 3 cấp. defaultExpanded mở rộng tất cả. Các cột sắp xếp được vẫn hoạt động ở mọi cấp của cây.

```tsx
<DataTable
  data={orgData}
  columns={columns}
  getSubRows={(row) => row.subRows}
  getRowKey={(row) => row.id}
  defaultExpanded
  bordered
  stickyHeader
/>
```

### Column Resize

Đặt resizable: true trong định nghĩa cột để hiện tay kéo. Các cột không đặt thuộc tính này giữ cố định.

```tsx
const columns = [
  { id: "department", accessorKey: "department", width: 180, resizable: true },
  { id: "q1_plan",    accessorKey: "q1_plan",    width: 130, resizable: true },
  { id: "q2_plan",    accessorKey: "q2_plan",    width: 130 },  // not resizable
]

<DataTable data={data} columns={columns} getRowKey={(row) => row.id} bordered />
```

### Multi-sort

multiSort cho phép Shift+click để thêm tiêu chí sắp xếp phụ. onMultiSortChange được gọi mỗi khi thay đổi sắp xếp.

```tsx
const [sorts, setSorts] = useState([])

<DataTable
  data={employees}
  columns={columns}
  getRowKey={(row) => row.id}
  defaultSort={{ key: "salary", direction: "desc" }}
  multiSort
  onMultiSortChange={setSorts}
  bordered
/>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `data` (required) | `array` | — |
| `columns` (required) | `array` | — |
| `getRowKey` | `((row: T, index: number) => string)` | — |
| `loading` | `boolean` | — |
| `emptyMessage` | `ReactNode` | — |
| `bordered` | `boolean` | — |
| `striped` | `boolean` | — |
| `size` | `"compact" \| "default"` | — |
| `stickyHeader` | `boolean` | — |
| `scroll` | `{ x?: number \| string; y?: number \| string; }` | — |
| `defaultSort` | `DataTableSortValue` | — |
| `sort` | `DataTableSortValue \| null` | — |
| `onSortChange` | `((sort: DataTableSortValue \| null) => void)` | — |
| `multiSort` | `boolean` | — |
| `onFilterChange` | `((filters: Record<string, unknown>) => void)` | — |
| `rowSelection` | `DataTableRowSelectionConfig<T>` | — |
| `expandable` | `DataTableExpandableConfig<T>` | — |
| `getSubRows` | `((row: T) => T[] \| undefined)` | — |
| `defaultExpanded` | `boolean` | — |
| `defaultExpandedRowIds` | `string[]` | — |
| `pagination` | `false \| DataTablePaginationConfig` | — |
| `columnVisibility` | `Record<string, boolean>` | — |
| `onColumnVisibilityChange` | `((visibility: Record<string, boolean>) => void)` | — |
| `summary` | `((data: T[]) => ReactNode)` | — |
| `onRow` | `((row: T) => Pick<HTMLAttributes<HTMLTableRowElement>, "onClick" \| "onDoubleClick" \| "onMouseEnter" \| "onMouseLeave" \| "onContextMenu">)` | — |
| `virtual` | `boolean` | — |
| `onMultiSortChange` | `((sorts: DataTableSortValue[]) => void)` | — |

Bảng chỉ liệt kê prop riêng của `DataTableProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
