# SegmentedControl

> Nhóm nút liền nhau để chuyển giữa vài lựa chọn ngang hàng.

```tsx
import { SegmentedControl } from "@coreds/react"
```

## Examples

### Sizes

```tsx
<SegmentedControl options={options} value={value} onValueChange={setValue} size="xs" />
<SegmentedControl options={options} value={value} onValueChange={setValue} size="s" />
<SegmentedControl options={options} value={value} onValueChange={setValue} size="m" />
<SegmentedControl options={options} value={value} onValueChange={setValue} size="l" />
```

### Controlled usage

```tsx
const [view, setView] = useState("week")

<SegmentedControl
  options={[
    { value: "day", label: "Day" },
    { value: "week", label: "Week" },
    { value: "month", label: "Month" },
  ]}
  value={view}
  onValueChange={setView}
/>
<p>Selected: {view}</p>
```

### With disabled option

```tsx
<SegmentedControl
  options={[
    { value: "list", label: "List" },
    { value: "board", label: "Board" },
    { value: "calendar", label: "Calendar", disabled: true },
  ]}
  value={value}
  onValueChange={setValue}
/>
```

### Entirely disabled

```tsx
<SegmentedControl
  options={options}
  value="week"
  disabled
/>
```

### Uncontrolled (defaultValue)

```tsx
<SegmentedControl
  options={options}
  defaultValue="month"
  onValueChange={(v) => console.log(v)}
/>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `options` (required) | `array` | — |
| `value` | `string` | — |
| `defaultValue` | `string` | — |
| `onValueChange` | `((value: string) => void)` | — |
| `size` | `"l" \| "m" \| "s" \| "xs"` | — |

Bảng chỉ liệt kê prop riêng của `SegmentedControlProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
