# Chip

> Thẻ nhỏ để lọc, chuyển tab, hiển thị thông tin hoặc nhập nhiều giá trị.

```tsx
import { Chip, FilterChipRadioGroup, InfoChip, InputChip, TabChip } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Filter` là `FunnelIcon`, `Info` là `InfoIcon`, `Search` là `MagnifyingGlassIcon`, `User` là `UserIcon` (import từ `@coreds/react/icons`).

### Tag chip — default (neutral)

```tsx
<Chip>Label</Chip>
<Chip>Another</Chip>
```

### Tag and selector chip - radius and pill

```tsx
<Chip color="blue">Default radius</Chip>
<Chip color="blue" pill>Round</Chip>
<Chip variant="selector" options={options} placeholder="Status" />
```

### Tag chip — color palette (bordered)

```tsx
<Chip color="gray">Gray</Chip>
<Chip color="orange">Orange</Chip>
<Chip color="amber">Amber</Chip>
<Chip color="yellow">Yellow</Chip>
<Chip color="lime">Lime</Chip>
<Chip color="green">Green</Chip>
<Chip color="emerald">Emerald</Chip>
<Chip color="teal">Teal</Chip>
<Chip color="cyan">Cyan</Chip>
<Chip color="sky">Sky</Chip>
<Chip color="blue">Blue</Chip>
<Chip color="indigo">Indigo</Chip>
<Chip color="violet">Violet</Chip>
<Chip color="purple">Purple</Chip>
<Chip color="fuchsia">Fuchsia</Chip>
<Chip color="pink">Pink</Chip>
<Chip color="red">Red</Chip>
```

### Tag chip — transparent

```tsx
<Chip color="transparent">Ghost</Chip>
<Chip color="transparent" bordered={false}>No border</Chip>
```

### Tag chip — no border

```tsx
<Chip color="blue" bordered={false}>Blue</Chip>
<Chip color="green" bordered={false}>Green</Chip>
<Chip color="red" bordered={false}>Red</Chip>
```

### Tag chip — with remove button (onRemove on any variant)

```tsx
<Chip color="blue" onRemove={() => {}}>Blue tag</Chip>
<Chip color="green" onRemove={() => {}}>Green tag</Chip>
```

### Tag chip — sizes

```tsx
<Chip size="xs" color="blue">XS</Chip>
<Chip size="s" color="blue">S</Chip>
<Chip size="m" color="blue">M</Chip>
<Chip size="l" color="blue">L</Chip>
<Chip size="xl" color="blue">XL</Chip>
```

### Selector chip — click to open dropdown

```tsx
<Chip
  variant="selector"
  icon={<Filter />}
  options={options}
  value={createdBy}
  onValueChange={setCreatedBy}
  placeholder="Created by"
/>
```

### Selector chip — long options list (scrollable, max-height 240px)

```tsx
<Chip
  variant="selector"
  options={folderOptions} // 20 items
  value={folder}
  onValueChange={setFolder}
  searchable
  placeholder="Folder"
/>
```

### Selector chip — clearable (hover chip with value to reveal × clear)

```tsx
<Chip
  variant="selector"
  icon={<Filter />}
  options={options}
  value={createdBy}
  onValueChange={setCreatedBy}
  clearable
  placeholder="Created by"
/>
```

### Selector chip — labelMode "append" (shows placeholder: value)

```tsx
<Chip
  variant="selector"
  icon={<Filter />}
  options={options}
  value={createdBy}
  onValueChange={setCreatedBy}
  labelMode="append"
  placeholder="Created by"
/>
```

### Selector chip — sizes

```tsx
<Chip variant="selector" size="xs" options={[]} placeholder="XS" />
<Chip variant="selector" size="s" options={[]} placeholder="S" />
<Chip variant="selector" size="m" options={[]} placeholder="M" />
<Chip variant="selector" size="l" options={[]} placeholder="L" />
<Chip variant="selector" size="xl" options={[]} placeholder="XL" />
```

### Check chip — click to toggle (multi-select)

```tsx
<Chip
  variant="check"
  icon={<Filter />}
  selected={selected}
  onClick={() => setSelected(v => !v)}
>
  Option A
</Chip>
```

### Check chip — borderless selected (bordered={false})

```tsx
<Chip
  variant="check"
  bordered={false}
  selected={selected}
  onClick={() => toggle()}
>
  Option
</Chip>
```

### Check chip — sizes

```tsx
<Chip variant="check" size="xs">XS</Chip>
<Chip variant="check" size="s">S</Chip>
<Chip variant="check" size="m">M</Chip>
<Chip variant="check" size="l">L</Chip>
<Chip variant="check" size="xl">XL</Chip>
```

### FilterChipRadio - radiogroup keyboard selection

```tsx
<FilterChipRadioGroup
  aria-label="Status"
  options={statusOptions}
  value={statusFilter}
  onValueChange={setStatusFilter}
/>
```

### TabChip - aria-pressed active state

```tsx
<TabChip active={tab === "overview"} onClick={() => setTab("overview")}>
  Overview
</TabChip>
<TabChip display="iconOnly" aria-label="Search" icon={<Search />} />
```

### TabChip — sizes

```tsx
<TabChip size="xs">XS</TabChip>
<TabChip size="s">S</TabChip>
<TabChip size="m">M</TabChip>
<TabChip size="l">L</TabChip>
<TabChip size="xl">XL</TabChip>
```

### FilterChipRadio — sizes

```tsx
<FilterChipRadioGroup size="xs" aria-label="xs" options={sizeOptions} defaultValue="a" />
<FilterChipRadioGroup size="s" aria-label="s" options={sizeOptions} defaultValue="a" />
<FilterChipRadioGroup size="m" aria-label="m" options={sizeOptions} defaultValue="a" />
<FilterChipRadioGroup size="l" aria-label="l" options={sizeOptions} defaultValue="a" />
<FilterChipRadioGroup size="xl" aria-label="xl" options={sizeOptions} defaultValue="a" />
```

### InfoChip - fill, light, and icon mini close

```tsx
<InfoChip icon={<Info />} onClose={() => setVisible(false)}>
  Synced
</InfoChip>
<InfoChip variant="light">Draft saved</InfoChip>
```

### InfoChip — sizes

```tsx
<InfoChip size="xs" icon={<Info />} onClose={() => {}}>XS</InfoChip>
<InfoChip size="s" icon={<Info />} onClose={() => {}}>S</InfoChip>
<InfoChip size="m" icon={<Info />} onClose={() => {}}>M</InfoChip>
<InfoChip size="l" icon={<Info />} onClose={() => {}}>L</InfoChip>
<InfoChip size="xl" icon={<Info />} onClose={() => {}}>XL</InfoChip>
```

### InputChip - value, avatar, and icon mini close

```tsx
<InputChip type="avatar" avatarProps={{ fallback: "NP" }} onRemove={() => {}}>
  Nguyen Phuong Anh
</InputChip>
<InputChip icon={<User />} onRemove={() => {}}>No avatar</InputChip>
```

### Removable chips - onRemove works on any variant (click X to remove)

```tsx
<Chip variant="tag" icon={<User />} onRemove={() => removeItem(name)}>
  Nguyen Phuong Anh
</Chip>
```

### InputChip — sizes

```tsx
<InputChip size="xs" onRemove={() => {}}>XS</InputChip>
<InputChip size="s" onRemove={() => {}}>S</InputChip>
<InputChip size="m" onRemove={() => {}}>M</InputChip>
<InputChip size="l" onRemove={() => {}}>L</InputChip>
<InputChip size="xl" onRemove={() => {}}>XL</InputChip>
```

## Props

### ChipProps

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs"` | — |  |
| `pill` | `boolean` | — |  |
| `options` | `ChipOption[]` | — |  |
| `value` | `string` | — |  |
| `onValueChange` | `((value: string) => void)` | — |  |
| `searchable` | `boolean` | — |  |
| `clearable` | `boolean` | — |  |
| `labelMode` | `"append" \| "replace"` | — |  |
| `icon` | `ReactNode` | — |  |
| `onRemove` | `(() => void)` | — |  |
| `menu` | `ReactNode` | — | Replaces the selector's option list with your own content, keeping the chip trigger, the popup shell and its dismiss behaviour. Named `menu` rather than `children` because children is the chip's own label. `options` is then only used for the label the chip shows. |
| `menuClassName` | `string` | — | Classes for the popup — set a width here rather than reaching into the popper from outside. |
| `portal` | `boolean` | — | Forwarded to the selector's Popover. Turn off to render in place instead of portalling. |
| `portalContainer` | `HTMLElement \| null` | — | Where the selector's menu mounts. Without this a chip inside a Dialog portals its menu to `document.body`, outside the Dialog, and the Dialog's focus trap closes it as soon as it opens. Pass the Dialog element to keep the menu inside it. |
| `variant` | `"check" \| "selector" \| "tag" \| null` | — |  |
| `chipType` | `"borderFill" \| "borderLight" \| "borderless" \| null` | — |  |
| `color` | `"amber" \| "blue" \| "cyan" \| "emerald" \| "fuchsia" \| "gray" \| "green" \| "indigo" \| "lime" \| "orange" \| "pink" \| "purple" \| "red" \| "sky" \| "teal" \| "transparent" \| "violet" \| "white" \| "yellow" \| null` | — |  |
| `bordered` | `boolean \| null` | — |  |

Bảng chỉ liệt kê prop riêng của `ChipProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

### FilterChipRadioGroupProps

| Prop | Type | Default |
| --- | --- | --- |
| `options` (required) | `array` | — |
| `value` | `string` | — |
| `defaultValue` | `string` | — |
| `onValueChange` | `((value: string) => void)` | — |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs"` | — |
| `bordered` | `boolean` | — |
| `chipType` | `"borderFill" \| "borderLight" \| "borderless"` | — |

Bảng chỉ liệt kê prop riêng của `FilterChipRadioGroupProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

### TabChipProps

| Prop | Type | Default |
| --- | --- | --- |
| `active` | `boolean` | — |
| `display` | `"full" \| "iconOnly"` | — |
| `color` | `"fill" \| "subtle"` | — |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs"` | — |
| `pill` | `boolean` | — |
| `icon` | `ReactNode` | — |
| `type` | `"button" \| "reset" \| "submit"` | — |

Bảng chỉ liệt kê prop riêng của `TabChipProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

### InfoChipProps

| Prop | Type | Default |
| --- | --- | --- |
| `variant` | `"fill" \| "light"` | — |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs"` | — |
| `icon` | `ReactNode` | — |
| `showClose` | `boolean` | — |
| `closeAriaLabel` | `string` | — |
| `onClose` | `(() => void)` | — |

Bảng chỉ liệt kê prop riêng của `InfoChipProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

### InputChipProps

| Prop | Type | Default |
| --- | --- | --- |
| `type` | `"avatar" \| "value"` | — |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs"` | — |
| `icon` | `ReactNode` | — |
| `avatar` | `ReactNode` | — |
| `avatarProps` | `AvatarProps` | — |
| `showClose` | `boolean` | — |
| `closeAriaLabel` | `string` | — |
| `onRemove` | `(() => void)` | — |

Bảng chỉ liệt kê prop riêng của `InputChipProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
