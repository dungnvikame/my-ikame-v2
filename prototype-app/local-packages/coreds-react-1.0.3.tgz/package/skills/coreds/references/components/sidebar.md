# Sidebar

> Thanh điều hướng bên của app: nhóm mục, mục con, thu gọn và bố cục trang đi kèm.

```tsx
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarSection,
  SidebarItem,
  SidebarSubItem,
  SidebarTrigger,
  BlockSidebarLayout,
} from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Bell` là `BellIcon`, `Bug` là `BugIcon`, `Filter` là `FunnelIcon`, `Settings` là `GearSixIcon`, `Home` là `HouseIcon`, `Inbox` là `TrayIcon`, `List` là `ListIcon`, `PanelLeft` là `SidebarSimpleIcon`, `Search` là `MagnifyingGlassIcon`, `Help` là `QuestionIcon`, `Sparkles` là `SparkleIcon`, `X` là `XIcon`, `Zap` là `LightningIcon` (import từ `@coreds/react/icons`).

### Showcase — theming, sections, footer

Chọn theme để xem sidebar đổi màu (chỉ scope trong khung này), và thu gọn để xem rail icon-only.

```tsx
<div className="shrink-0 h-16 px-2 pt-5 pb-3">
  <div className="flex w-full items-center justify-between">
    <div className={cn("flex items-center transition-[gap] duration-200", collapsed ? "gap-0" : "gap-1.5")}>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button aria-label="User menu" className={cn("inline-flex h-8 w-8 items-center justify-center radius_round transition-[translate] duration-200", collapsed && "translate-x-1")}>
            <Avatar size="xs" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" side="top" sideOffset={8} className="w-48">
          <DropdownMenuLabel>Lê Trung</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>Tài khoản</DropdownMenuItem>
          <DropdownMenuItem>Đăng xuất</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      {[<QuestionIcon />, <GearSixIcon />].map((icon, index) => (
        <div key={index} className={cn("min-w-0 shrink-0 overflow-hidden transition-[max-width,opacity] duration-200", collapsed ? "max-w-0 opacity-0" : "max-w-8 opacity-100")}>
          <button aria-label={index === 0 ? "Help" : "Settings"}>{icon}</button>
        </div>
      ))}
    </div>
    <div className={cn("min-w-0 shrink-0 overflow-hidden transition-[max-width,opacity] duration-200", collapsed ? "max-w-0 opacity-0" : "max-w-8 opacity-100")}>
      <button aria-label="Report a bug"><BugIcon /></button>
    </div>
  </div>
</div>
```

### collapseMode='collapse' (default, icon-only)

```tsx
const [collapsed, setCollapsed] = useState(false)
const [activeId, setActiveId] = useState("dashboard")

<Sidebar className="h-full" collapsed={collapsed} onCollapsedChange={setCollapsed}>
  <SidebarHeader title="Workspace" />
  <SidebarContent>
    <SidebarSection label="Main">
      <SidebarItem
        icon={<Sparkles size="s" />}
        label="Dashboard"
        active={activeId === "dashboard"}
        onClick={() => setActiveId("dashboard")}
      />
      <SidebarItem
        icon={<Zap size="s" />}
        label="Components"
        active={activeId === "components"}
        onClick={() => setActiveId("components")}
      />
      <SidebarItem
        icon={<List size="s" />}
        label="Library"
        active={activeId === "library"}
        onClick={() => setActiveId("library")}
      />
    </SidebarSection>
  </SidebarContent>
</Sidebar>
```

### collapseMode='hide' (fully hidden)

```tsx
const groups: SidebarNavGroup[] = [
  {
    id: "main",
    label: "Main",
    items: [
      { id: "inbox",   label: "Inbox",   icon: <Inbox size="s" /> },
      { id: "filters", label: "Filters", icon: <Filter size="s" /> },
    ],
  },
]

<BlockSidebarLayout
  className="h-80"
  collapseMode="hide"
  groups={groups}
  activeId="inbox"
  collapsed={collapsed}
  onCollapsedChange={setCollapsed}
  onNavigate={() => undefined}
  header={<p className="fg_sidebar_secondary body_s font_semibold truncate">Workspace</p>}
>
  <div className="h-full">
    <div className="flex items-center gap-2 border-b border_secondary px-4 py-2">
      <SidebarTrigger isHideWhenSidebarOpen />
      <p className="text_primary text-sm font-medium">Main content header</p>
    </div>
    <div className="p-4 text_secondary text-sm">Sidebar fully hides at width 0.</div>
  </div>
</BlockSidebarLayout>
```

### Overlay panel (Notion-style) — panel đè lên content, không đẩy content vào trong

```tsx
const PANEL_IDS = new Set(["inbox", "filters"])
const [panelId, setPanelId] = useState<string | null>(null)

const groups: SidebarNavGroup[] = [
  {
    id: "main",
    items: [
      { id: "inbox",   label: "Inbox",   icon: <Inbox size="s" /> },
      { id: "filters", label: "Filters", icon: <Filter size="s" /> },
      { id: "list",    label: "List",    icon: <List size="s" /> },
    ],
  },
]

<BlockSidebarLayout
  groups={groups}
  activeId={panelId ?? undefined}
  onNavigate={(id) => {
    if (PANEL_IDS.has(id)) {
      setPanelId((prev) => (prev === id ? null : id))
    } else {
      // normal navigation
    }
  }}
>
  <div className="relative h-full overflow-hidden">
    {/* Transparent backdrop: z-10, click bất kỳ đâu ngoài panel để đóng */}
    {panelId && (
      <div className="absolute inset-0 z-10" onClick={() => setPanelId(null)} />
    )}

    {/* Panel: z-20 (trên backdrop), slide in/out bằng translateX */}
    <div
      className={`absolute left-0 top-0 h-full w-60 z-20 flex flex-col
        border-r border_secondary bg_secondary shadow-lg
        transition-transform duration-200
        ${panelId ? "translate-x-0" : "-translate-x-full"}`}
    >
      <div className="shrink-0 flex items-center justify-between px-4 py-3 border-b border_secondary">
        <p className="text_primary text-sm font-semibold capitalize">{panelId}</p>
        <button
          onClick={() => setPanelId(null)}
          className="w-6 h-6 flex items-center justify-center radius_6 text_tertiary hover:text_primary hover:state_bg_button_tertiary_soft"
        >
          <X size={14} />
        </button>
      </div>
      <div className="flex-1 overflow-auto p-3">
        {/* render panel content based on panelId */}
      </div>
    </div>

    {/* Main content: luôn full width, không bị đẩy */}
    <div className="h-full overflow-auto p-6">
      {/* page content */}
    </div>
  </div>
</BlockSidebarLayout>
```

### Multiple sections — group spacing

```tsx
<Sidebar className="h-full">
  <SidebarHeader title="iWiki" />
  <SidebarContent>
    <SidebarSection>
      <SidebarItem icon={<Sparkles size="s" />} label="Home" active />
      <SidebarItem icon={<Zap size="s" />} label="iWiki AI" />
      <SidebarItem icon={<Inbox size="s" />} label="Thông báo" />
      <SidebarItem icon={<List size="s" />} label="Bài viết của tôi" />
    </SidebarSection>
    <SidebarSection label="Space công ty">
      <SidebarItem icon={<Filter size="s" />} label="My iKame" />
      <SidebarItem icon={<PanelLeft size="s" />} label="iKame Apps" />
      <SidebarItem icon={<Zap size="s" />} label="Technology" />
      <SidebarItem icon={<Sparkles size="s" />} label="Finance & Accounting" />
    </SidebarSection>
  </SidebarContent>
</Sidebar>
```

### Items — badge, dot, nested children

```tsx
<Sidebar className="h-full">
  <SidebarHeader title="Navigation" />
  <SidebarContent>
    <SidebarSection label="Library">
      <SidebarItem
        icon={<Inbox size="s" />}
        label="Inbox"
        badge={<Badge size="xs" variant="error">5</Badge>}
        active
      />
      <SidebarItem icon={<PanelLeft size="s" />} label="Releases" dot />
      <SidebarItem icon={<List size="s" />} label="Collections" defaultOpen>
        <SidebarSubItem label="Roadmap" />
        <SidebarSubItem label="Backlog" />
      </SidebarItem>
    </SidebarSection>
  </SidebarContent>
</Sidebar>
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `groups` (required) | `array` | — |  |
| `footerGroups` | `SidebarNavGroup[]` | — |  |
| `onNavigate` | `((id: string, href?: string) => void)` | — |  |
| `activeId` | `string` | — |  |
| `header` | `ReactNode` | — | Free-form header content. Rendered inside the DS brand block, so it needs no chrome of its own. |
| `logo` | `ReactNode` | — | Brand mark shown beside `title`. Ignored when `header` is given. |
| `title` | `ReactNode` | — | Workspace name shown beside `logo`. Ignored when `header` is given. |
| `footer` | `ReactNode` | — |  |
| `defaultCollapsed` | `boolean` | — |  |
| `collapsed` | `boolean` | — |  |
| `onCollapsedChange` | `((collapsed: boolean) => void)` | — |  |
| `collapseMode` | `"collapse" \| "hide"` | — |  |
| `contentClassName` | `string` | — |  |

Bảng chỉ liệt kê prop riêng của `BlockSidebarLayoutProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
