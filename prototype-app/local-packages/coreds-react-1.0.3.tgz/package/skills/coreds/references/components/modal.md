# Modal

> Hộp thoại giữa màn hình, chặn tương tác với phần còn lại cho đến khi đóng.

```tsx
import { Modal } from "@coreds/react"
```

## Examples

### Size — sm

```tsx
<Modal
  trigger={<Button variant="border">Open sm modal</Button>}
  title="Small modal"
  description="A compact sm-sized dialog."
  size="sm"
>
  <p className="text_secondary text-sm">Content for a small modal.</p>
</Modal>
```

### Size — md (default)

```tsx
<Modal
  trigger={<Button>Open md modal</Button>}
  title="Create workspace"
  description="Fill in workspace details before continuing."
  size="md"
  footer={
    <>
      <Button variant="subtle">Cancel</Button>
      <Button>Save</Button>
    </>
  }
>
  <div className="space-y-3">
    <Input placeholder="Workspace name" />
    <Input placeholder="Owner" />
  </div>
</Modal>
```

### Size — lg

```tsx
<Modal
  trigger={<Button variant="border">Open lg modal</Button>}
  title="Release notes"
  description="Preview long-form content in a larger dialog."
  size="lg"
>
  <p className="text_secondary text-sm">
    This is a large modal surface for longer content sections, review flows, or previews.
  </p>
</Modal>
```

### Size — xl

```tsx
<Modal
  trigger={<Button variant="border">Open xl modal</Button>}
  title="Data preview"
  description="Extra-large dialog for wide content."
  size="xl"
>
  <p className="text_secondary text-sm">
    An extra-large modal suited for tables, code editors, or multi-column layouts.
  </p>
</Modal>
```

### Size — full

```tsx
<Modal
  trigger={<Button variant="border">Open full-width modal</Button>}
  title="Full width"
  description="Spans nearly the full viewport width."
  size="full"
>
  <p className="text_secondary text-sm">Full-width dialog for immersive experiences.</p>
</Modal>
```

### With scrollable body

```tsx
<Modal
  trigger={<Button variant="border">Open scrollable modal</Button>}
  title="Terms of service"
  description="Please read carefully."
  size="md"
  footer={<Button>Accept</Button>}
>
  <div className="space-y-3">
    {Array.from({ length: 10 }).map((_, i) => (
      <p key={i} className="text_secondary text-sm">
        Section {i + 1}: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
      </p>
    ))}
  </div>
</Modal>
```

### With footer content

```tsx
<Modal
  trigger={<Button>Open with footer</Button>}
  title="Delete project"
  description="This action cannot be undone."
  size="sm"
  footer={
    <>
      <Button variant="subtle">Cancel</Button>
      <Button variant="danger">Delete</Button>
    </>
  }
>
  <p className="text_secondary text-sm">
    Are you sure you want to delete this project? All associated data will be permanently removed.
  </p>
</Modal>
```

### No close button

```tsx
const [open, setOpen] = useState(false)

<>
  <Button variant="border" onClick={() => setOpen(true)}>No close button</Button>
  <Modal
    open={open}
    onOpenChange={setOpen}
    title="Confirm action"
    description="Use the footer buttons to proceed."
    size="sm"
    showCloseButton={false}
    closeOnOverlayClick={false}
    footer={
      <>
        <Button variant="subtle" onClick={() => setOpen(false)}>Cancel</Button>
        <Button onClick={() => setOpen(false)}>Confirm</Button>
      </>
    }
  >
    <p className="text_secondary text-sm">
      This modal has no close button and cannot be dismissed by clicking the overlay.
    </p>
  </Modal>
</>
```

### Controlled state

```tsx
const [open, setOpen] = useState(false)

<>
  <Button onClick={() => setOpen(true)}>Open controlled modal</Button>
  <Modal
    open={open}
    onOpenChange={setOpen}
    title="Controlled modal"
    description="Open/close state is managed externally."
    size="md"
    footer={
      <>
        <Button variant="subtle" onClick={() => setOpen(false)}>Cancel</Button>
        <Button onClick={() => setOpen(false)}>Confirm</Button>
      </>
    }
  >
    <Input placeholder="Enter a value" />
  </Modal>
</>
```

### Modal + Select (layered scroll validation)

```tsx
const [open, setOpen] = useState(false)
const [priority, setPriority] = useState<string | string[]>("")
const [portalContainer, setPortalContainer] = useState<HTMLElement | null>(null)

<>
  <Button variant="border" onClick={() => setOpen(true)}>Open modal with select</Button>
  <Modal open={open} onOpenChange={setOpen} title="Assign priority" size="md">
    <div ref={setPortalContainer} className="space-y-3">
      <Input placeholder="Task title" />
      <Select
        options={priorityOptions}
        value={priority}
        onValueChange={setPriority}
        searchable
        portalContainer={portalContainer}
        placeholder="Select priority"
      />
    </div>
  </Modal>
</>
```

### Scrollable body — controlled

```tsx
const [open, setOpen] = useState(false)

<>
  <Button variant="border" onClick={() => setOpen(true)}>Open scrollable (controlled)</Button>
  <Modal
    open={open}
    onOpenChange={setOpen}
    title="Long document"
    size="md"
      footer={<Button onClick={() => setOpen(false)}>Done</Button>}
  >
    <div>
      <div className="space-y-2">
        {Array.from({ length: 12 }).map((_, i) => (
          <p key={i} className="text_secondary text-sm">
            Paragraph {i + 1}: Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.
          </p>
        ))}
      </div>
    </div>
  </Modal>
</>
```

### Spotlight modal — no overlay

```tsx
const [open, setOpen] = useState(false)

<>
  <Button variant="border" onClick={() => setOpen(true)}>Open spotlight modal</Button>
  <Modal
    variant="spotlight"
    open={open}
    onOpenChange={setOpen}
    size="2xl"
    showCloseButton={false}
    bodyClassName="h-full flex flex-col"
  >
    <div className="flex items-center gap-3 px-4 py-3 border-b border_secondary">
      <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text_tertiary flex-shrink-0" aria-hidden="true">
        <circle cx="6.5" cy="6.5" r="4" stroke="currentColor" strokeWidth="1.5" />
        <path d="M11 11L14 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
      <input
        className="flex-1 bg-transparent outline-none text_primary placeholder:text_tertiary text-sm"
        placeholder="Search or ask a question..."
        autoFocus
      />
      <kbd className="text-xs text_tertiary border border_secondary radius_4 px-1.5 py-0.5 font-sans">Esc</kbd>
    </div>
    <div className="flex-1 overflow-y-auto py-2">
      <p className="px-4 py-1.5 text-xs font-medium text_tertiary uppercase tracking-wide">Recent</p>
      {["Welcome to Notion!", "Getting started", "My tasks", "Project roadmap"].map((item) => (
        <div key={item} className="flex items-center gap-3 px-4 py-2 hover:bg_surface cursor-pointer">
          <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text_tertiary flex-shrink-0" aria-hidden="true">
            <rect x="2" y="2" width="12" height="12" rx="1" stroke="currentColor" strokeWidth="1.5" />
            <path d="M5 6h6M5 9h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
          <span className="text-sm text_primary">{item}</span>
        </div>
      ))}
    </div>
    <div className="border-t border_secondary px-4 py-2 flex items-center gap-3">
      <span className="text-xs text_tertiary">Open page</span>
      <kbd className="text-xs text_tertiary border border_secondary radius_4 px-1.5 py-0.5 font-sans">↵</kbd>
    </div>
  </Modal>
</>
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `onOpenChange` | `((open: boolean) => void)` | — |  |
| `trigger` | `ReactNode` | — |  |
| `description` | `string` | — |  |
| `footer` | `ReactNode` | — |  |
| `size` | `"2xl" \| "full" \| "lg" \| "md" \| "sm" \| "xl"` | — |  |
| `showCloseButton` | `boolean` | — |  |
| `showHeaderDivider` | `boolean` | — | Draws the hairline under the header. Turn it off for a header that reads as one block with the body. |
| `closeOnOverlayClick` | `boolean` | — |  |
| `bodyClassName` | `string` | — |  |
| `variant` | `"default" \| "spotlight"` | — |  |

Bảng chỉ liệt kê prop riêng của `ModalProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
