# Drawer

> Bảng trượt ra từ cạnh màn hình cho nội dung phụ hoặc biểu mẫu.

```tsx
import {
  Drawer,
  DrawerTrigger,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerBody,
  DrawerFooter,
  DrawerClose,
} from "@coreds/react"
```

## Examples

### All sides (left, right, top, bottom)

```tsx
{(["left", "right", "top", "bottom"] as const).map((side) => (
  <Drawer key={side}>
    <DrawerTrigger asChild>
      <Button variant="border">Open {side}</Button>
    </DrawerTrigger>
    <DrawerContent side={side}>
      <DrawerHeader>
        <div>
          <DrawerTitle>{side} drawer</DrawerTitle>
          <DrawerDescription>Drawer from {side} side.</DrawerDescription>
        </div>
      </DrawerHeader>
      <DrawerBody>
        <p className="text_secondary text-sm">This demonstrates the {side} position.</p>
      </DrawerBody>
    </DrawerContent>
  </Drawer>
))}
```

### Full-screen size

```tsx
<Drawer>
  <DrawerTrigger asChild>
    <Button variant="border">Open full-screen drawer</Button>
  </DrawerTrigger>
  <DrawerContent side="right" size="full">
    <DrawerHeader>
      <div>
        <DrawerTitle>Full-screen drawer</DrawerTitle>
        <DrawerDescription>Fills the entire viewport.</DrawerDescription>
      </div>
    </DrawerHeader>
    <DrawerBody>
      <p className="text_secondary text-sm">Use this size for focused, complex workflows.</p>
    </DrawerBody>
  </DrawerContent>
</Drawer>
```

### Left — sizes s / m / l

```tsx
{(["s", "m", "l"] as const).map((size) => (
  <Drawer key={size}>
    <DrawerTrigger asChild>
      <Button variant="border">Left {size.toUpperCase()}</Button>
    </DrawerTrigger>
    <DrawerContent side="left" size={size}>
      <DrawerHeader>
        <div>
          <DrawerTitle>Left / {size.toUpperCase()}</DrawerTitle>
          <DrawerDescription>Size preview</DrawerDescription>
        </div>
      </DrawerHeader>
      <DrawerBody>
        <p className="text_secondary text-sm">Drawer size: {size.toUpperCase()}</p>
      </DrawerBody>
    </DrawerContent>
  </Drawer>
))}
```

### Right — sizes s / m / l

```tsx
{(["s", "m", "l"] as const).map((size) => (
  <Drawer key={size}>
    <DrawerTrigger asChild>
      <Button variant="border">Right {size.toUpperCase()}</Button>
    </DrawerTrigger>
    <DrawerContent side="right" size={size}>
      <DrawerHeader>
        <div>
          <DrawerTitle>Right / {size.toUpperCase()}</DrawerTitle>
          <DrawerDescription>Size preview</DrawerDescription>
        </div>
      </DrawerHeader>
      <DrawerBody>
        <p className="text_secondary text-sm">Drawer size: {size.toUpperCase()}</p>
      </DrawerBody>
    </DrawerContent>
  </Drawer>
))}
```

### Bottom — sizes s / m / l

```tsx
{(["s", "m", "l"] as const).map((size) => (
  <Drawer key={size}>
    <DrawerTrigger asChild>
      <Button variant="border">Bottom {size.toUpperCase()}</Button>
    </DrawerTrigger>
    <DrawerContent side="bottom" size={size}>
      <DrawerHeader>
        <div>
          <DrawerTitle>Bottom / {size.toUpperCase()}</DrawerTitle>
          <DrawerDescription>Size preview</DrawerDescription>
        </div>
      </DrawerHeader>
      <DrawerBody>
        <p className="text_secondary text-sm">Drawer size: {size.toUpperCase()}</p>
      </DrawerBody>
    </DrawerContent>
  </Drawer>
))}
```

### Full example — header + body + footer + DrawerClose

```tsx
const [open, setOpen] = useState(false)

<Drawer open={open} onOpenChange={setOpen}>
  <DrawerTrigger asChild>
    <Button>Open full example</Button>
  </DrawerTrigger>
  <DrawerContent side="left" size="m">
    <DrawerHeader>
      <div>
        <DrawerTitle>Filter projects</DrawerTitle>
        <DrawerDescription>Adjust filters before applying.</DrawerDescription>
      </div>
    </DrawerHeader>
    <DrawerBody>
      <div className="space-y-3">
        <Input placeholder="Project name" />
        <Input placeholder="Owner" />
        <Select options={statusOptions} placeholder="Status" />
      </div>
    </DrawerBody>
    <DrawerFooter>
      <DrawerClose asChild>
        <Button variant="subtle">Close</Button>
      </DrawerClose>
      <Button onClick={() => setOpen(false)}>Apply</Button>
    </DrawerFooter>
  </DrawerContent>
</Drawer>
```

### Drawer with users select (long list)

```tsx
const [open, setOpen] = useState(false)
const [selectedUser, setSelectedUser] = useState<string | string[]>("")
const userOptions = usersData.map((user) => ({
  value: user.id,
  label: user.name,
  description: user.email,
  icon: <Avatar size="xs" type="text" fallback={user.avatar} alt={user.name} />,
}))

<Drawer open={open} onOpenChange={setOpen}>
  <DrawerTrigger asChild>
    <Button variant="border">Open users drawer</Button>
  </DrawerTrigger>
  <DrawerContent side="right" size="m">
    <DrawerHeader>
      <div>
        <DrawerTitle>Select assignee</DrawerTitle>
        <DrawerDescription>Use long users list inside drawer to test scroll behavior.</DrawerDescription>
      </div>
    </DrawerHeader>
    <DrawerBody>
      <div className="space-y-3">
        <Select
          options={userOptions}
          value={selectedUser}
          onValueChange={setSelectedUser}
          searchable
          clearable
          placeholder="Chọn người dùng..."
          searchPlaceholder="Tìm kiếm theo tên hoặc email..."
        />
      </div>
    </DrawerBody>
  </DrawerContent>
</Drawer>
```

### App-like repro: DrawerBody overflow-hidden + ScrollArea + Select

```tsx
const [open, setOpen] = useState(false)
const [rawUser, setRawUser] = useState<string | string[]>("")
const [fixedUser, setFixedUser] = useState<string | string[]>("")
const [portalContainer, setPortalContainer] = useState<HTMLElement | null>(null)

<Drawer open={open} onOpenChange={setOpen}>
  <DrawerTrigger asChild>
    <Button variant="border">Open nested scroll repro</Button>
  </DrawerTrigger>
  <DrawerContent side="right" size="m">
    <DrawerHeader>
      <div>
        <DrawerTitle>Nested scroll repro</DrawerTitle>
        <DrawerDescription>Mimics app structure: DrawerBody overflow-hidden + ScrollArea.</DrawerDescription>
      </div>
    </DrawerHeader>
    <DrawerBody className="overflow-hidden">
      <ScrollArea className="h-full" viewportClassName="pr-3">
        <div ref={setPortalContainer} className="space-y-3">
          <Input placeholder="Job title" />
          <Select options={userOptions} value={rawUser} onValueChange={setRawUser} searchable placeholder="Raw select (no portalContainer)" />
          <Select options={userOptions} value={fixedUser} onValueChange={setFixedUser} searchable portalContainer={portalContainer} placeholder="Fixed select (with portalContainer)" />
          {Array.from({ length: 8 }).map((_, i) => <Input key={i} placeholder={`Extra field ${i + 1}`} />)}
        </div>
      </ScrollArea>
    </DrawerBody>
  </DrawerContent>
</Drawer>
```

## Props

Drawer dựng trên Radix Dialog, nên `Drawer`, `DrawerTrigger` và `DrawerClose` nhận đúng props của Radix Dialog. Xem [tài liệu Radix](https://www.radix-ui.com/primitives/docs/components/dialog).
