# Tabs

> Chia nội dung thành các tab ngang hàng.

```tsx
import { Tabs } from "@coreds/react"
```

## Examples

### Data-driven (no TabsList/TabsTrigger needed)

```tsx
<Tabs defaultValue="profile" items={[
  {
    value: "profile",
    label: "Profile",
    content: (
      <div className="space-y-1">
        <p className="text-sm font-medium text_primary">Profile</p>
        <p className="text-xs text_tertiary">Profile settings and personal information.</p>
      </div>
    ),
  },
  ...
]} />
```

### Underline label variant

```tsx
<Tabs
  defaultValue="overview"
  variant="underlineLabel"
  color="orange"
  tabHeight={36}
  items={[
    { value: "overview", label: "Overview", content: <OverviewPanel /> },
    { value: "analytics", label: "Analytics", content: <AnalyticsPanel /> },
    { value: "reports", label: "Reports", content: <ReportsPanel /> },
  ]}
/>
```

### Underline variant

```tsx
<Tabs
  defaultValue="overview"
  variant="underline"
  color="orange"
  tabHeight={36}
  items={[
    { value: "overview", label: "Overview", content: <OverviewPanel /> },
    { value: "analytics", label: "Analytics", content: <AnalyticsPanel /> },
    { value: "reports", label: "Reports", content: <ReportsPanel /> },
    { value: "notifications", label: "Notifications", content: <NotificationsPanel /> },
  ]}
/>
```

### Borderless variant

```tsx
<Tabs
  defaultValue="overview"
  variant="borderless"
  color="primary"
  tabHeight={36}
  items={[
    { value: "overview", label: "Overview", content: <OverviewPanel /> },
    { value: "analytics", label: "Analytics", content: <AnalyticsPanel /> },
    { value: "reports", label: "Reports", content: <ReportsPanel /> },
    { value: "notifications", label: "Notifications", content: <NotificationsPanel /> },
  ]}
/>
```

### Disabled tabs

```tsx
<Tabs
  defaultValue="active"
  items={[
    { value: "active", label: "Active", content: <ActivePanel /> },
    { value: "disabled", label: "Disabled", disabled: true, content: <DisabledPanel /> },
    { value: "another", label: "Another", content: <AnotherPanel /> },
  ]}
/>
```

### Controlled tabs

```tsx
const [activeTab, setActiveTab] = useState("profile")

<div className="space-y-2">
  <p className="text_tertiary text-xs">Active tab: {activeTab}</p>
  <Tabs value={activeTab} onValueChange={setActiveTab} items={tabsData} />
</div>
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` (required) | `array` | — |  |
| `variant` | `"borderless" \| "default" \| "underline" \| "underlineLabel"` | — |  |
| `color` | `"orange" \| "primary"` | — |  |
| `tabHeight` | `string \| number` | — |  |
| `tabsListClassName` | `string` | — |  |
| `triggerClassName` | `string` | — |  |
| `contentClassName` | `string` | — |  |
| `asChild` | `boolean` | — |  |
| `value` | `string` | — | The value for the selected tab, if controlled |
| `defaultValue` | `string` | — | The value of the tab to select by default, if uncontrolled |
| `onValueChange` | `((value: string) => void)` | — | A function called when a new tab is selected |
| `orientation` | `"horizontal" \| "vertical"` | `horizontal` | The orientation the tabs are layed out. Mainly so arrow navigation is done accordingly (left & right vs. up & down) |
| `dir` | `"ltr" \| "rtl"` | — | The direction of navigation between toolbar items. |
| `activationMode` | `"automatic" \| "manual"` | `automatic` | Whether a tab is activated automatically or manually. |

Bảng chỉ liệt kê prop riêng của `TabsProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
