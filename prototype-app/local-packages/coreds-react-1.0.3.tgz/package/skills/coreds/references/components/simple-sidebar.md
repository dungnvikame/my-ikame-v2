# SimpleSidebar

> Sidebar gọn, dựng từ một mảng dữ liệu thay vì ghép từng phần.

```tsx
import { SimpleSidebar } from "@coreds/react"
```

## Examples

Code ví dụ gọi icon bằng tên ngắn: `Calendar` là `CalendarBlankIcon`, `FolderOpen` là `FolderOpenIcon`, `HelpCircle` là `QuestionIcon`, `Home` là `HouseIcon`, `MessageSquare` là `ChatCircleIcon`, `Settings` là `GearIcon`, `Sparkles` là `SparkleIcon` (import từ `@coreds/react/icons`).

### Basic - hover to expand

```tsx
const [activeId, setActiveId] = useState("home")

const groups: SimpleSidebarGroup[] = [
  {
    id: "main",
    items: [
      { id: "home", label: "Home", icon: <Home size="m" /> },
      { id: "projects", label: "Projects", icon: <FolderOpen size="m" /> },
      { id: "calendar", label: "Calendar", icon: <Calendar size="m" /> },
      { id: "settings", label: "Settings", icon: <Settings size="m" /> },
    ],
  },
  {
    id: "support",
    items: [
      { id: "help", label: "Help", icon: <HelpCircle size="m" /> },
      { id: "feedback", label: "Feedback", icon: <MessageSquare size="m" /> },
    ],
  },
]

<div className="h-96 relative border border_secondary radius_8 overflow-hidden">
  <SimpleSidebar groups={groups} activeId={activeId} onNavigate={(id) => setActiveId(id)} />
  <div className="w-full h-full p-6 pl-[200px] overflow-auto">
    <p className="text_secondary text-sm">
      Hover over the sidebar to expand. Content stays full width - sidebar overlays the left edge.
    </p>
  </div>
</div>
```

### With header and footer

```tsx
const [activeId, setActiveId] = useState("projects")

<div className="h-96 relative border border_secondary radius_8 overflow-hidden">
  <SimpleSidebar
    groups={groups}
    activeId={activeId}
    alwaysExpanded
    onNavigate={(id) => setActiveId(id)}
    header={<Sparkles size="m" className="text_primary" />}
    footer={<Avatar fallback="UN" size="s" type="text" />}
  />
  <div className="w-full h-full p-6 pl-[200px] overflow-auto">
    <p className="text_secondary text-sm">
      Main content area. This example keeps the sidebar expanded without requiring hover.
    </p>
  </div>
</div>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `groups` (required) | `array` | — |
| `activeId` | `string` | — |
| `onNavigate` | `((id: string, href?: string) => void)` | — |
| `header` | `ReactNode` | — |
| `footer` | `ReactNode` | — |
| `alwaysExpanded` | `boolean` | — |
| `expandedWidth` | `number` | — |
| `collapsedWidth` | `number` | — |

Bảng chỉ liệt kê prop riêng của `SimpleSidebarProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
