# Textarea

> Ô nhập văn bản nhiều dòng.

```tsx
import { Textarea } from "@coreds/react"
```

## Examples

### Default (3 rows)

```tsx
<Textarea placeholder="Enter your message..." />
```

### Autosize — grows with content

```tsx
<Textarea autosize placeholder="Type to auto-grow..." minRows={2} />
```

### Autosize with maxRows={6}

```tsx
<Textarea autosize minRows={2} maxRows={6} placeholder="Max 6 rows then scrolls..." />
```

### Controlled

```tsx
const [value, setValue] = useState("")
<Textarea
  value={value}
  onChange={(e) => setValue(e.target.value)}
  autosize
  placeholder="Controlled textarea..."
/>
```

### Variants

```tsx
<Textarea variant="light" placeholder="light" />
<Textarea variant="fill" placeholder="fill" />
<Textarea variant="dim" placeholder="dim" />
```

### Sizes

```tsx
<Textarea size="s" placeholder="s" rows={2} />
<Textarea size="m" placeholder="m" rows={2} />
<Textarea size="l" placeholder="l" rows={2} />
```

### Disabled

```tsx
<Textarea disabled value="Cannot edit this" />
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `autosize` | `boolean` | — | Auto-grow height with content |
| `minRows` | `number` | — | Minimum number of visible rows (default: 3) |
| `maxRows` | `number` | — | Maximum number of rows before scrolling |
| `dirName` | `string` | — |  |
| `variant` | `"borderless" \| "dim" \| "fill" \| "light" \| null` | — |  |
| `size` | `"l" \| "m" \| "s" \| "xl" \| "xs" \| null` | — |  |

Bảng chỉ liệt kê prop riêng của `TextareaProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
