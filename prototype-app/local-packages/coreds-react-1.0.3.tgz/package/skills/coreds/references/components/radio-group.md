# RadioGroup

> Nhóm lựa chọn chỉ chọn được một.

```tsx
import { RadioGroup, RadioGroupItem } from "@coreds/react"
```

## Examples

### Vertical (default)

```tsx
<RadioGroup value={value} onValueChange={setValue}>
  <RadioGroupItem value="monthly" label="Monthly" />
  <RadioGroupItem value="quarterly" label="Quarterly" />
  <RadioGroupItem value="yearly" label="Yearly" description="Best for annual planning" />
  <RadioGroupItem value="legacy" label="Legacy" disabled />
</RadioGroup>
```

### Horizontal

```tsx
<RadioGroup value={value} onValueChange={setValue} orientation="horizontal">
  <RadioGroupItem value="monthly" label="Monthly" />
  <RadioGroupItem value="quarterly" label="Quarterly" />
  <RadioGroupItem value="yearly" label="Yearly" />
</RadioGroup>
```

### Sizes

```tsx
<RadioGroup value={value} onValueChange={setValue}>
  <RadioGroupItem value="a" label="Small (sm)" size="sm" />
  <RadioGroupItem value="b" label="Medium (md) — default" size="md" />
  <RadioGroupItem value="c" label="Large (lg)" size="lg" />
</RadioGroup>
```

### Disabled option

```tsx
<RadioGroup value="active" onValueChange={() => {}}>
  <RadioGroupItem value="active" label="Active plan" />
  <RadioGroupItem value="paused" label="Paused" disabled />
  <RadioGroupItem value="cancelled" label="Cancelled" disabled />
</RadioGroup>
```

## Props

### RadioGroupProps

| Prop | Type | Default |
| --- | --- | --- |
| `orientation` | `"horizontal" \| "vertical"` | — |
| `asChild` | `boolean` | — |
| `dir` | `"ltr" \| "rtl"` | — |
| `defaultValue` | `string` | — |
| `value` | `string \| null` | — |
| `onValueChange` | `((value: string) => void)` | — |

Bảng chỉ liệt kê prop riêng của `RadioGroupProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.

### RadioGroupItemProps

| Prop | Type | Default |
| --- | --- | --- |
| `description` | `string` | — |
| `size` | `"lg" \| "md" \| "sm"` | — |
| `type` | `"button" \| "reset" \| "submit"` | — |
| `asChild` | `boolean` | — |
| `value` (required) | `string` | — |

Bảng chỉ liệt kê prop riêng của `RadioGroupItemProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
