# Slider

> Thanh trượt chọn một giá trị hoặc một khoảng.

```tsx
import { Slider } from "@coreds/react"
```

## Examples

### Single value

```tsx
const [value, setValue] = useState([35])

<Slider min={0} max={100} step={1} value={value} onValueChange={setValue} />
<p>Value: {value[0]}</p>
```

### Range (two thumbs)

```tsx
const [range, setRange] = useState([20, 75])

<Slider min={0} max={100} step={1} value={range} onValueChange={setRange} />
<p>Range: {range[0]} – {range[1]}</p>
```

### Custom step

```tsx
{/* step={10} snaps to 0, 10, 20, … 100 */}
<Slider min={0} max={100} step={10} value={value} onValueChange={setValue} />
<p>Value: {value[0]}</p>
```

### Fine-grained step with range

```tsx
{/* step={0.5} for decimal precision */}
<Slider min={0} max={100} step={0.5} value={value} onValueChange={setValue} />
<p>Range: {value[0].toFixed(1)} – {value[1].toFixed(1)}</p>
```

### Disabled

```tsx
<Slider min={0} max={100} step={1} defaultValue={[60]} disabled />
```

### With min / max labels

```tsx
<div className="space-y-1">
  <Slider min={0} max={100} step={1} value={value} onValueChange={setValue} />
  <div className="flex justify-between text-xs text_tertiary">
    <span>0</span>
    <span>{value[0]}</span>
    <span>100</span>
  </div>
</div>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `asChild` | `boolean` | — |
| `orientation` | `"horizontal" \| "vertical"` | — |
| `dir` | `"ltr" \| "rtl"` | — |
| `min` | `number` | — |
| `max` | `number` | — |
| `step` | `number` | — |
| `minStepsBetweenThumbs` | `number` | — |
| `value` | `number[]` | — |
| `defaultValue` | `number[]` | — |
| `onValueChange` | `((value: number[]) => void)` | — |
| `onValueCommit` | `((value: number[]) => void)` | — |
| `inverted` | `boolean` | — |

Bảng chỉ liệt kê prop riêng của `SliderProps`. Thuộc tính HTML chuẩn của phần tử nó render (`className`, `aria-*`, event handler…) vẫn dùng được.
