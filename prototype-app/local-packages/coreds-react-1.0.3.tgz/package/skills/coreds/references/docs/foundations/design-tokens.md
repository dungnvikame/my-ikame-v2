# Design Tokens

> Giá trị của mọi token màu ở cả bảy theme, kèm màn thử đổi màu ngay trên component thật.

Token đặt tên theo vai trò (`bg_primary`, `text_secondary`, `border_accent_primary`), mỗi theme gán cho nó một giá trị. Bảng dưới đọc giá trị từ chính stylesheet của `@coreds/ui` lúc build, nên luôn khớp với bản đang phát hành. Ý nghĩa và cách chọn từng token xem ở [Colors](./colors.md).

## Theme tokens

Mỗi hàng là một token, mỗi cột là một theme. Bấm vào một ô để nạp token đó vào màn thử bên dưới.

| Token | Light | High contrast | Olive | Sunset | iCreative Studio | Dark | Deep forest |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `bg_primary` | #FFFFFF | #FFFFFF | #F5FAF5 | #FFFFFF | #ffffff | #252422 | #034A41 |
| `bg_secondary` | #FAFAFA | #FAFAFA | #EBF4EC | #FCFCFC | #f7faff | #1D1C1B | #024039 |
| `bg_tertiary` | #F0F0EF | #F0F0EF | #E0EBE1 | #F2F2F2 | #eef5ff | #131211 | #023C35 |
| `bg_quaternary` | #E7E6E4 | #E7E6E4 | #D3E3D6 | #E8E8E8 | #e3eefc | #252422 | #01231F |
| `bg_primary_transparent` | #FFFFFF00 | #FFFFFF00 | #F5FAF500 | #FFFFFF00 | #FFFFFF00 | #25242200 | #034A4100 |
| `bg_secondary_transparent` | #FAFAFA00 | #FAFAFA00 | #EBF4EC00 | #FCFCFC00 | #FAFAFA00 | #1D1C1B00 | #02403900 |
| `bg_tertiary_transparent` | #F0F0EF00 | #F0F0EF00 | #E0EBE100 | #F2F2F200 | #F0F0EF00 | #13121100 | #023C3500 |
| `bg_quaternary_transparent` | #E7E6E400 | #E7E6E400 | #D3E3D600 | #E8E8E800 | #E7E6E400 | #25242200 | #01231F00 |
| `bg_canvas_primary` | #FFFFFF | #FFFFFF | #F5FAF5 | #FFFFFF | #f5f9ff | #131211 | #023C35 |
| `bg_canvas_secondary` | #FAFAFA | #FAFAFA | #EBF4EC | #FCFCFC | #eef5ff | #181716 | #02453E |
| `bg_canvas_tertiary` | #F0F0EF | #F0F0EF | #E0EBE1 | #F2F2F2 | #e3eefc | #222120 | #03544A |
| `bg_canvas_quaternary` | #EBEBEA | #EBEBEA | #DAE7DC | #EDEDED | #d7e7fa | #32312F | #04675B |
| `bg_interactive_primary` | #FFFFFF | #FFFFFF | #F5FAF5 | #FFFFFF | #ffffff | #383633 | #047164 |
| `bg_interactive_secondary` | #F5F5F4 | #F5F5F4 | #E6EFE7 | #F5F5F4 | #f4f8fe | #3D3B38 | #057B6C |
| `bg_interactive_tertiary` | #EBEBEA | #EBEBEA | #DAE7DC | #EBEBEA | #e8f1fd | #4A4844 | #057B6C |
| `bg_interactive_contrast` | #D8D6D5 | #D8D6D5 | #C1D7C4 | #D8D6D5 | #d9e6f7 | #6F6B67 | #07AC97 |
| `bg_interactive_transparent` | #00000017 | #00000017 | #00000017 | #00000017 | #00000017 | #FFFFFF17 | #FFFFFF17 |
| `bg_overlay` | #FFFFFF | #FFFFFF | #F5FAF5 | #FFFFFF | #ffffff | #2A2927 | #034038 |
| `bg_inverse` | #222120 | #222120 | #222120 | #222120 | #10233f | #F5F5F4 | #B5FCF3 |
| `bg_backdrop` | #3D3B3866 | #3D3B3866 | #3D3B3866 | #3D3B3866 | #10233f66 | #00000066 | #00000066 |
| `bg_button_primary` | #F76226 | #F76226 | #5DE442 | #DD7000 | #ff6b2c | #F76226 | #F76226 |
| `bg_button_secondary` | #FEF4F0 | #FEF4F0 | #C9E9CC | #FFFBEB | #fff0e8 | #993706 | #993706 |
| `bg_button_tertiary` | #F5F5F4 | #F5F5F4 | #E8EEE8 | #F5F5F4 | #f1f6fd | #2A2927 | #046D60 |
| `bg_input_fill` | #F5F5F4 | #F5F5F4 | #E8EEE8 | #F5F5F4 | #ffffff | #32312F | #04685C |
| `bg_input_fill_dim` | #EEEDEC | #EEEDEC | #DFE7E0 | #EEEDEC | #ffffff | #2A2927 | #016055 |
| `bg_input_light` | #FFFFFF | #FFFFFF | #F5FAF5 | #FFFFFF | #ffffff | #252422 | #034A41 |
| `bg_sidebar_primary` | #F5F5F4 | #F5F5F4 | #E8F2E8 | #F3ECE8 | #ffffff | #181716 | #02453E |
| `bg_sidebar_secondary` | #F0F0EF | #F0F0EF | #E2EEE2 | #EFE7E1 | #f2f6fb | #131211 | #023B34 |
| `bg_sidebar_primary_transparent` | #F5F5F400 | #F5F5F400 | #E8F2E800 | #F3ECE800 | #F5F5F400 | #18171600 | #02453E00 |
| `bg_sidebar_secondary_transparent` | #F0F0EF00 | #F0F0EF00 | #E2EEE200 | #EFE7E100 | #F0F0EF00 | #1D1C1B00 | #023C3500 |
| `bg_accent_primary` | #F76226 | #F76226 | #5DE442 | #DD7000 | #ff6b2c | #F76226 | #F76226 |
| `bg_accent_primary_subtle` | #FEF4F0 | #FEF4F0 | #F5FAF5 | #FFFBEB | #fff0e8 | #993706 | #BB4307 |
| `bg_accent_secondary` | #0D87F2 | #0D87F2 | #0D87F2 | #0D87F2 | #287de3 | #0D87F2 | #0D87F2 |
| `bg_accent_secondary_subtle` | #F6FAFE | #F6FAFE | #EDF5FD | #F6FAFE | #eaf4ff | #043057 | #063E6F |
| `focus_ring` | #F76226 | #F76226 | #5DE442 | #DD7000 | #287de3 | #F76226 | #F76226 |
| `bg_success` | #F6FEF9 | #F6FEF9 | #F6FEF9 | #F6FEF9 | #f1fcf5 | #024C24 | #055723 |
| `bg_success_contrast` | #02B644 | #02B644 | #02B644 | #02B644 | #16a34a | #02B644 | #02B644 |
| `bg_warning` | #FFFDF5 | #FFFDF5 | #FFFDF5 | #FFFDF5 | #fff9e9 | #574404 | #745A06 |
| `bg_warning_contrast` | #CA9C02 | #CA9C02 | #CA9C02 | #CA9C02 | #c48216 | #CA9C02 | #CA9C02 |
| `bg_error` | #FEF6F7 | #FEF6F7 | #FEF6F7 | #FEF6F7 | #fff5f5 | #40070C | #8C171F |
| `bg_error_contrast` | #D3222E | #D3222E | #D3222E | #D3222E | #dc3b42 | #E5616A | #E5616A |
| `bg_info` | #F6FAFE | #F6FAFE | #F6FAFE | #F6FAFE | #eef7ff | #043057 | #063E6F |
| `bg_info_contrast` | #0D87F2 | #0D87F2 | #0D87F2 | #0D87F2 | #287de3 | #0D87F2 | #0D87F2 |
| `text_primary` | #32312F | #131211 | #32312F | #32312F | #10233f | #F5F5F4 | #F4F5F4 |
| `text_secondary` | #55524E | #32312F | #55524E | #55524E | #54657b | #D8D6D5 | #D0DCDA |
| `text_tertiary` | #8A857F | #55524E | #8A857F | #8A857F | #7f8da0 | #A4A19D | #9DA4A3 |
| `text_contrast` | #131211 | #131211 | #131211 | #131211 | #08182e | #FFFFFF | #FFFFFF |
| `icon_primary` | #55524E | #131211 | #55524E | #55524E | #465a73 | #F0F0EF | #F0F0EF |
| `icon_secondary` | #6F6B67 | #383633 | #6F6B67 | #6F6B67 | #6f8095 | #EBEBEA | #EBEBEA |
| `icon_tertiary` | #A4A19D | #55524E | #A4A19D | #A4A19D | #9aa8b8 | #CECCCA | #CECCCA |
| `fg_accent_primary` | #EC5509 | #EC5509 | #1C670C | #DD7000 | #e85418 | #FCC8B5 | #FEDACD |
| `fg_accent_secondary` | #0B72CB | #0B72CB | #0B72CB | #0B72CB | #176bc8 | #64B2F7 | #A8D4FA |
| `fg_link` | #0B72CB | #0B72CB | #0B72CB | #0B72CB | #176bc8 | #64B2F7 | #64B2F7 |
| `fg_accent_primary_inverse` | #FBA789 | #FBA789 | #93F07F | #FBA789 | #FBA789 | #EC5509 | #EC5509 |
| `fg_accent_secondary_inverse` | #64B2F7 | #64B2F7 | #64B2F7 | #64B2F7 | #64B2F7 | #0B72CB | #64B2F7 |
| `fg_success` | #029739 | #029739 | #029739 | #029739 | #15803d | #86EAA4 | #86EAA4 |
| `fg_warning` | #745A06 | #745A06 | #745A06 | #745A06 | #916009 | #FBC637 | #FBC637 |
| `fg_error` | #D3222E | #D3222E | #D3222E | #D3222E | #c92f36 | #F49AA0 | #FBDADD |
| `fg_info` | #0B72CB | #0B72CB | #0B72CB | #0B72CB | #176bc8 | #64B2F7 | #64B2F7 |
| `fg_on_accent_primary` | #FFFFFF | #FFFFFF | #165805 | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF |
| `fg_on_accent_secondary` | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF |
| `fg_on_accent_general` | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF |
| `fg_on_contrast` | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #383633 | #383633 |
| `fg_inverse_primary` | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #32312F | #32312F |
| `fg_inverse_secondary` | #D8D6D5 | #D8D6D5 | #D8D6D5 | #D8D6D5 | #D8D6D5 | #55524E | #55524E |
| `light_fixed` | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF | #FFFFFF |
| `dim_fixed` | #252422 | #252422 | #252422 | #252422 | #252422 | #252422 | #252422 |
| `fg_sidebar_primary` | #32312F | #131211 | #32312F | #32312F | #10233f | #F5F5F4 | #F5F5F4 |
| `fg_sidebar_secondary` | #55524E | #32312F | #55524E | #55524E | #54657b | #D8D6D5 | #D0DCDA |
| `fg_sidebar_tertiary` | #8A857F | #4A4844 | #8A857F | #8A857F | #7f8da0 | #A4A19D | #9DA4A3 |
| `border_primary` | #F0F0EF | #D8D6D5 | #DBEBDB | #F0F0EF | #dce6f2 | #383633 | #045D52 |
| `border_secondary` | #EBEBEA | #CECCCA | #D5E7D5 | #EBEBEA | #e7eef7 | #32312F | #035349 |
| `border_tertiary` | #DFDEDD | #BFBDBA | #C2DBC2 | #DFDEDD | #ceddeb | #4A4844 | #047B6C |
| `border_contrast_primary` | #6F6B67 | #55524E | #676F67 | #6F6B67 | #60738a | #CECCCA | #63F8E6 |
| `border_contrast_secondary` | #A4A19D | #8A857F | #9DA4A0 | #A4A19D | #91a0b0 | #A4A19D | #22F6DB |
| `border_accent_primary` | #FCC8B5 | #FBA789 | #B5FCD0 | #FCE68A | #ffc6aa | #BB4307 | #BB4307 |
| `border_accent_primary_contrast` | #F87E52 | #F76226 | #52F892 | #FFC21A | #ff8c5c | #BB4307 | #BB4307 |
| `border_accent_secondary` | #CFE7FC | #A8D4FA | #CFE7FC | #CFE7FC | #bddcff | #063E6F | #063E6F |
| `border_accent_secondary_contrast` | #64B2F7 | #0D87F2 | #64B2F7 | #64B2F7 | #70b3f5 | #64B2F7 | #64B2F7 |
| `border_input` | #EBEBEA | #CECCCA | #D6EBD6 | #EBEBEA | #d9e4f0 | #4A4844 | #057F70 |
| `border_input_opacity` | #3D3B3800 | #CECCCA | #3D3B3800 | #3D3B3800 | #3D3B3800 | #3D3B3800 | #3D3B3800 |
| `border_button` | #DFDEDD | #BFBDBA | #CDDFCD | #DFDEDD | #ceddeb | #3D3B38 | #045D52 |
| `border_dim_button` | #EBEBEA | #CECCCA | #CDDFCD | #EBEBEA | #e1eaf4 | #3D3B38 | #045D52 |
| `border_secondary_button` | #FEECE6 | #FBA789 | #C6DDC6 | #FEECE6 | #ffd5c2 | #BB4307 | #BB4307 |
| `border_error_button` | #FBDADD | #F49AA0 | #FBDADD | #FBDADD | #f6d4d6 | #8C171F | #8C171F |
| `border_success` | #B1F1C9 | #43DB6B | #B1F1C9 | #B1F1C9 | #b8e8ca | #029739 | #029739 |
| `border_error` | #FCCFD2 | #E5616A | #FCCFD2 | #FCCFD2 | #f6c5c8 | #D3222E | #E5616A |

## Playground

Đổi màu bằng ô chọn màu hoặc gõ giá trị (hex, `rgb()`, `color-mix()`…). Khung xem trước dùng component thật của Core DS ở theme đang chọn, nên thấy ngay chữ còn đọc được không, viền còn rõ không. Màu mới chỉ nằm trong trang này.

Muốn đổi màu thật cho một theme: thử ở đây, gửi giá trị cho designer cập nhật trong Figma, rồi làm theo mục "Designer sửa màu" trong README của repo Core DS để sinh lại token.

## Token names

| Tên                  | Ví dụ                                           |
| -------------------- | ----------------------------------------------- |
| Class                | `bg_primary`, `text_secondary`                  |
| CSS variable         | `--ds-bg-primary`, `--ds-text-secondary`        |
| Theme (`data-theme`) | `light` (mặc định), `dark`, `sunset`…           |
| Class của theme      | `dark`, `theme-sunset`, `theme-creative-studio` |

Class và CSS variable cùng tên, khác dấu gạch: class dùng `_`, biến dùng `-` và có tiền tố `--ds-`. Cần màu trong style inline hoặc CSS riêng thì dùng biến: `style={{ borderColor: "var(--ds-border-secondary)" }}`.
