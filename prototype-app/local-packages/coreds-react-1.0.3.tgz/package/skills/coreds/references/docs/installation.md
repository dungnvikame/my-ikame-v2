# Installation

> Thêm registry của Core DS vào app, cài gói, import CSS và provider.

### Trỏ scope `@coreds` về registry

Thêm một dòng vào `.npmrc` ở gốc app. File này không chứa bí mật nên commit cùng code.

```ini title=".npmrc"
@coreds:registry=https://gitlab.ikameglobal.com/api/v4/projects/2163/packages/npm/
```

Yarn 2 trở lên đọc `.yarnrc.yml` thay cho `.npmrc`:

```yaml title=".yarnrc.yml"
npmScopes:
  coreds:
    npmRegistryServer: "https://gitlab.ikameglobal.com/api/v4/projects/2163/packages/npm/"
```

### Cài gói

Gói tổng `@coreds/react` có cả component lẫn icon. Chỉ cần một phần thì cài riêng `@coreds/ui` hoặc `@coreds/icons`.

```bash tab="npm"
npm install @coreds/react
```

```bash tab="pnpm"
pnpm add @coreds/react
```

```bash tab="yarn"
yarn add @coreds/react
```

Cần React 18 hoặc 19.

### Import CSS một lần

Ở file vào của app (`main.tsx`, hoặc `app/layout.tsx` với Next.js):

```tsx
import "@coreds/react/style.css"
```

Stylesheet đã có font Inter (kể cả bộ ký tự tiếng Việt), design token và style của mọi component.

### Bọc app bằng provider

`TooltipProvider` cần cho `Tooltip`, `Toaster` cần khi gọi `toast()`.

```tsx
import { Toaster, TooltipProvider } from "@coreds/react"

export function App({ children }: { children: React.ReactNode }) {
  return (
    <TooltipProvider>
      {children}
      <Toaster />
    </TooltipProvider>
  )
}
```

## Usage

```tsx
import { Button, toast } from "@coreds/react"
import { CheckIcon } from "@coreds/react/icons"

export function SaveButton() {
  return (
    <Button onClick={() => toast.success("Đã lưu")}>
      <CheckIcon /> Lưu
    </Button>
  )
}
```

## Dark mode

Thêm class `dark` vào phần tử gốc (thường là `<html>`), toàn bộ token chuyển sang giao diện tối. Hook `useTheme` lo việc này và nhớ lựa chọn của người dùng.
