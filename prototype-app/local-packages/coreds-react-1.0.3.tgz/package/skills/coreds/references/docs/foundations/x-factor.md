# Hệ số X

> Một biến CSS chung (--ds-x) làm component thoáng hơn và bo tròn hơn mà không đổi prop size. Đặt cho cả theme hoặc từng khu vực.

X là một biến CSS, `--ds-x`, chỉnh độ thoáng và độ bo góc của các component đã tham gia. Theme hoặc một khu vực trong app đặt X riêng là component trong đó to ra theo, không cần đổi prop `size`.

## How it works

- Chiều cao, padding và khoảng cách bên trong = **số đo gốc × X**.
- Bo góc = **số đo gốc × X³**, để độ bo tăng rõ hơn kích thước.
- X mặc định là `1`, nên khi chưa đặt gì thì mọi số đo giữ nguyên.

Ví dụ khi X tăng từ `1` lên `1.2`:

| Phần              | X = 1 | X = 1.2 |
| ----------------- | ----- | ------- |
| Button `size="m"` | 32px  | 38.4px  |
| Input `size="m"`  | 40px  | 48px    |
| `radius_6`        | 6px   | 10.37px |

## What it changes

- **Thay đổi theo X:**
  - Chiều cao, padding và khoảng cách của Button, IconToggle, Chip, Input, Select. Ô chọn ngày của DatePicker và ô tìm trong Chip, Select dùng chung kiểu của Input nên cũng đổi theo.
  - Dòng menu của Select và DropdownMenu ([Menu](./menu.md)).
  - Dòng của Sidebar và SimpleSidebar.
  - Mọi class bo góc `radius_*`.
  - Khung của Button icon. Hình icon bên trong giữ nguyên.
- **Chỉ đổi bo góc:** Card, Modal, khung menu, Accordion và các component khác dùng `radius_*`.
- **Không đổi:** cỡ chữ, hình icon, độ dày viền, khoảng cách bố cục trang (`gap-*`, `p-*` bạn tự viết), chiều cao tab của Tabs, Textarea, SegmentedControl, Checkbox, RadioGroup, Switch.
- `size="m"` vẫn chọn cùng một bậc size; X chỉ đổi số đo của bậc đó.

## Playground

So sánh X = 1 với một giá trị khác, ở theme đang chọn trên trang.

## Usage

Đặt `--ds-x` trên phần tử gốc của vùng cần thoáng hơn. Mọi component bên trong nhận giá trị đó.

```css
/* Cả một theme */
[data-theme="creative-studio"] {
  --ds-x: 1.125;
}

/* Chỉ một khu vực */
.spacious-panel {
  --ds-x: 1.2;
}
```

```tsx
<section className="spacious-panel">
  <Button size="m">Tạo mới</Button>
</section>
```

Theme iCreative Studio đã đặt sẵn `--ds-x: 1.125`. Các theme còn lại dùng X = 1.

Ở X = 1.2, Button `size="m"` cao 38.4px, padding ngang 14.4px, bo góc 10.37px, khoảng cách icon và chữ 9.6px. Ở theme iCreative Studio (X = 1.125) là 36px, 13.5px, 8.54px và 9px.

Chỉ một component cần to hơn thì chọn bậc `size` lớn hơn, đừng đặt X riêng cho nó. Khi X chung chưa hợp với một component, các biến số đo riêng của component (vd. `--ds-menu-item-height`, `--ds-sidebar-item-height`) vẫn ghi đè được.

## Caveats

- **Menu, popover, tooltip và modal không nhận X của khu vực.** Radix render chúng ở cuối `body`, ngoài phần tử đặt `--ds-x`. Select và Chip có prop `portalContainer` để render vào trong khu vực; các trường hợp khác thì đặt X trên `<html>` (hoặc theo theme) thay vì một khu vực.
- **Cần trình duyệt có hàm `pow()` của CSS:** Chrome, Edge 120+, Firefox 118+, Safari 15.4+. Trình duyệt cũ hơn bỏ qua các class `radius_*`, góc sẽ vuông.
