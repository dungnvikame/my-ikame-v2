# Spacing & Radius

> Thang bo góc, bo góc theo cỡ control, khoảng cách giữa các khối và padding bên trong component của Core DS.

Hai thang quyết định một màn hình trông gọn hay rời rạc: các phần tử cách nhau bao xa, và góc của chúng bo bao nhiêu. Core DS có token cho bo góc và cho kích thước bên trong component. Khoảng cách _giữa_ các component dùng thang 4px của Tailwind.

Giá trị bo góc và kích thước trong các bảng dưới đây đọc trực tiếp từ CSS của `@coreds/ui`.

## Radius scale

Tám bậc. Mỗi bậc có một class `radius_*` và một token `--ds-radius-*`.

| Class | Value | CSS variable | Usage | Used in |
| --- | --- | --- | --- | --- |
| `radius_2` | 2px | `--ds-radius-2` | Mảng rất nhỏ, nơi đường cong gần như không nhìn thấy. | — |
| `radius_4` | 4px | `--ds-radius-4` | Thứ nằm bên trong thứ khác, và các control nhỏ nhất. | Tooltip, Checkbox, Chip, Badge khi rounded={false}, tag trong Select, InputPinCode cỡ s |
| `radius_6` | 6px | `--ds-radius-6` | Mặc định cho control. | Input, Textarea, Select, dòng menu, tab, nút của SegmentedControl, mục Sidebar, ô ngày của Calendar, Skeleton |
| `radius_8` | 8px | `--ds-radius-8` | Khung chứa control bên trong: popover, menu, panel nhỏ. | Popover, menu của Select và DropdownMenu, Calendar, Alert, Toast, khung Tabs và SegmentedControl, DataTable khi bordered |
| `radius_12` | 12px | `--ds-radius-12` | Card và hộp thoại, những khối có padding riêng. | Card, Modal |
| `radius_16` | 16px | `--ds-radius-16` | Bề mặt cấp trang, như khối lớn có viền chứa danh sách hoặc bảng. | — |
| `radius_24` | 24px | `--ds-radius-24` | Panel rất lớn. Hiếm dùng. | — |
| `radius_round` | 625rem | `--ds-radius-round` | Thứ phải trông như hình tròn hoặc bo tròn hai đầu. | Avatar, Badge, Chip khi pill, Switch, RadioGroup, Progress, Slider, Steps, NotiBadge, thanh cuộn của ScrollArea |

Trong JSX dùng class. Khi viết CSS, dùng token:

```tsx
<div className="radius_8 border border_secondary p-4">…</div>
```

```css
.panel {
  border-radius: var(--ds-radius-12);
}
```

### Lớp ngoài bo nhiều hơn lớp trong

Quy tắc giữ cho màn hình nhất quán: bề mặt càng ở ngoài thì bo càng nhiều. Control `radius_6` nằm trong khung `radius_8`, khung đó nằm trong card `radius_12`. Đừng làm ngược lại, vì góc của lớp trong sẽ cắt vào góc của lớp ngoài.

Bo góc lồng nhau, mỗi lớp ngoài tròn hơn lớp nó chứa: khối ngoài `radius_16` → Card `radius_12` → khung Tabs `radius_8` → tab đang chọn `radius_6`.

## Radius by control size

Bo góc vừa với nút cao 24px sẽ trông cùn trên nút cao 48px. Vì vậy Button không dùng một bậc cố định mà lấy bo góc theo `size`, qua class `radius_button_*`. Đường cong nhờ đó giữ đúng tỉ lệ với nút.

| Class | Value |
| --- | --- |
| `radius_button_xs` | 4px |
| `radius_button_s` | 6px |
| `radius_button_m` | 6px |
| `radius_button_l` | 8px |
| `radius_button_xl` | 8px |

Các component khác:

- `IconToggle` dùng cùng token bo góc với Button ở từng size.
- `InputPinCode` đổi bo góc theo size: `s` là `radius_4`, `m` là `radius_6`, `l` là `radius_8`.
- `Input`, `Textarea` và `Select` giữ `radius_6` ở mọi size.
- `Chip` dùng `radius_4`, hoặc `radius_round` khi đặt `pill`. Chip `variant="check"` và `variant="selector"` luôn bo tròn hai đầu.
- `Badge` mặc định là `radius_round`. Đặt `rounded={false}` để về `radius_4`.

Thang size còn có token `--ds-size-*-size-border-radius-adaptive` (6, 6, 6, 8, 8px từ `xs` đến `xl`). Token này chưa có class riêng và chưa component nào dùng. Cần thì dùng thẳng biến CSS, ví dụ `rounded-[var(--ds-size-l-size-border-radius-adaptive)]`.

## Spacing scale

Core DS không có token khoảng cách. Khoảng cách giữa các component dùng thang của Tailwind, mỗi bậc 4px. Hãy giữ trong thang: mọi khoảng cách trên màn hình là bội của 4, và 8, 16, 24 làm phần lớn công việc. Bậc `0.5` (2px) chỉ dành cho khe rất nhỏ.

| Step | Value | Usage |
| --- | --- | --- |
| `0.5` | 2px | Khe rất nhỏ, như khoảng hở giữa khung SegmentedControl và các nút bên trong. |
| `1` | 4px | Bên trong một control: nhãn, ô nhập và dòng gợi ý của Field; padding của khung menu. |
| `1.5` | 6px | Chỗ dày đặc: padding ngang của Tooltip, icon với chữ trong Chip cỡ m và l. |
| `2` | 8px | Bậc dùng nhiều nhất: icon với chữ trong Button, các nút cạnh nhau, padding của Popover. |
| `3` | 12px | Giữa các phần liên quan: icon với nội dung trong Alert, padding ngang của dòng menu. |
| `4` | 16px | Padding của Alert, padding ngang ô DataTable, khoảng cách giữa các field trong form. |
| `5` | 20px | Lề ngang của Modal trên màn hình nhỏ. |
| `6` | 24px | Padding của CardHeader và CardContent; khoảng cách giữa các card, giữa tiêu đề và khối bên dưới. |
| `8` | 32px | Lề ngang của Modal từ breakpoint sm; lề trang trên màn hình rộng. |
| `10` | 40px | Giữa các phần lớn của một trang. |
| `16` | 64px | Cuối trang cuộn, để dòng cuối không dính sát mép dưới. |

```tsx
// Đúng thang
<div className="flex items-center gap-2 px-4 py-3">…</div>

// Lệch thang: 5px và 13px không thuộc bậc nào
<div className="flex items-center gap-[5px] px-[13px]">…</div>
```

## Component padding

Padding bên trong control không phải do bạn chọn. Nó đi theo thang size, nên mọi component cùng loại và cùng size trông như nhau. Truyền prop `size` thì chiều cao, padding ngang và bo góc đổi cùng lúc.

| Component | Property | xs | s | m | l | xl |
| --- | --- | --- | --- | --- | --- | --- |
| Button | Chiều cao | 24px | 28px | 32px | 40px | 48px |
| Button | Padding ngang | 8px | 10px | 12px | 16px | 18px |
| Button | Bo góc (`radius_button_*`) | 4px | 6px | 6px | 8px | 8px |
| Input, Select | Chiều cao | 32px | 36px | 40px | 48px | 56px |
| Input, Select | Padding ngang | 10px | 12px | 16px | 16px | 20px |
| Chip | Chiều cao (`h_chip_*`) | 24px | 28px | 32px | 40px | 48px |
| Chip | Padding ngang (`px_chip_*`) | 8px | 10px | 12px | 14px | 16px |
| Chip | Padding phải khi có icon cuối (`pr_chip_icon_*`) | 4px | 6px | 8px | 10px | 12px |
| Badge | Chiều cao | 18px | 20px | 24px | 28px | 32px |
| Badge | Padding ngang | 6px | 7px | 8px | 12px | 14px |
| SegmentedControl | Chiều cao (`h_segmented_button_*`) | 22px | 26px | 32px | 36px | — |
| SegmentedControl | Padding ngang (`px_segmented_button_*`) | 8px | 10px | 12px | 14px | — |

Đơn vị là px. Dấu `*` trong tên token và class là tên size, ví dụ `--ds-size-m-size-button` hay `h_chip_m`. Muốn control to hay nhỏ hơn thì đổi `size`, đừng ghi đè bằng `h-*` hay `px-*`.

Những component sau không theo thang năm cỡ này:

- Dòng menu trong `Select` và `DropdownMenu` không có size, luôn là `px-3 py-2`.
- `DataTable` có hai cỡ ô: `size="default"` (`px-4 py-3`) và `size="compact"` (`px-3 py-1.5`).
- `Checkbox`, `RadioGroup`, `Switch` và `Progress` không có chữ để căn theo, nên dùng thang ba cỡ riêng: `sm`, `md`, `lg`.

## Hai lỗi hay gặp

Cả hai đều từng gặp trong một app thật dùng bộ thư viện này, và không lỗi nào hiện thành thông báo.

### Class bo góc không tồn tại

`radius_full` và `radius_0` không có trong Core DS. Class vẫn nằm trong markup nhưng không có CSS nào đi kèm, nên góc giữ nguyên và không ai để ý. Thang chỉ có các bậc ở trên, từ `radius_2` đến `radius_24` và `radius_round`.

```tsx
// Không có tác dụng: hai class này không tồn tại
<img className="size-10 radius_full" src={src} alt="" />
<Card className="radius_0">…</Card>

// Đúng
<img className="size-10 radius_round" src={src} alt="" />
<Card className="rounded-none!">…</Card>
```

Bo tròn hẳn (ảnh đại diện, chấm tròn, bo tròn hai đầu) dùng `radius_round`. Góc vuông dùng `rounded-none` của Tailwind. Khi bỏ bo góc có sẵn của một component, thêm `!` như ở ví dụ trên (xem lưu ý cuối trang).

### Hai đường bo trên cùng một cạnh

Component tự vẽ viền và bo góc, đặt trong một khung cũng có viền và bo góc, sẽ cho hai đường cong cách nhau một pixel. Nhìn như một đường viền dày và nhòe. Hãy bỏ viền, bo góc và bóng của lớp trong.

```tsx
// Card đã có viền và radius_12, bảng bên trong không vẽ thêm khung
<Card>
  <DataTable columns={columns} data={data} bordered={false} />
</Card>
```

> **Ghi đè bo góc và bóng cần dấu !**
>
> `cn` không gộp `radius_*` hay `shadow_*` với `rounded-*` hay `shadow-*` của Tailwind. Truyền
> `className="rounded-none"` vào component có sẵn `radius_12` thì phần tử mang cả hai class. Class
> nào thắng là do thứ tự trong CSS, không do thứ tự trong `className`. Ví dụ trong stylesheet của
> Core DS, `shadow-none` đứng trước các class `shadow_*` nên bị chúng đè. Viết `rounded-none!` và
> `shadow-none!` để kết quả không phụ thuộc thứ tự. Riêng `Card` có sẵn prop `shadow="none"`.
