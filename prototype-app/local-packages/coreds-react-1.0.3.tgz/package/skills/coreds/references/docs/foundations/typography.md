# Typography

> Thang chữ Headline và Body của Core DS trên font Inter, cùng cách chọn class theo vai trò của chữ.

Core DS có hai thang chữ: Headline cho tiêu đề, Body cho chữ trong giao diện. Mỗi class đặt cùng lúc font, cỡ chữ, chiều cao dòng, giãn chữ và độ đậm, khớp với trang Typography trong Figma.

Số liệu dưới đây đọc trực tiếp từ CSS của `@coreds/ui`.

## Headline

Độ đậm cố định 600. Dùng cho tiêu đề trang và tiêu đề khu vực.

| Class | Font size | Line height | Letter spacing | Font weight |
| --- | --- | --- | --- | --- |
| `headline_xl` | 48px | 56px | -0.72px | 600 |
| `headline_l` | 40px | 50px | -0.6px | 600 |
| `headline_m` | 32px | 40px | -0.32px | 600 |
| `headline_s` | 28px | 36px | -0.14px | 600 |
| `headline_xs` | 24px | 30px | -0.12px | 600 |

## Body

Độ đậm 400. Dùng cho chữ trong giao diện: đoạn văn, nhãn, nội dung bảng, chú thích.

| Class | Font size | Line height | Letter spacing | Font weight |
| --- | --- | --- | --- | --- |
| `body_xl` | 20px | 28px | 0 | 400 |
| `body_l` | 18px | 26px | 0 | 400 |
| `body_m` | 16px | 24px | 0.16px | 400 |
| `body_s` | 14px | 22px | 0.14px | 400 |
| `body_xs` | 12px | 19px | 0.3px | 400 |
| `body_xxs` | 10px | 16px | 0.3px | 400 |

> **Note**
>
> Figma ghi giãn chữ theo phần trăm cỡ chữ. CSS đổi giá trị đó sang `rem`, nên bảng trên ghi cả phần
> trăm lẫn số pixel tương ứng.

## Font weight

`font_semibold` đưa độ đậm lên 600. Thêm nó vào class Body khi cần nhấn mạnh: nhãn, tiêu đề nhỏ, tiêu đề cột. Headline đã ở 600 nên không cần thêm.

Thứ tự trong `className` không quan trọng: `font_semibold` nằm sau các class Body trong stylesheet nên luôn thắng.

Các class `body_*` có font-weight 400. Thêm `font_semibold` (font-weight 600) để in đậm vừa, ví dụ `className="body_s font_semibold"`.

## Font

Mọi class typography dùng Inter, bản variable (`Inter Variable`). Font đi kèm stylesheet của `@coreds/ui`, không cần tải từ Google Fonts hay thêm thẻ `<link>`. Mỗi bộ ký tự là một file riêng; trình duyệt chỉ tải bộ mà trang dùng tới, thường là Latin và tiếng Việt.

Nếu font chưa tải xong, chữ hiển thị bằng font hệ thống (`system-ui`, `Segoe UI`, `Roboto`…) cho tới khi Inter sẵn sàng.

## Usage

Chọn class theo vai trò của chữ, không theo cỡ pixel. Ghép với class màu chữ như `text_primary`, `text_secondary`, `text_tertiary` (xem [Colors](./colors.md)).

```tsx title="workspace-header.tsx"
export function WorkspaceHeader() {
  return (
    <header className="flex flex-col gap-1">
      <h1 className="headline_m text_primary">Tạo không gian làm việc</h1>
      <p className="body_m text_secondary">Mời thành viên sau khi tạo xong.</p>
      <span className="body_s font_semibold text_primary">Tên không gian</span>
    </header>
  )
}
```

Không thay các class này bằng `text-*`, `font-*`, `leading-*` hay `tracking-*` của Tailwind. Ví dụ `text-sm` cũng cho chữ 14px nhưng chiều cao dòng 20px và không giãn chữ, trong khi `body_s` là 22px và giãn 1%. Chữ sẽ lệch so với component và so với Figma.

Component của `@coreds/ui` đã gắn sẵn class. Có thể lấy làm mốc khi tự dựng giao diện:

| Phần tử                              | Class                  |
| ------------------------------------ | ---------------------- |
| Tiêu đề `Drawer`                     | `body_l font_semibold` |
| Tiêu đề `Card`, `Modal`              | `body_m font_semibold` |
| Mô tả `Modal`                        | `body_s`               |
| Nhãn và chú thích dưới ô của `Field` | `body_s`               |
