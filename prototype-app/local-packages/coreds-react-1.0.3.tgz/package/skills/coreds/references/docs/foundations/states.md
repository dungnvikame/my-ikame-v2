# States

> Màu hover và nhấn được trộn từ chính màu nền của component theo bốn mức cố định, và tự đổi chiều theo theme.

Màu hover và màu nhấn không phải token riêng. Class state lấy token mà bề mặt đang dùng, rồi trộn thêm một tỉ lệ cố định của **màu trộn** (mix color) vào lúc render, trong không gian màu oklab. Màu trộn là đen ở theme sáng và trắng ở theme tối. Nhờ vậy một class dùng được cho cả sáu theme: trên theme sáng nó làm màu tối đi, trên theme tối nó làm màu sáng lên. Không ai phải khai báo thêm giá trị thứ hai.

## Formula

```css
/* .state_bg_button_primary_soft biên dịch ra */
background-color: color-mix(
  in oklab,
  var(--ds-bg-button-primary) 100%,
  var(--ds-mix-color) var(--ds-mix-soft) /* 5% */
);
```

Trộn trong `oklab` thay vì sRGB giữ cho kết quả đều theo cảm nhận của mắt: trộn 5% làm một bề mặt nhạt và một bề mặt đậm lệch đi gần như cùng một mức. Trộn RGB thông thường không làm được điều đó.

## Playground

Chọn token nền, màu trộn và tỉ lệ, rồi đọc màu mà trình duyệt thực sự tính ra. Nền ca-rô hiện qua ở những chỗ kết quả còn kênh alpha. Khi tỉ lệ trùng một mức có sẵn và màu trộn để "Theo theme", khung code hiện đúng class tương ứng.

## Levels

Có bốn mức, khai báo một lần trong `packages/ui/state-mix.config.json`. Mỗi mức là một biến CSS: `--ds-mix-subtle`, `--ds-mix-soft`, `--ds-mix-medium`, `--ds-mix-strong`.

| Mức      | Tỉ lệ | Tỉ lệ thực | Dùng cho                                                                           |
| -------- | ----- | ---------- | ---------------------------------------------------------------------------------- |
| `subtle` | 3%    | 2,91%      | Hover của component nhạt. Mức nhẹ nhất, đủ báo là bấm được mà không làm rối trang. |
| `soft`   | 5%    | 4,76%      | Nhấn của component nhạt. Nặng hơn hover một bậc để nhấn tách khỏi hover.           |
| `medium` | 7%    | 6,54%      | Hover của component tương phản. Trên nền đậm, hai mức nhẹ gần như không thấy.      |
| `strong` | 9%    | 8,26%      | Nhấn của component tương phản. Mức nặng nhất.                                      |

"Tỉ lệ thực" là phần màu trộn sau khi trình duyệt chuẩn hoá, giải thích ở phần Figma và code bên dưới.

Chọn mức gồm hai bước, và bước đầu không liên quan đến tương tác mà đến màu sẵn có của component. Lệch 3% thấy rõ trên một nút xám nhạt nhưng gần như biến mất trên một nút màu đậm, nên mỗi nhóm màu có cặp mức riêng:

- **Component nhạt** (nút dim, nền tertiary, accent nhạt) dùng `subtle` và `soft`.
- **Component tương phản** (nút primary, accent đặc, badge tô màu) dùng `medium` và `strong`.

Trong mỗi cặp, mức nhẹ hơn cho hover, mức nặng hơn cho nhấn. Mỗi hàng dưới đây là màu gốc rồi lần lượt bốn mức, dùng đúng class `state_bg_*` mà thư viện xuất ra:

| Level | Mix | Effective |
| --- | --- | --- |
| `subtle` | 3% | 2.91% |
| `soft` | 5% | 4.76% |
| `medium` | 7% | 6.54% |
| `strong` | 9% | 8.26% |

Class theo mẫu `state_{token}_{level}`, ví dụ `state_bg_button_primary_soft`, `state_bg_accent_secondary_soft`. Nền trong suốt dùng `state_bg_transparent_{level}`.

## Naming

Class theo mẫu `state_[kênh]_[tên]_[mức]`, trong đó `[tên]` là tên token đã bỏ tiền tố của kênh:

| Kênh     | Thuộc tính CSS     | Sinh cho                             |
| -------- | ------------------ | ------------------------------------ |
| `bg`     | `background-color` | Mọi token `bg_*`, thêm `transparent` |
| `fg`     | `color`            | Mọi token `text_*`, `icon_*`, `fg_*` |
| `border` | `border-color`     | Mọi token `border_*`                 |

Ví dụ ở mức `soft`:

- `bg_button_primary` → `state_bg_button_primary_soft`
- `text_primary` → `state_fg_primary_soft`
- `fg_link` → `state_fg_link_soft`
- `border_primary` → `state_border_primary_soft`

Kênh `fg` gom ba tiền tố nên có thể trùng tên. Khi đó token đến sau giữ nguyên tên đầy đủ: `icon_primary` thành `state_fg_icon_primary_soft`, `text_error` thành `state_fg_text_error_soft`. Với token `fg`, nên tra tên class trong `@coreds/ui/style.css` trước khi dùng.

Mỗi class có thêm hai biến thể `hover:` và `active:`, và gần như lúc nào cũng nên dùng biến thể. Class trần áp màu vô điều kiện, tức chỉ là một màu nghỉ khác. Các biến thể này được viết sẵn trong CSS của thư viện chứ không do Tailwind sinh, nên chỉ có hai biến thể đó, theo `pseudos` trong config.

```tsx
import { cn } from "@coreds/react"

export function SaveButton() {
  return (
    <button
      className={cn(
        "bg_button_primary fg_on_accent_primary",
        "hover:state_bg_button_primary_soft active:state_bg_button_primary_medium"
      )}
    >
      Lưu
    </button>
  )
}
```

Các biến thể của `Button` dùng những cặp sau:

| Biến thể                               | Màu nghỉ                     | Hover    | Nhấn     |
| -------------------------------------- | ---------------------------- | -------- | -------- |
| `primary`                              | `bg_button_primary`          | `soft`   | `medium` |
| `primary2`                             | `bg_accent_secondary`        | `soft`   | `medium` |
| `secondary`                            | `bg_button_secondary`        | `subtle` | `soft`   |
| `secondary2`                           | `bg_accent_secondary_subtle` | `subtle` | `soft`   |
| `dim`                                  | `bg_button_tertiary`         | `subtle` | `soft`   |
| `danger`                               | `bg_error`                   | `subtle` | `soft`   |
| `border`, `subtle`, `borderlessSubtle` | `bg-transparent`             | `subtle` | `soft`   |

Rê chuột và nhấn giữ từng nút để xem:

> **Khác với state_primary_* và state_neutral_***
>
> Thư viện còn các class như `state_primary_soft`, `state_error_medium`, `state_neutral_max` hay
> `state_mix`. Chúng tô `background-color` bằng một token màu bán trong suốt có sẵn từ Figma
> (`--ds-state-primary-soft`…), không trộn với màu nền của component. Class trộn màu luôn có kênh
> ngay sau `state_`: `state_bg_`, `state_fg_`, `state_border_`.

## Figma và code mô tả cùng một thứ

Trong Figma, state là một **lớp phủ bán trong suốt** màu đen hoặc trắng (biến `state_mix`) đặt lên màu của component, và mức chính là độ mờ của lớp phủ đó. Trong code không có lớp thứ hai: `color-mix` tính ra cùng kết quả dưới dạng một màu duy nhất. Đây là hai kỹ thuật khác nhau cho cùng một kết quả, nên tỉ lệ ở hai bên khớp nhau.

Một hệ quả cần biết: màu thứ nhất trong `color-mix` luôn là `100%`, mức là tỉ lệ thứ hai. Tổng hai tỉ lệ vượt 100% nên trình duyệt chuẩn hoá lại: `100%` với `5%` thành 5/105, tức khoảng 4,76% màu trộn. Chênh lệch nhỏ giữa mức khai báo và mức hiển thị (cột "Tỉ lệ thực" ở trên) đến từ đây.

## Theme đổi màu trộn

Tỉ lệ giữ nguyên, chỉ màu trộn đổi theo theme. Rút gọn từ `theme.css`:

```css
:root,
.theme-high-contrast-light,
.theme-olive,
.theme-sunset {
  --ds-mix-color: #000000;
}

.dark,
.theme-deep-forest {
  --ds-mix-color: #ffffff;
}
```

Mỗi class theme còn một selector tương đương dạng `[data-theme="..."]`, ví dụ `[data-theme="dark"]`. Màu trộn của từng theme lấy từ biến `state_mix` trong file token Figma. `mixColor` trong `state-mix.config.json` (đen cho sáng, trắng cho tối) chỉ được dùng khi file token thiếu biến đó.

Đổi giao diện sáng/tối của trang này rồi rê chuột lên các nút ở trên: cùng class, theme sáng làm tối, theme tối làm sáng. Các khung dưới đây áp từng class theme lên một vùng riêng nên xem được mọi theme cùng lúc. Chấm tròn cạnh tên là màu trộn của theme đó. Mỗi dải là màu gốc rồi `subtle`, `soft`, `medium`, `strong`.

Theme sáng mặc định khai báo ở `:root`, chính là theme của trang này ở chế độ sáng.

## Transparent background

Control không có nền riêng thì không có token nào để trộn. Trộn từ một token không liên quan sẽ kéo theo sắc màu của token đó: ở theme Deep forest, `bg_button_tertiary` có màu xanh lá, nên một nút trong suốt trộn từ token này sẽ ngả xanh khi hover (so hai dải trong khung Deep forest ở trên). Vì vậy các control này trộn từ `transparent`, cho ra một lớp màu trung tính ở mọi theme.

```tsx
<button
  className={cn(
    "bg-transparent text_primary",
    "hover:state_bg_transparent_subtle active:state_bg_transparent_soft"
  )}
>
  Huỷ
</button>
```

Biến thể `border`, `subtle` và `borderlessSubtle` của `Button` dùng cách này.

## Nguyên tắc

- Dùng biến thể `hover:` và `active:`, không dùng class trần. Class trần là một màu nghỉ.
- Trộn từ đúng token mà bề mặt đang dùng. Ghép `bg_button_primary` với `hover:state_bg_button_secondary_soft` cho ra một màu không thuộc về bên nào.
- Chọn cặp mức theo màu của component, rồi chọn mức theo tương tác. Component nhạt đi `subtle` → `soft`, component tương phản đi `medium` → `strong`. Dù chọn cặp nào, hover và nhấn luôn cách nhau một bậc. Chính một bậc đó làm nhấn trông như một trạng thái riêng, không chỉ là hover đậm hơn.
- Nút đặc của thư viện (`primary`, `primary2`) đứng thấp hơn cặp tương phản một bậc, ở `soft` → `medium`. Trên nền bão hoà, các mức nặng trông đục chứ không giống đang nhấn, nên cặp nhẹ hơn là lựa chọn có chủ ý.
- Không viết cứng màu hover. Một mã hex chỉ đúng ở một trong sáu theme và sai ở năm theme còn lại mà không ai báo.
