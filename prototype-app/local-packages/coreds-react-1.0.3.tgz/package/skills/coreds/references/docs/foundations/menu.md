# Menu

> Bề mặt, khoảng cách và màu hover, nhấn dùng chung cho menu của Select và DropdownMenu.

Select và DropdownMenu giữ hành vi riêng, nhưng vẽ menu bằng cùng một lớp giao diện: bề mặt, khoảng cách của từng dòng và màu hover, nhấn. Sửa lớp này thì cả hai component đổi theo.

## Menu surface

Rê chuột lên từng dòng để xem màu hover, bấm giữ để xem màu nhấn.

## Shared tokens

| Phần      | Token                                                                                                              |
| --------- | ------------------------------------------------------------------------------------------------------------------ |
| Surface   | `bg_primary`, `border_secondary`, `shadow_subtle_l`, `radius_8`, padding 4px                                       |
| Item      | `body_s`, `text_primary`, `radius_6`                                                                               |
| Item size | Cao 38px, padding ngang 12px, dọc 8px, khoảng cách icon và chữ 8px, nhân với [hệ số X](./x-factor.md) |
| Hover     | `state_bg_transparent_subtle` (3%)                                                                                 |
| Active    | `state_bg_transparent_soft` (5%)                                                                                   |
| Separator | `bg_tertiary`, cao 1px                                                                                             |
| Disabled  | Mờ 50%, không bấm được                                                                                             |

Số đo của dòng nằm ở các biến `--ds-menu-item-height`, `--ds-menu-item-padding-inline`, `--ds-menu-item-padding-block` và `--ds-menu-item-content-gap`.

## Usage

Menu tự dựng, ví dụ danh sách lựa chọn trong một Popover, dùng cùng variant để trông như Select và DropdownMenu:

```tsx
import { dropdownMenuContentVariants, dropdownMenuItemVariants } from "@coreds/react"

export function QuickActions() {
  return (
    <div className={dropdownMenuContentVariants()}>
      <button type="button" className={dropdownMenuItemVariants()}>
        Đổi tên
      </button>
      <button type="button" className={dropdownMenuItemVariants()}>
        Nhân bản
      </button>
    </div>
  )
}
```

Cần đủ hành vi bàn phím, đóng khi bấm ra ngoài và vị trí tự lật thì dùng [DropdownMenu](../../components/dropdown-menu.md) thay vì tự dựng.
