# LLMs.txt

> Docs Core DS dạng Markdown cho AI assistant đọc, gồm llms.txt, llms-full.txt và bản Markdown của từng trang.

Core DS có sẵn docs dạng text theo chuẩn [llms.txt](https://llmstxt.org) cho AI assistant như Claude, ChatGPT hay Cursor. Nội dung giống trang web: code ví dụ, bảng props và bảng token đều được viết thành chữ.

## Files

| File                               | Nội dung                                                                                             |
| ---------------------------------- | ---------------------------------------------------------------------------------------------------- |
| [`/llms.txt`](/llms.txt)           | Mục lục: giới thiệu ngắn, cách cài, quy tắc style chính, link tới Markdown của từng trang theo nhóm. |
| [`/llms-full.txt`](/llms-full.txt) | Toàn bộ docs trong một file.                                                                         |

Đường dẫn tính từ địa chỉ trang docs. Context của assistant nhỏ thì đưa `/llms.txt` để nó tự mở trang cần; đủ lớn thì đưa `/llms-full.txt`.

## Per-page Markdown

Mỗi trang có nút **Copy Markdown** và **View as Markdown** dưới tiêu đề. Đường dẫn là `/md` cộng đường dẫn trang cộng `.md`:

```txt
/components/button        →   /md/components/button.md
/editor/notion-like       →   /md/editor/notion-like.md
```

Trang component có dòng import, code của từng ví dụ và bảng props sinh từ type. Trang Foundations có bảng token kèm giá trị ở theme light và dark.

## Integration

Docs Core DS ở https://ui.ikameglobal.com.

**Claude, ChatGPT và assistant khác:** dán link vào cuộc trò chuyện.

```txt
Dùng docs Core DS ở https://ui.ikameglobal.com/llms.txt khi viết UI.
```

**Cursor:** thêm docs bằng `@Docs`.

```txt
@Docs https://ui.ikameglobal.com/llms-full.txt
```

Chỉ hỏi về một component thì bấm **Copy Markdown** ở trang đó rồi dán vào.

> **Agent làm việc trong repo của app**
>
> Claude Code, Codex hay Cursor đang sửa code của app thì dùng [Agent
> Skills](./agent-skills.md): docs nằm sẵn trên máy, khớp version đang cài, không cần mạng.
