# AGENTS.md

> Đoạn quy tắc Core DS để dán vào AGENTS.md hoặc CLAUDE.md của app, để agent nhớ cả khi chưa mở skill.

`AGENTS.md` là file hướng dẫn ở gốc repo mà phần lớn AI coding agent tự đọc khi bắt đầu làm việc; Claude Code đọc `CLAUDE.md`. Dán đoạn dưới đây để agent luôn theo quy tắc Core DS, kể cả agent không hỗ trợ [Agent Skills](./agent-skills.md).

## Snippet

```md title="AGENTS.md"
## UI

- Giao diện dùng Core DS (`@coreds/react`). Trước khi viết UI, đọc
  `node_modules/@coreds/react/skills/coreds/SKILL.md`. Docs của từng component nằm ở
  `references/components/<id>.md` trong cùng thư mục.
- Có component Core DS thì dùng, không tự dựng lại bằng `div` và Tailwind.
- Màu, chữ, bo góc, bóng dùng class token (`bg_primary`, `text_secondary`, `border_secondary`,
  `body_s`, `radius_12`, `shadow_m`) hoặc `var(--ds-*)`. Không dùng màu Tailwind hay mã hex.
- Hover và nhấn: `hover:state_bg_<token>_soft active:state_bg_<token>_medium`, với `<token>` là
  nền đang dùng.
- Kích cỡ control chọn bằng prop `size`, không ghi đè `h-*` hay `px-*`.
```

Đường dẫn trong `node_modules` luôn khớp version đang cài, nên không cần sửa đoạn này khi nâng `@coreds/react`.

## Claude Code

Claude Code đọc `CLAUDE.md`. Để hai file dùng chung một nội dung, tạo `CLAUDE.md` chỉ có một dòng import:

```md title="CLAUDE.md"
@AGENTS.md
```

## Core DS repo

Repo Core DS có `AGENTS.md` và `CLAUDE.md` riêng ở thư mục gốc, cho agent sửa chính thư viện: cấu trúc gói, lệnh build và test, quy ước code, các bước thêm component.
