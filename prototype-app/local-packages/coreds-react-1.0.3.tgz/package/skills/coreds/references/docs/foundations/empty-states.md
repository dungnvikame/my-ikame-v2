# Empty States

> Năm hình minh hoạ cho danh sách trống, thiếu dữ liệu và không có quyền xem, kèm cách ghép với tiêu đề, mô tả và nút hành động.

Hình minh hoạ cho lúc màn hình chưa có gì để hiện: danh sách trống, chưa có dữ liệu, hoặc người dùng không có quyền xem. Mỗi hình giữ bảng màu gốc từ Figma, không đổi theo theme, giống logo hay mascot.

## Illustrations

Bấm **Copy SVG** hoặc **Download** để lấy file, lưu vào app (vd. `src/assets/empty-states/`). Hình chưa nằm trong gói npm nào.

| Illustration | Usage | File |
| --- | --- | --- |
| Documents | Chưa có tài liệu, file hay báo cáo nào cho bản ghi. | `empty-state-documents.svg` |
| Chat / feedback | Chưa có tin nhắn, bình luận hay góp ý. | `empty-state-chat-feedback.svg` |
| Goal setting | Chưa đặt mục tiêu, chỉ tiêu hay OKR nào. | `empty-state-goal-setting.svg` |
| Generic | Dùng cho mọi danh sách trống khi không có hình nào hợp hơn. | `empty-state-generic.svg` |
| No permission | Người dùng không có quyền xem nội dung này. | `empty-state-no-permission.svg` |

## Usage

Một empty state gồm hình, một tiêu đề ngắn, một câu mô tả, và nút hành động nếu người dùng tự sửa được tình trạng đó.

```tsx
import { Button } from "@coreds/react"
import emptyReports from "@/assets/empty-states/empty-state-documents.svg"

export function ReportsEmpty({ onCreate }: { onCreate: () => void }) {
  return (
    <div className="flex flex-col items-center gap-3 px-6 py-12 text-center">
      <img src={emptyReports} alt="" className="h-28" />
      <p className="headline_xs text_primary">Chưa có báo cáo nào</p>
      <p className="max-w-sm body_s text_secondary">
        Báo cáo tuần sẽ hiện ở đây sau khi bạn tạo báo cáo đầu tiên.
      </p>
      <Button size="m" onClick={onCreate}>
        Tạo báo cáo
      </Button>
    </div>
  )
}
```

## Rules of thumb

- Chọn hình theo nội dung đang trống, không theo màu. Không có hình nào khớp thì dùng **Generic**.
- Hình là trang trí: để `alt=""` và để tiêu đề nói điều đang xảy ra.
- Không tô lại hình bằng class token như `icon_secondary`; hình có bảng màu riêng.
- Không có quyền xem thì dùng **No permission** và nói người dùng cần làm gì (xin quyền ai), không chỉ báo lỗi.
- Ô trống nhỏ (một dòng trong bảng, một ô lọc không có kết quả) chỉ cần một dòng chữ `body_s text_secondary`, không cần hình.
