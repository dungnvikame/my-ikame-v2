# Colors

> Token màu chức năng, bảng màu mở rộng, đổ bóng và sáu theme dựng sẵn của Core DS, cùng cách đổi theme trong app.

Mỗi màu trong Core DS là một CSS variable `--ds-*` kèm một utility class cùng tên, viết bằng dấu gạch dưới: `--ds-bg-primary` đi với `bg_primary`, `--ds-text-secondary` đi với `text_secondary`. Theme chỉ đổi giá trị của các biến, nên giao diện dựng bằng token tự đổi theo.

Ô màu trên trang này đọc thẳng `var(--ds-…)`. Dòng thứ ba cạnh mỗi ô là giá trị ở theme đang bật. Chuyển trang giữa giao diện sáng và tối để thấy giá trị đổi.

## Quy tắc chung

- Dùng class token hoặc `var(--ds-…)`. Màu Tailwind (`bg-white`, `text-gray-900`) và mã hex viết tay không đổi theo theme.
- Chọn token theo vai trò, không theo màu đang thấy. `bg_canvas_primary` trùng màu `bg_primary` ở bốn theme sáng nhưng khác ở `dark` và `deep-forest`.
- Chữ trên nền màu dùng token `fg_on_*` tương ứng, không gán cứng màu trắng. Theme `olive` đổi `fg_on_accent_primary` thành xanh lá đậm, hai theme tối đổi `fg_on_contrast` thành xám đậm.
- Hover và nhấn dùng class `state_*`. Thêm `hover:` trước class màu (`hover:bg_secondary`) không có tác dụng, vì class màu viết sẵn trong CSS của thư viện chứ không do Tailwind sinh ra. Chi tiết ở trang [States](./states.md).

```tsx
// Đúng: đổi theo theme
<div className="bg_secondary text_primary border border_secondary" />

// Sai: luôn nền trắng chữ xám, kể cả ở theme tối
<div className="bg-white text-gray-900 border border-gray-200" />

// Cần màu trong style inline hoặc CSS riêng thì dùng biến
<div style={{ boxShadow: "0 0 0 1px var(--ds-border-secondary)" }} />
```

## Background

Core DS có bốn cấp nền, nhưng phần lớn sản phẩm chỉ dùng ba: `bg_tertiary` cho điều hướng và thông tin ít cần chú ý, `bg_secondary` cho khung chứa dùng chung, `bg_primary` cho vùng người dùng đọc và thao tác.

![Ba cấp nền của Core DS: bg_tertiary cho điều hướng, bg_secondary cho khung chứa dùng chung, bg_primary cho vùng người dùng đọc và thao tác](/images/background-levels.png)

### Surface

Bản `_transparent` cùng màu với cấp tương ứng nhưng trong suốt hoàn toàn, hợp làm điểm cuối của dải gradient mờ dần.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `bg_primary` | `--ds-bg-primary` | #FFFFFF | #252422 |  |
| `bg_secondary` | `--ds-bg-secondary` | #FAFAFA | #1D1C1B |  |
| `bg_tertiary` | `--ds-bg-tertiary` | #F0F0EF | #131211 |  |
| `bg_quaternary` | `--ds-bg-quaternary` | #E7E6E4 | #252422 |  |
| `bg_primary_transparent` | `--ds-bg-primary-transparent` | #FFFFFF00 | #25242200 |  |
| `bg_secondary_transparent` | `--ds-bg-secondary-transparent` | #FAFAFA00 | #1D1C1B00 |  |
| `bg_tertiary_transparent` | `--ds-bg-tertiary-transparent` | #F0F0EF00 | #13121100 |  |
| `bg_quaternary_transparent` | `--ds-bg-quaternary-transparent` | #E7E6E400 | #25242200 |  |

### Canvas

Nền của vùng làm việc phía sau nội dung. Ở các theme sáng, `bg_canvas_primary` trùng `bg_primary`, nên cặp này không tách được hai lớp. Cần tách lớp thì dùng `bg_secondary` hoặc viền.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `bg_canvas_primary` | `--ds-bg-canvas-primary` | #FFFFFF | #131211 |  |
| `bg_canvas_secondary` | `--ds-bg-canvas-secondary` | #FAFAFA | #181716 |  |
| `bg_canvas_tertiary` | `--ds-bg-canvas-tertiary` | #F0F0EF | #222120 |  |
| `bg_canvas_quaternary` | `--ds-bg-canvas-quaternary` | #EBEBEA | #32312F |  |

### Interactive

Nền của phần tử bấm được: Chip và IconToggle dùng `bg_interactive_primary`, `bg_interactive_secondary`. `bg_interactive_transparent` là lớp phủ trong mờ, Progress dùng nó làm rãnh.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `bg_interactive_primary` | `--ds-bg-interactive-primary` | #FFFFFF | #383633 |  |
| `bg_interactive_secondary` | `--ds-bg-interactive-secondary` | #F5F5F4 | #3D3B38 |  |
| `bg_interactive_tertiary` | `--ds-bg-interactive-tertiary` | #EBEBEA | #4A4844 |  |
| `bg_interactive_contrast` | `--ds-bg-interactive-contrast` | #D8D6D5 | #6F6B67 |  |
| `bg_interactive_transparent` | `--ds-bg-interactive-transparent` | #00000017 | #FFFFFF17 |  |

### Overlay & Inverse

`bg_inverse` ngược màu với trang: tối ở theme sáng, sáng ở theme tối. Tooltip dùng nó cùng chữ `fg_inverse_primary`. `bg_backdrop` là màn mờ phía sau Modal và Drawer. `bg_overlay` dành cho bề mặt nổi phía trên trang; ở theme `dark` nó sáng hơn `bg_primary` một bậc.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `bg_overlay` | `--ds-bg-overlay` | #FFFFFF | #2A2927 |  |
| `bg_inverse` | `--ds-bg-inverse` | #222120 | #F5F5F4 |  |
| `bg_backdrop` | `--ds-bg-backdrop` | #3D3B3866 | #00000066 |  |

### Component

Nền riêng của nút (`bg_button_*`), ô nhập (`bg_input_*`) và sidebar (`bg_sidebar_*`). Khi tự dựng một phần tử cùng loại, dùng các token này để khớp với component có sẵn. `bg_input_fill_dim_default` là alias của `bg_input_fill_dim`; bước build token thêm nó, Figma không có tên này.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `bg_button_primary` | `--ds-bg-button-primary` | #F76226 | #F76226 |  |
| `bg_button_secondary` | `--ds-bg-button-secondary` | #FEF4F0 | #993706 |  |
| `bg_button_tertiary` | `--ds-bg-button-tertiary` | #F5F5F4 | #2A2927 |  |
| `bg_input_fill` | `--ds-bg-input-fill` | #F5F5F4 | #32312F |  |
| `bg_input_fill_dim` | `--ds-bg-input-fill-dim` | #EEEDEC | #2A2927 |  |
| `bg_input_fill_dim_default` | `--ds-bg-input-fill-dim-default` | #EEEDEC | #2A2927 | tên cũ, trỏ tới `bg_input_fill_dim` |
| `bg_input_light` | `--ds-bg-input-light` | #FFFFFF | #252422 |  |
| `bg_sidebar_primary` | `--ds-bg-sidebar-primary` | #F5F5F4 | #181716 |  |
| `bg_sidebar_secondary` | `--ds-bg-sidebar-secondary` | #F0F0EF | #131211 |  |
| `bg_sidebar_primary_transparent` | `--ds-bg-sidebar-primary-transparent` | #F5F5F400 | #18171600 |  |
| `bg_sidebar_secondary_transparent` | `--ds-bg-sidebar-secondary-transparent` | #F0F0EF00 | #1D1C1B00 |  |

### Accent

Màu nhận diện. Accent primary là cam ở theme mặc định và đổi theo theme: xanh lá ở `olive`, cam đất ở `sunset`. Accent secondary là xanh dương ở cả sáu theme.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `bg_accent_primary` | `--ds-bg-accent-primary` | #F76226 | #F76226 |  |
| `bg_accent_primary_subtle` | `--ds-bg-accent-primary-subtle` | #FEF4F0 | #993706 |  |
| `bg_accent_secondary` | `--ds-bg-accent-secondary` | #0D87F2 | #0D87F2 |  |
| `bg_accent_secondary_subtle` | `--ds-bg-accent-secondary-subtle` | #F6FAFE | #043057 |  |

`--ds-focus-ring` luôn cùng giá trị với `--ds-bg-accent-primary`. Biến này không có utility class, dùng qua `var(--ds-focus-ring)`.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| — | `--ds-focus-ring` | #F76226 | #F76226 | chỉ có CSS variable, không có class |

### Status

Thành công, cảnh báo, lỗi và thông tin. Bản thường là nền nhạt, đi với chữ `fg_*` cùng tên: Badge `variant="success"` dùng `bg_success` và `fg_success`. Bản `_contrast` là nền đậm.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `bg_success` | `--ds-bg-success` | #F6FEF9 | #024C24 |  |
| `bg_success_contrast` | `--ds-bg-success-contrast` | #02B644 | #02B644 |  |
| `bg_warning` | `--ds-bg-warning` | #FFFDF5 | #574404 |  |
| `bg_warning_contrast` | `--ds-bg-warning-contrast` | #CA9C02 | #CA9C02 |  |
| `bg_error` | `--ds-bg-error` | #FEF6F7 | #40070C |  |
| `bg_error_contrast` | `--ds-bg-error-contrast` | #D3222E | #E5616A |  |
| `bg_info` | `--ds-bg-info` | #F6FAFE | #043057 |  |
| `bg_info_contrast` | `--ds-bg-info-contrast` | #0D87F2 | #0D87F2 |  |

## Text & Icon

### Text

`text_primary` cho nội dung chính, `text_secondary` cho chữ phụ, `text_tertiary` cho chú thích và chữ mờ, `text_contrast` khi cần đậm nhất. Bốn class cuối là alias trỏ sang token `fg_*`.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `text_primary` | `--ds-text-primary` | #32312F | #F5F5F4 |  |
| `text_secondary` | `--ds-text-secondary` | #55524E | #D8D6D5 |  |
| `text_tertiary` | `--ds-text-tertiary` | #8A857F | #A4A19D |  |
| `text_contrast` | `--ds-text-contrast` | #131211 | #FFFFFF |  |
| `text_accent_primary` | `--ds-text-accent-primary` | #EC5509 | #FCC8B5 | tên cũ, trỏ tới `fg_accent_primary` |
| `text_error` | `--ds-text-error` | #D3222E | #F49AA0 | tên cũ, trỏ tới `fg_error` |
| `text_inverse_primary` | `--ds-text-inverse-primary` | #FFFFFF | #32312F | tên cũ, trỏ tới `fg_inverse_primary`; đặt trên `bg_inverse` |
| `text_inverse_secondary` | `--ds-text-inverse-secondary` | #D8D6D5 | #55524E | tên cũ, trỏ tới `fg_inverse_secondary`; đặt trên `bg_inverse` |

### Icon

Ở theme mặc định, mỗi cấp icon nhạt hơn cấp chữ cùng tên. Icon trong `@coreds/icons` vẽ bằng `currentColor`, nên class màu đặt thẳng lên icon.

```tsx
import { BellIcon } from "@coreds/react/icons"
;<BellIcon size="s" className="icon_secondary" aria-hidden="true" />
```

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `icon_primary` | `--ds-icon-primary` | #55524E | #F0F0EF |  |
| `icon_secondary` | `--ds-icon-secondary` | #6F6B67 | #EBEBEA |  |
| `icon_tertiary` | `--ds-icon-tertiary` | #A4A19D | #CECCCA |  |

### Accent & Link

`fg_accent_*` cho chữ và icon mang màu nhận diện, `fg_link` cho link. Bản `_inverse` dùng trên `bg_inverse`.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `fg_accent_primary` | `--ds-fg-accent-primary` | #EC5509 | #FCC8B5 |  |
| `fg_accent_secondary` | `--ds-fg-accent-secondary` | #0B72CB | #64B2F7 |  |
| `fg_link` | `--ds-fg-link` | #0B72CB | #64B2F7 |  |
| `fg_accent_primary_inverse` | `--ds-fg-accent-primary-inverse` | #FBA789 | #EC5509 | đặt trên `bg_inverse` |
| `fg_accent_secondary_inverse` | `--ds-fg-accent-secondary-inverse` | #64B2F7 | #0B72CB | đặt trên `bg_inverse` |

### Status

Đặt trên nền trạng thái cùng tên hoặc trên nền trang.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `fg_success` | `--ds-fg-success` | #029739 | #86EAA4 | đặt trên `bg_success` |
| `fg_warning` | `--ds-fg-warning` | #745A06 | #FBC637 | đặt trên `bg_warning` |
| `fg_error` | `--ds-fg-error` | #D3222E | #F49AA0 | đặt trên `bg_error` |
| `fg_info` | `--ds-fg-info` | #0B72CB | #64B2F7 | đặt trên `bg_info` |

### On color

- `fg_on_accent_primary` trên `bg_accent_primary` và `bg_button_primary`.
- `fg_on_accent_secondary` trên `bg_accent_secondary`.
- `fg_on_accent_general` luôn là trắng. `fg_on_accent` là alias của nó.
- `fg_on_contrast` trên nền `bg_*_contrast` của bảng màu mở rộng. NotiBadge dùng cặp này.
- `fg_inverse_primary`, `fg_inverse_secondary` trên `bg_inverse`.
- `light_fixed` (trắng) và `dim_fixed` (xám rất đậm) giữ nguyên ở mọi theme, cho chỗ cần một màu không đổi.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `fg_on_accent_primary` | `--ds-fg-on-accent-primary` | #FFFFFF | #FFFFFF | đặt trên `bg_accent_primary` |
| `fg_on_accent_secondary` | `--ds-fg-on-accent-secondary` | #FFFFFF | #FFFFFF | đặt trên `bg_accent_secondary` |
| `fg_on_accent_general` | `--ds-fg-on-accent-general` | #FFFFFF | #FFFFFF | đặt trên `bg_accent_secondary` |
| `fg_on_accent` | `--ds-fg-on-accent` | #FFFFFF | #FFFFFF | tên cũ, trỏ tới `fg_on_accent_general`; đặt trên `bg_accent_primary` |
| `fg_on_contrast` | `--ds-fg-on-contrast` | #FFFFFF | #383633 | đặt trên `bg_red_contrast` |
| `fg_inverse_primary` | `--ds-fg-inverse-primary` | #FFFFFF | #32312F | đặt trên `bg_inverse` |
| `fg_inverse_secondary` | `--ds-fg-inverse-secondary` | #D8D6D5 | #55524E | đặt trên `bg_inverse` |
| `light_fixed` | `--ds-light-fixed` | #FFFFFF | #FFFFFF | đặt trên `dim_fixed` |
| `dim_fixed` | `--ds-dim-fixed` | #252422 | #252422 | đặt trên `light_fixed` |

### Sidebar

Chữ và icon trong sidebar, trên nền `bg_sidebar_*`.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `fg_sidebar_primary` | `--ds-fg-sidebar-primary` | #32312F | #F5F5F4 | đặt trên `bg_sidebar_primary` |
| `fg_sidebar_secondary` | `--ds-fg-sidebar-secondary` | #55524E | #D8D6D5 | đặt trên `bg_sidebar_primary` |
| `fg_sidebar_tertiary` | `--ds-fg-sidebar-tertiary` | #8A857F | #A4A19D | đặt trên `bg_sidebar_primary` |

## Border

Class viền chỉ đặt `border-color`. Độ dày lấy từ class Tailwind: `border border_secondary`.

### Base

`border_secondary` là viền mặc định của Card, Popover và menu. `border_contrast_*` đậm hơn, cho điều khiển nhỏ cần nổi rõ như Radio. `border_contrast` là alias của `border_contrast_primary`.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `border_primary` | `--ds-border-primary` | #F0F0EF | #383633 |  |
| `border_secondary` | `--ds-border-secondary` | #EBEBEA | #32312F |  |
| `border_tertiary` | `--ds-border-tertiary` | #DFDEDD | #4A4844 |  |
| `border_contrast_primary` | `--ds-border-contrast-primary` | #6F6B67 | #CECCCA |  |
| `border_contrast_secondary` | `--ds-border-contrast-secondary` | #A4A19D | #A4A19D |  |
| `border_contrast` | `--ds-border-contrast` | #6F6B67 | #CECCCA | tên cũ, trỏ tới `border_contrast_primary` |

### Accent

Bản `_contrast` đậm hơn bản thường. `border_accent` là alias của `border_accent_primary`.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `border_accent_primary` | `--ds-border-accent-primary` | #FCC8B5 | #BB4307 |  |
| `border_accent_primary_contrast` | `--ds-border-accent-primary-contrast` | #F87E52 | #BB4307 |  |
| `border_accent_secondary` | `--ds-border-accent-secondary` | #CFE7FC | #063E6F |  |
| `border_accent_secondary_contrast` | `--ds-border-accent-secondary-contrast` | #64B2F7 | #64B2F7 |  |
| `border_accent` | `--ds-border-accent` | #FCC8B5 | #BB4307 | tên cũ, trỏ tới `border_accent_primary` |

### Component

Viền của ô nhập và nút. `border_input_opacity` trong suốt ở mọi theme trừ `high-contrast-light`, nên Input kiểu `fill` và `dim` chỉ hiện viền ở theme tương phản cao.

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `border_input` | `--ds-border-input` | #EBEBEA | #4A4844 |  |
| `border_input_opacity` | `--ds-border-input-opacity` | #3D3B3800 | #3D3B3800 |  |
| `border_button` | `--ds-border-button` | #DFDEDD | #3D3B38 |  |
| `border_dim_button` | `--ds-border-dim-button` | #EBEBEA | #3D3B38 |  |
| `border_secondary_button` | `--ds-border-secondary-button` | #FEECE6 | #BB4307 |  |
| `border_error_button` | `--ds-border-error-button` | #FBDADD | #8C171F |  |

### Status

| Class | CSS variable | Light | Dark | Note |
| --- | --- | --- | --- | --- |
| `border_success` | `--ds-border-success` | #B1F1C9 | #029739 |  |
| `border_error` | `--ds-border-error` | #FCCFD2 | #D3222E |  |

## Extended palette

19 màu: `orange`, `amber`, `yellow`, `lime`, `green`, `emerald`, `teal`, `cyan`, `sky`, `blue`, `indigo`, `violet`, `purple`, `fuchsia`, `pink`, `red`, `slate`, `gray`, `zinc`. Mỗi màu có sáu nhóm token:

| Nhóm       | Class               | CSS variable             | Dùng cho                                  |
| ---------- | ------------------- | ------------------------ | ----------------------------------------- |
| Nền nhạt   | `bg_<màu>_subtle`   | `--ds-bg-<màu>-subtle`   | Tag, badge, banner                        |
| Nền vừa    | `bg_<màu>_medium`   | `--ds-bg-<màu>-medium`   | Thanh tiến độ, biểu đồ, hàng được làm nổi |
| Nền đậm    | `bg_<màu>_contrast` | `--ds-bg-<màu>-contrast` | Badge đậm, biểu đồ, trạng thái đang chọn  |
| Viền       | `border_<màu>`      | `--ds-border-<màu>`      | Viền đi cùng nền nhạt                     |
| Chữ đậm    | `fg_<màu>_strong`   | `--ds-fg-<màu>-strong`   | Chữ và icon trên nền nhạt                 |
| Chữ accent | `fg_<màu>_accent`   | `--ds-fg-<màu>-accent`   | Icon, link, chữ trang trí                 |

`slate`, `gray` và `zinc` không có nền đậm. `fg_<màu>_accent` giữ nguyên giá trị ở cả sáu theme; các nhóm còn lại đổi giữa theme sáng và tối.

Badge có prop `color` dựng đúng bộ ba nền nhạt, viền và chữ đậm: `<Badge color="orange">` ra `bg_orange_subtle border_orange fg_orange_strong`. Cột Preview vẽ bộ ba đó, cạnh một số đếm trên nền đậm với chữ `fg_on_contrast` như NotiBadge.

19 hue: `orange`, `amber`, `yellow`, `lime`, `green`, `emerald`, `teal`, `cyan`, `sky`, `blue`, `indigo`, `violet`, `purple`, `fuchsia`, `pink`, `red`, `slate`, `gray`, `zinc`.

Mỗi hue có các class `bg_{hue}_subtle`, `bg_{hue}_medium`, `bg_{hue}_contrast`, `border_{hue}`, `fg_{hue}_strong`, `fg_{hue}_accent`. `slate`, `gray`, `zinc` không có `bg_{hue}_contrast`.

## Shadows

Hai thang: Regular (`shadow_xs` tới `shadow_xxl`) và Subtle (`shadow_subtle_xxs` tới `shadow_subtle_xxl`). Mỗi class đặt `box-shadow` bằng biến `--ds-shadow-*` cùng tên.

Bóng là màu đen cố định, giống nhau ở mọi theme. Trên nền tối bóng gần như không thấy, nên ở theme tối viền mới là thứ tách các lớp.

### Regular

| Class | CSS variable |
| --- | --- |
| `shadow_xs` | `--ds-shadow-xs` |
| `shadow_s` | `--ds-shadow-s` |
| `shadow_m` | `--ds-shadow-m` |
| `shadow_l` | `--ds-shadow-l` |
| `shadow_xl` | `--ds-shadow-xl` |
| `shadow_xxl` | `--ds-shadow-xxl` |

### Subtle

Subtle gồm hai lớp bóng mềm, một lớp sát và một lớp lan rộng, và không tự vẽ cạnh. Phần tử dùng Subtle phải có viền thật `border border_secondary`. Bóng không đổi theo theme như token viền, nên giả cạnh bằng một lớp bóng mảnh sẽ hỏng khi đổi theme.

```tsx
<div className="border border_secondary bg_primary radius_12 shadow_subtle_l" />
```

| Class | CSS variable |
| --- | --- |
| `shadow_subtle_xxs` | `--ds-shadow-subtle-xxs` |
| `shadow_subtle_xs` | `--ds-shadow-subtle-xs` |
| `shadow_subtle_s` | `--ds-shadow-subtle-s` |
| `shadow_subtle_m` | `--ds-shadow-subtle-m` |
| `shadow_subtle_l` | `--ds-shadow-subtle-l` |
| `shadow_subtle_xl` | `--ds-shadow-subtle-xl` |
| `shadow_subtle_xxl` | `--ds-shadow-subtle-xxl` |

Component trong thư viện đều dùng thang Subtle. Khi tự dựng một bề mặt nổi, lấy cùng mức với component gần nó nhất.

| Component                                   | Bóng                                                                                       |
| ------------------------------------------- | ------------------------------------------------------------------------------------------ |
| Card                                        | `shadow_subtle_xxs` tới `shadow_subtle_xl` theo prop `shadow`, mặc định `shadow_subtle_xs` |
| Popover, DropdownMenu, Select               | `shadow_subtle_l`                                                                          |
| Modal, Drawer                               | `shadow_subtle_xl`                                                                         |
| Tooltip, Toast, DatePicker                  | `shadow_subtle_m`                                                                          |
| SegmentedControl (mục đang chọn)            | `shadow_subtle_s`                                                                          |
| Calendar, DateRangePicker, Slider (nút kéo) | `shadow_subtle_xs`                                                                         |

Hai alias: `shadow_xxs` trỏ tới `--ds-shadow-subtle-xxs`, nên thuộc thang Subtle dù tên không có chữ subtle. `shadow_md` trỏ tới `--ds-shadow-m`.

### Other effects

| Class                  | CSS variable                | Tác dụng                                                                  |
| ---------------------- | --------------------------- | ------------------------------------------------------------------------- |
| `backdrop_blur`        | `--ds-backdrop-blur`        | `backdrop-filter: blur(4px)`                                              |
| `outline_blue_focus`   | `--ds-outline-blue-focus`   | `box-shadow` thành vòng 3px xanh dương. Button và Checkbox dùng khi focus |
| `outline_orange_focus` | `--ds-outline-orange-focus` | `box-shadow` thành vòng 3px cam nhạt                                      |

## Theme

Core DS có sáu theme dùng chung và một theme riêng cho phòng Creative. Theme `light` là giá trị mặc định ở `:root`. Các theme còn lại khai báo bằng một class và bằng `data-theme` mang đúng tên theme, dùng cách nào cũng được.

| Theme (`data-theme`)  | Class                       | Type | Khác với light                                                                                        |
| --------------------- | --------------------------- | ---- | ----------------------------------------------------------------------------------------------------- |
| `light`               | (không có)                  | Sáng | Theme mặc định                                                                                        |
| `high-contrast-light` | `theme-high-contrast-light` | Sáng | Chữ, icon và viền đậm hơn                                                                             |
| `olive`               | `theme-olive`               | Sáng | Nền ngả xanh lá, accent xanh lá                                                                       |
| `dark`                | `dark`                      | Tối  | Nền xám đậm                                                                                           |
| `deep-forest`         | `theme-deep-forest`         | Tối  | Nền xanh lục đậm                                                                                      |
| `sunset`              | `theme-sunset`              | Sáng | Sidebar ngả nâu nhạt, accent cam đất                                                                  |
| `creative-studio`     | `theme-creative-studio`     | Sáng | Riêng phòng Creative: nền ngả xanh dương, [hệ số X](./x-factor.md) 1.125. Phải bật riêng |

Mỗi theme đặt luôn `color-scheme`, nên thanh cuộn và control gốc của trình duyệt theo đúng kiểu sáng hoặc tối.

### Preview

Mỗi thẻ dưới đây đặt `data-theme` trên phần tử bọc của riêng nó, bên trong là cùng một bộ class token và component. Trang không đổi theme.

| Theme | Enable with | Scheme |
| --- | --- | --- |
| Light | mặc định (`:root`) | light |
| High Contrast Light | `class="theme-high-contrast-light"` hoặc `data-theme="high-contrast-light"` | light |
| Olive | `class="theme-olive"` hoặc `data-theme="olive"` | light |
| Dark | `class="dark"` hoặc `data-theme="dark"` | dark |
| Deep Forest | `class="theme-deep-forest"` hoặc `data-theme="deep-forest"` | dark |
| Sunset | `class="theme-sunset"` hoặc `data-theme="sunset"` | light |
| iCreative Studio | `class="theme-creative-studio"` hoặc `data-theme="creative-studio"` | light |

### Đổi theme bằng `useTheme`

```tsx title="theme-switcher.tsx"
"use client"

import { Button, useTheme } from "@coreds/react"

export function ThemeSwitcher() {
  const { theme, setTheme, themes } = useTheme()

  return (
    <div className="flex flex-wrap gap-2">
      {themes.map((option) => (
        <Button
          key={option}
          size="s"
          variant={theme === option ? "primary" : "dim"}
          onClick={() => setTheme(option)}
        >
          {option}
        </Button>
      ))}
    </div>
  )
}
```

Hook làm những việc sau:

- Đặt `data-theme` lên `<html>`, thêm class `dark` cho theme dark và `theme-<tên>` cho bốn theme còn lại. Theme light không thêm class nào.
- Lưu lựa chọn vào `localStorage` với key `ui-kit-theme`.
- Lần đầu, khi `localStorage` chưa có gì, dùng `defaultValue`. Không truyền `defaultValue` thì theo cài đặt sáng hoặc tối của hệ điều hành.

```tsx
const { theme, setTheme } = useTheme({
  defaultValue: "light",
  storageKey: "my-app-theme",
})
```

Hook gắn class sau khi component mount. Vì vậy app render ở server sẽ hiện theme sáng một khoảnh khắc trước khi hook chạy. Muốn tránh thì đặt sẵn class trên `<html>` từ server.

`themes` (danh sách sáu theme dùng chung) và type `ThemeName` cũng được export riêng, dùng khi dựng menu chọn theme.

### iCreative Studio

Theme `creative-studio` dành cho sản phẩm của phòng Creative, không nằm trong `themes`. `useTheme` chỉ nhận theme có trong `availableThemes`, nên app phải bật riêng:

```tsx
import { creativeStudioTheme, useTheme } from "@coreds/react"

// Chỉ app của phòng Creative làm vậy.
const { theme } = useTheme({
  availableThemes: [creativeStudioTheme],
  defaultValue: creativeStudioTheme,
  storageKey: "creative-studio-theme",
})
```

App cho chọn cả bảy theme thì khai báo mảng một lần ở ngoài component, vì mảng viết thẳng trong lời gọi làm hook gắn lại listener mỗi lần render:

```tsx
import { creativeStudioTheme, themes } from "@coreds/react"

const ALL_THEMES = [...themes, creativeStudioTheme]

function ThemeMenu() {
  const { theme, setTheme } = useTheme({ availableThemes: ALL_THEMES })
  // …
}
```

Không dùng hook thì đặt thẳng `data-theme="creative-studio"` hoặc class `theme-creative-studio` lên phần tử gốc.

Theme này đặt sẵn `--ds-x: 1.125`, nên component trong đó thoáng và tròn hơn một chút. Giá trị lạ hoặc không nằm trong `availableThemes` bị bỏ qua, `useTheme` quay về `defaultValue`.

### Chỉ cần sáng và tối

App chỉ có hai chế độ thì dùng `useDarkMode`. Hook này bật, tắt class `dark` trên `<html>` và lưu vào `localStorage` với key `ui-kit-dark-mode`.

```tsx
import { useDarkMode } from "@coreds/react"

const { isDark, setIsDark, toggle } = useDarkMode()
```

Chỉ dùng một trong hai hook. Cả hai cùng ghi lên `<html>` nhưng lưu ở hai key khác nhau, dùng chung sẽ giành nhau.

### Không dùng hook

Theme chỉ dựa vào class hoặc `data-theme`, nên đặt thẳng lên `<html>` là đủ:

```html
<html class="dark">
  <!-- hoặc -->
  <html data-theme="deep-forest"></html>
</html>
```

App đã có bộ đổi theme khác, như next-themes, thì không cần hook của Core DS: chỉ cần bộ đó đặt class `dark` hoặc `data-theme` lên `<html>`. Trang tài liệu này làm như vậy: Fumadocs gắn class `dark` và token Core DS đổi theo.

### Đặt theme cho một vùng

Selector của các theme không gắn với `<html>`, nên đặt `data-theme` trên một phần tử bất kỳ sẽ đổi theme cho mọi thứ bên trong nó.

```tsx
<section data-theme="dark" className="bg_primary text_primary p-6 radius_12">
  <Button>Lưu</Button>
</section>
```

> **Giới hạn**
>
> - Phần tử bọc cần class nền và chữ của riêng nó, như `bg_primary text_primary`. Không có thì nó
>   vẫn hiện nền của trang phía sau.
> - Theme light chỉ khai báo ở `:root`, nên không bọc được một vùng sáng bên trong trang đang tối.
> - Modal, Drawer, Popover, DropdownMenu, Select, Tooltip và DatePicker render ra `<body>` qua portal,
>   nằm ngoài vùng bọc nên theo theme của trang.
