# Agent Skills

> Skill coreds cho AI agent biết component, token và quy tắc của Core DS, khớp với version đang cài trong app.

Skill `coreds` đi kèm gói `@coreds/react`. Nó gồm quy tắc dùng Core DS và toàn bộ docs dạng Markdown, nên agent tra cứu ngay trên máy và luôn khớp với version app đang cài.

## Installation

Chạy ở thư mục gốc của app đã cài `@coreds/react`:

```bash tab="npm"
npx @coreds/react skill
```

```bash tab="pnpm"
pnpm exec coreds-react skill
```

```bash tab="yarn"
yarn coreds-react skill
```

Skill được chép vào `.claude/skills/coreds`. Mỗi lần nâng version `@coreds/react`, chạy lại lệnh để docs trong skill khớp version mới. Commit thư mục này nếu muốn cả team dùng chung.

### Install scope

| Option         | Cài vào                                                                                                                             |
| -------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| (mặc định)     | `.claude/skills/coreds` của project, cho Claude Code                                                                                |
| `--global`     | `~/.claude/skills/coreds`, dùng cho mọi project trên máy                                                                            |
| `--dir <path>` | `<path>/coreds`, cho agent đọc skill ở chỗ khác: `.cursor/skills` (Cursor), `.agents/skills` (Codex), `.opencode/skills` (OpenCode) |

```bash
npx @coreds/react skill --dir .agents/skills
```

## Usage

Agent tự dùng skill khi bạn nhờ viết UI bằng Core DS. Trong Claude Code có thể gọi thẳng bằng `/coreds`. Ví dụ:

- Làm form đăng nhập bằng Core DS.
- Thêm bảng danh sách người dùng có phân trang và ô tìm kiếm.
- Sửa màu của màn này cho đúng token, chạy được ở theme dark.

## What's included

- `SKILL.md`: cách cài và import, quy tắc style (token màu, chữ, bo góc, hover, kích cỡ control, icon, theme), cách dùng editor, việc cần kiểm tra trước khi xong.
- `references/`: bản Markdown của mọi trang docs. Trang component có code ví dụ và bảng props, trang Foundations có bảng token.

```txt
.claude/skills/coreds/
├── SKILL.md
└── references/
    ├── index.md              # mục lục
    ├── docs/
    │   ├── installation.md
    │   └── foundations/      # colors, design-tokens, typography, spacing-radius, x-factor…
    ├── components/           # button.md, select.md, date-picker.md…
    ├── icons/                # index (cách dùng), phosphor, iconsax (danh sách tên icon)
    └── editor/               # installation, simple, notion-like, chat-box, rich-text-box
```

## Without installing

Agent không hỗ trợ skill vẫn đọc được bản đi kèm gói ở `node_modules/@coreds/react/skills/coreds/`. Trỏ agent tới đó bằng [AGENTS.md](./agents-md.md).
