# All components

> 40 component dựng trên Radix và Tailwind, dùng chung token màu, chữ và khoảng cách. Mỗi trang có ví dụ chạy được và bảng props.

Import mọi component từ `@coreds/react` (hoặc `@coreds/ui` nếu không cần icon). Chọn một component để xem ví dụ và props.

## General

- [Avatar](./components/avatar.md): Ảnh đại diện của người dùng hoặc nhóm, nhiều kích thước và hình dạng.
- [Badge](./components/badge.md): Nhãn nhỏ cho trạng thái, phân loại hoặc số đếm. NotiBadge là chấm hoặc số thông báo gắn lên phần tử khác.
- [Button](./components/button.md): Nút bấm cho hành động chính, phụ và nguy hiểm, có trạng thái đang tải. Kèm DropdownButton và SplitDropdownButton cho nút mở menu.
- [Chip](./components/chip.md): Thẻ nhỏ để lọc, chuyển tab, hiển thị thông tin hoặc nhập nhiều giá trị.
- [IconToggle](./components/icon-toggle.md): Nút icon có trạng thái bật/tắt, dùng cho thanh công cụ và hành động nhanh.
- [Spinner](./components/spinner.md): Vòng quay báo đang xử lý.

## Forms

- [Checkbox](./components/checkbox.md): Ô đánh dấu cho lựa chọn bật/tắt hoặc chọn nhiều mục.
- [Field](./components/field.md): Bọc một ô nhập với nhãn, mô tả và thông báo lỗi.
- [FileUpload](./components/file-upload.md): Vùng kéo-thả hoặc bấm để chọn file, kèm danh sách file đã chọn.
- [Input](./components/input.md): Ô nhập văn bản một dòng. NumberInput dành cho số, có định dạng hàng nghìn.
- [InputPinCode](./components/input-pin-code.md): Ô nhập mã PIN hoặc OTP theo từng ký tự.
- [RadioGroup](./components/radio-group.md): Nhóm lựa chọn chỉ chọn được một.
- [SegmentedControl](./components/segmented-control.md): Nhóm nút liền nhau để chuyển giữa vài lựa chọn ngang hàng.
- [Select](./components/select.md): Ô chọn một hoặc nhiều giá trị từ danh sách.
- [Slider](./components/slider.md): Thanh trượt chọn một giá trị hoặc một khoảng.
- [Switch](./components/switch.md): Công tắc bật/tắt, có hiệu lực ngay khi gạt.
- [Textarea](./components/textarea.md): Ô nhập văn bản nhiều dòng.

## Date & Time

- [Calendar](./components/calendar.md): Lịch chọn ngày hoặc khoảng ngày, có thể đánh dấu những ngày đặc biệt.
- [DatePicker](./components/date-picker.md): Ô chọn ngày, mở lịch trong popover.
- [DateRangePicker](./components/date-range-picker.md): Ô chọn khoảng ngày từ – đến.

## Overlays

- [Drawer](./components/drawer.md): Bảng trượt ra từ cạnh màn hình cho nội dung phụ hoặc biểu mẫu.
- [DropdownMenu](./components/dropdown-menu.md): Menu thả xuống cho các hành động, có menu con, mục checkbox, radio và phím tắt.
- [Modal](./components/modal.md): Hộp thoại giữa màn hình, chặn tương tác với phần còn lại cho đến khi đóng.
- [Popover](./components/popover.md): Khung nổi gắn với một phần tử, chứa nội dung tương tác nhỏ.
- [Tooltip](./components/tooltip.md): Chú thích ngắn hiện khi rê chuột hoặc focus vào phần tử. Cần `TooltipProvider` ở gốc app.

## Layout

- [Accordion](./components/accordion.md): Các mục thu gọn và mở rộng, để chứa nội dung dài trong không gian hẹp.
- [Card](./components/card.md): Khung gom một nhóm nội dung liên quan: tiêu đề, mô tả, nội dung và chân.
- [ScrollArea](./components/scroll-area.md): Vùng cuộn với thanh cuộn theo style của design system.
- [Tabs](./components/tabs.md): Chia nội dung thành các tab ngang hàng.

## Navigation

- [Breadcrumb](./components/breadcrumb.md): Đường dẫn cho biết trang hiện tại nằm ở đâu trong cấu trúc.
- [Pagination](./components/pagination.md): Chuyển trang cho danh sách hoặc bảng dài.
- [Sidebar](./components/sidebar.md): Thanh điều hướng bên của app: nhóm mục, mục con, thu gọn và bố cục trang đi kèm.
- [SimpleSidebar](./components/simple-sidebar.md): Sidebar gọn, dựng từ một mảng dữ liệu thay vì ghép từng phần.
- [Steps](./components/steps.md): Các bước của một quy trình và bước đang làm.

## Feedback

- [Alert](./components/alert.md): Thông báo nổi bật trong trang: thông tin, thành công, cảnh báo hoặc lỗi.
- [Progress](./components/progress.md): Thanh tiến trình khi biết hoặc chưa biết thời gian còn lại.
- [Skeleton](./components/skeleton.md): Khối giữ chỗ trong lúc nội dung đang tải.
- [Toast](./components/toast.md): Thông báo ngắn hiện ở góc màn hình, gọi bằng hàm `toast()`. Cần `Toaster` ở gốc app.

## Data Display

- [DataTable](./components/table.md): Bảng dữ liệu có sắp xếp, lọc, chọn hàng, mở rộng hàng và phân trang.
- [VirtualList](./components/virtual-list.md): Danh sách rất dài nhưng chỉ render phần đang nhìn thấy.

## Patterns

- [App header](./components/app-header.md): Hàng tiêu đề trên nội dung của app, ghép từ Breadcrumb, Select, Input, Button và Tabs. Là cách ghép component để tham khảo, không phải component xuất từ thư viện.
