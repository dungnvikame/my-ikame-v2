# Introduction

> Core DS là thư viện React dùng chung của team, gồm component, icon và editor.

Core DS gom ba thư viện cũ (ui-kit, icon-kit, tiptap-kit) vào một repo, dùng chung một bộ design token. Mọi gói nằm dưới scope `@coreds` và cài được mà không cần token.

## Packages

| Package          | Description                                         |
| ---------------- | --------------------------------------------------- |
| `@coreds/react`  | Gói tổng: toàn bộ UI, icon ở `@coreds/react/icons`  |
| `@coreds/ui`     | Component, CSS, hook, design token                  |
| `@coreds/icons`  | Icon Phosphor, bộ Iconsax ở `@coreds/icons/iconsax` |
| `@coreds/tiptap` | Editor Tiptap v3, 4 template và CLI                 |

`@coreds/react`, `@coreds/ui` và `@coreds/icons` dùng chung một số version. `@coreds/tiptap` có version riêng.

## Next steps

- [Installation](./docs/installation.md): Thêm registry, cài gói, import CSS và provider.
- [Components](./components.md): Từng component kèm ví dụ chạy được và bảng props.
- [Foundations](./docs/foundations/colors.md): Token màu, chữ, khoảng cách, hệ số X và trạng thái.
- [Icons](./icons.md): Hai bộ Phosphor và Iconsax, tìm theo tên và chép dòng import.
