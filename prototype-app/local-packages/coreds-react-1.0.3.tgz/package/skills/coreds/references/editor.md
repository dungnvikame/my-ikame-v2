# Introduction

> @coreds/tiptap là bộ editor Tiptap v3 dựng trên @coreds/ui, có 4 template dùng ngay.

`@coreds/tiptap` gom các khối, menu và thanh công cụ của editor vào một gói. Giao diện dùng component và token của `@coreds/ui`, nên editor đổi theo theme như phần còn lại của app.

Bắt đầu từ trang [Installation](./editor/installation.md), rồi chọn một template.

## Templates

- [Simple](./editor/simple.md): Thanh công cụ cố định phía trên, cho nội dung cơ bản.
- [Notion-like](./editor/notion-like.md): Editor dạng khối: menu lệnh /, kéo-thả khối, bảng, nhắc tên.
- [Chat box](./editor/chat-box.md): Ô soạn tin nhắn gọn, Enter để gửi.
- [Rich text box](./editor/rich-text-box.md): Ô soạn thảo nhỏ gọn có thanh công cụ gắn liền, dùng trong form.

## Customization

- `extensionOverrides`: extension trùng tên với extension có sẵn sẽ thay nó, tên mới thì được thêm vào.
- `features` (Notion-like): bật tắt từng tính năng, xem trang [Notion-like](./editor/notion-like.md).
- `npx @coreds/tiptap eject <component>`: chép riêng một primitive ra app khi cần sửa sâu hơn.

> **Menu AI**
>
> Menu AI cần extension AI của Tiptap Pro (`aiTextPrompt`, `aiAccept`, `aiReject`), gói này không
> kèm sẵn. Khi thiếu, các hành động AI bị tắt. Menu AI vẫn dựng trên Ariakit; chỉ cài
> `@ariakit/react` nếu bạn bật nó.
