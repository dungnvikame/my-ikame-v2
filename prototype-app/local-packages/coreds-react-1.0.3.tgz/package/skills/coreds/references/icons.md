# Introduction

> Hai bộ icon Phosphor và Iconsax dạng component React, mỗi cỡ mang sẵn độ dày nét theo thiết kế.

Icon nằm trong gói `@coreds/icons`. Gói tổng `@coreds/react` export lại toàn bộ dưới `@coreds/react/icons`, nên app đã cài `@coreds/react` không cần cài thêm.

Có hai bộ: Phosphor (1.512 icon) và Iconsax (993 icon). Mỗi icon là một component riêng, bundle chỉ chứa những icon được import.

| Bộ       | Đã cài `@coreds/react`        | Chỉ cài `@coreds/icons` |
| -------- | ----------------------------- | ----------------------- |
| Phosphor | `@coreds/react/icons`         | `@coreds/icons`         |
| Iconsax  | `@coreds/react/icons/iconsax` | `@coreds/icons/iconsax` |

## Usage

Truyền `size`, độ dày nét đi kèm theo cỡ. Không cần đặt nét riêng.

```tsx
import { MagnifyingGlassIcon } from "@coreds/react/icons"

export function SearchHint() {
  // size quyết định cả khung lẫn độ dày nét
  return <MagnifyingGlassIcon aria-hidden="true" size="s" className="icon_secondary" />
}
```

Không truyền `size` thì icon rộng `1em`, tức theo cỡ chữ xung quanh. Đặt khung bằng class Tailwind như `h-4 w-4` cũng được. Khi đó, nếu không có `size`, nét dùng mức mặc định 1,25px (bằng cỡ `s`).

| Prop          | Type                                            | Default               | Notes                                                                          |
| ------------- | ----------------------------------------------- | --------------------- | ------------------------------------------------------------------------------ |
| `size`        | `"xs" \| "s" \| "m" \| "l" \| number \| string` | `"1em"`               | Tên cỡ mang theo cả khung và nét. Số hoặc chuỗi đi thẳng vào `width`/`height`. |
| `strokeWidth` | `number`                                        | theo `size`           | Độ dày nét, tính bằng px. Không có tác dụng với kiểu tô đặc.                   |
| `variant`     | `IconVariant` / `IconsaxVariant`                | `"line"` / `"linear"` | Phosphor: `line`, `duotone`, `fill`. Iconsax: `linear`, `bold`, `bulk`.        |
| …             | `SVGProps<SVGSVGElement>`                       |                       | `className`, `aria-hidden`, `onClick`, `ref`…                                  |

## Sizes

Bốn cỡ, mỗi cỡ có sẵn độ dày nét theo Core DS 1.1. Nét đi theo cỡ chứ không phải một thông số chỉnh riêng: cỡ nhỏ có nét dày hơn so với khung để icon giữ cùng độ đậm khi nhìn.

| size | Box | Stroke |
| --- | --- | --- |
| `"xs"` | 12px | 0.9px |
| `"s"` | 16px | 1.25px |
| `"m"` | 20px | 1.25px |
| `"l"` | 24px | 1.5px |

| Cỡ   | Khung | Nét    | Dùng cho                                           |
| ---- | ----- | ------ | -------------------------------------------------- |
| `xs` | 12px  | 0,9px  | Chỗ chật: chip, badge, ô bảng dày đặc              |
| `s`  | 16px  | 1,25px | Dùng nhiều nhất: nút, ô nhập, mục menu, breadcrumb |
| `m`  | 20px  | 1,25px | Icon đầu mục, tiêu đề section, vùng thả file       |
| `l`  | 24px  | 1,5px  | Icon đứng riêng, trạng thái trống                  |

Bảng cỡ có trong code dưới tên `SIZES`, export từ cả hai bộ:

```tsx
import { SIZES } from "@coreds/react/icons"

SIZES.s // { box: 16, stroke: 1.25 }
```

## Stroke width

`strokeWidth` nhận giá trị bằng px CSS, đúng đơn vị file thiết kế ghi, không cần quy đổi. Mọi nét được vẽ với `vector-effect: non-scaling-stroke`, nên độ dày giữ nguyên dù khung to hay nhỏ, kể cả khi khung lấy từ class `h-*`/`w-*`.

Prop này dành cho trường hợp hiếm mà không cỡ nào đáp ứng được, ví dụ dấu tích trong Checkbox lấp đầy một ô nhỏ hơn mọi cỡ của DS. Hãy chọn cỡ trước.

```tsx
// Dấu tích của Checkbox: khung lấy từ ô chứa, nét đặt riêng 2px
<CheckIcon aria-hidden="true" strokeWidth={2} className="h-full w-full" />

// Khung lấy từ class Tailwind, nét giữ mức mặc định 1.25px
<CaretDownIcon aria-hidden="true" className="h-4 w-4 icon_tertiary" />
```

> **Note**
>
> `strokeWidth` không có tác dụng với kiểu tô đặc: `fill` của Phosphor, `bold` và `bulk` của
> Iconsax. Bảy icon Phosphor vẽ bằng chấm đặc cũng vậy: `DotIcon`, `DotsNineIcon`, `DotsSixIcon`,
> `DotsSixVerticalIcon`, `DotsThreeIcon`, `DotsThreeVerticalIcon`, `NumpadIcon`.

## Colors

Icon lấy màu từ `currentColor`. Gắn class màu icon của DS lên icon. Không dùng class màu có sẵn của Tailwind (như `text-gray-500`) vì màu đó không đổi theo giao diện sáng, tối.

| Class | Usage |
| --- | --- |
| `icon_primary` | Icon mang nghĩa chính, đứng cạnh chữ chính. |
| `icon_secondary` | Icon giao diện thông thường. Dùng nhiều nhất. |
| `icon_tertiary` | Icon phụ, nhạt hơn: icon trong ô nhập, dấu phân cách. |

Icon trạng thái dùng `fg_success`, `fg_warning`, `fg_error`, `fg_info`.

Icon báo trạng thái dùng class màu trạng thái `fg_success`, `fg_warning`, `fg_error`, `fg_info`. Icon đầu dòng của Alert tô màu theo cách này.

Không gắn class nào thì icon theo màu chữ của phần tử cha. Icon trong Button dựa vào điều này để lấy màu chữ của nút.

## Accessibility

Icon đứng cạnh nhãn chữ chỉ để trang trí: ẩn khỏi trình đọc màn hình bằng `aria-hidden="true"`. Icon không tự ẩn, nên phải truyền prop này.

Nút chỉ có icon cần tên riêng: đặt `aria-label` lên nút, không đặt lên icon.

```tsx
import { Button } from "@coreds/react"
import { TrashIcon } from "@coreds/react/icons"

// Trang trí: nhãn bên cạnh đã nói nút làm gì
<Button variant="border">
  <TrashIcon aria-hidden="true" size="s" />
  Xoá
</Button>

// Nút chỉ có icon: tên đặt trên nút
<Button variant="border" size="icon-m" aria-label="Xoá dòng">
  <TrashIcon aria-hidden="true" size="s" />
</Button>
```

Icon đứng một mình mà mang nghĩa, không có chữ đi kèm, thì thêm `role="img"` và `aria-label` lên chính icon.

## Icon sets

Hai bộ trùng nhiều tên (`WalletIcon`, `HeartIcon`, `StarIcon`…) nên nằm ở hai đường import riêng. Dùng cả hai trong một file thì đặt tên khác cho một bên:

```tsx
import { WalletIcon } from "@coreds/react/icons"
import { WalletIcon as VsWalletIcon } from "@coreds/react/icons/iconsax"
```

Hai bộ dùng chung `size`, `strokeWidth` và bảng cỡ, chỉ khác giá trị của `variant`.

| Set | Import | variant |
| --- | --- | --- |
| Phosphor | `@coreds/react/icons` | `line`, `duotone`, `fill` |
| Iconsax | `@coreds/react/icons/iconsax` | `linear`, `bold`, `bulk` |

Mỗi bộ có trang riêng, kèm bảng tra icon theo tên:

- [Phosphor](./icons/phosphor.md): 1.512 icon, kiểu `line`, `duotone`, `fill`. Import từ `@coreds/react/icons`.
- [Iconsax](./icons/iconsax.md): 993 icon, kiểu `linear`, `bold`, `bulk`. Import từ `@coreds/react/icons/iconsax`.
