# Core DS

> Thư viện giao diện React dùng chung của team: component dựng trên Radix và Tailwind, icon Phosphor và Iconsax, editor Tiptap, sáu theme. Docs viết tiếng Việt, thuật ngữ giữ tiếng Anh.

- Cài: thêm `@coreds:registry=https://gitlab.ikameglobal.com/api/v4/projects/2163/packages/npm/` vào `.npmrc`, chạy `npm install @coreds/react`, import `@coreds/react/style.css` một lần.
- Import component từ `@coreds/react` (`import { Button } from "@coreds/react"`), icon từ `@coreds/react/icons`.
- Màu, chữ, bo góc dùng class token của Core DS (`bg_primary`, `text_secondary`, `border_secondary`, `body_s`, `radius_12`) hoặc `var(--ds-*)`. Không dùng màu Tailwind hay mã hex viết tay: chúng không đổi theo theme.
- Hover và nhấn trộn từ token nền đang dùng: `hover:state_bg_button_primary_soft active:state_bg_button_primary_medium`. Viết `hover:bg_*` không có tác dụng.

Mỗi link dưới đây là bản Markdown của một trang. Trang component có code ví dụ và bảng props.

## Docs: Getting Started

- [Introduction](./docs.md): Core DS là thư viện React dùng chung của team, gồm component, icon và editor.
- [Installation](./docs/installation.md): Thêm registry của Core DS vào app, cài gói, import CSS và provider.

## Docs: Foundations

- [Colors](./docs/foundations/colors.md): Token màu chức năng, bảng màu mở rộng, đổ bóng và sáu theme dựng sẵn của Core DS, cùng cách đổi theme trong app.
- [Design Tokens](./docs/foundations/design-tokens.md): Giá trị của mọi token màu ở cả bảy theme, kèm màn thử đổi màu ngay trên component thật.
- [Typography](./docs/foundations/typography.md): Thang chữ Headline và Body của Core DS trên font Inter, cùng cách chọn class theo vai trò của chữ.
- [Spacing & Radius](./docs/foundations/spacing-radius.md): Thang bo góc, bo góc theo cỡ control, khoảng cách giữa các khối và padding bên trong component của Core DS.
- [Hệ số X](./docs/foundations/x-factor.md): Một biến CSS chung (--ds-x) làm component thoáng hơn và bo tròn hơn mà không đổi prop size. Đặt cho cả theme hoặc từng khu vực.
- [States](./docs/foundations/states.md): Màu hover và nhấn được trộn từ chính màu nền của component theo bốn mức cố định, và tự đổi chiều theo theme.
- [Menu](./docs/foundations/menu.md): Bề mặt, khoảng cách và màu hover, nhấn dùng chung cho menu của Select và DropdownMenu.
- [Empty States](./docs/foundations/empty-states.md): Năm hình minh hoạ cho danh sách trống, thiếu dữ liệu và không có quyền xem, kèm cách ghép với tiêu đề, mô tả và nút hành động.

## Docs: AI

- [LLMs.txt](./docs/ai/llms-txt.md): Docs Core DS dạng Markdown cho AI assistant đọc, gồm llms.txt, llms-full.txt và bản Markdown của từng trang.
- [Agent Skills](./docs/ai/agent-skills.md): Skill coreds cho AI agent biết component, token và quy tắc của Core DS, khớp với version đang cài trong app.
- [AGENTS.md](./docs/ai/agents-md.md): Đoạn quy tắc Core DS để dán vào AGENTS.md hoặc CLAUDE.md của app, để agent nhớ cả khi chưa mở skill.

## Components: Overview

- [All components](./components.md): 40 component dựng trên Radix và Tailwind, dùng chung token màu, chữ và khoảng cách. Mỗi trang có ví dụ chạy được và bảng props.

## Components: General

- [Avatar](./components/avatar.md): Ảnh đại diện của người dùng hoặc nhóm, nhiều kích thước và hình dạng.
- [Badge](./components/badge.md): Nhãn nhỏ cho trạng thái, phân loại hoặc số đếm. NotiBadge là chấm hoặc số thông báo gắn lên phần tử khác.
- [Button](./components/button.md): Nút bấm cho hành động chính, phụ và nguy hiểm, có trạng thái đang tải. Kèm DropdownButton và SplitDropdownButton cho nút mở menu.
- [Chip](./components/chip.md): Thẻ nhỏ để lọc, chuyển tab, hiển thị thông tin hoặc nhập nhiều giá trị.
- [IconToggle](./components/icon-toggle.md): Nút icon có trạng thái bật/tắt, dùng cho thanh công cụ và hành động nhanh.
- [Spinner](./components/spinner.md): Vòng quay báo đang xử lý.

## Components: Forms

- [Checkbox](./components/checkbox.md): Ô đánh dấu cho lựa chọn bật/tắt hoặc chọn nhiều mục.
- [Field](./components/field.md): Bọc một ô nhập với nhãn, mô tả và thông báo lỗi.
- [FileUpload](./components/file-upload.md): Vùng kéo-thả hoặc bấm để chọn file, kèm danh sách file đã chọn.
- [Input](./components/input.md): Ô nhập văn bản một dòng. NumberInput dành cho số, có định dạng hàng nghìn.
- [InputPinCode](./components/input-pin-code.md): Ô nhập mã PIN hoặc OTP theo từng ký tự.
- [RadioGroup](./components/radio-group.md): Nhóm lựa chọn chỉ chọn được một.
- [SegmentedControl](./components/segmented-control.md): Nhóm nút liền nhau để chuyển giữa vài lựa chọn ngang hàng.
- [Select](./components/select.md): Ô chọn một hoặc nhiều giá trị từ danh sách.
- [Slider](./components/slider.md): Thanh trượt chọn một giá trị hoặc một khoảng.
- [Switch](./components/switch.md): Công tắc bật/tắt, có hiệu lực ngay khi gạt.
- [Textarea](./components/textarea.md): Ô nhập văn bản nhiều dòng.

## Components: Date & Time

- [Calendar](./components/calendar.md): Lịch chọn ngày hoặc khoảng ngày, có thể đánh dấu những ngày đặc biệt.
- [DatePicker](./components/date-picker.md): Ô chọn ngày, mở lịch trong popover.
- [DateRangePicker](./components/date-range-picker.md): Ô chọn khoảng ngày từ – đến.

## Components: Overlays

- [Drawer](./components/drawer.md): Bảng trượt ra từ cạnh màn hình cho nội dung phụ hoặc biểu mẫu.
- [DropdownMenu](./components/dropdown-menu.md): Menu thả xuống cho các hành động, có menu con, mục checkbox, radio và phím tắt.
- [Modal](./components/modal.md): Hộp thoại giữa màn hình, chặn tương tác với phần còn lại cho đến khi đóng.
- [Popover](./components/popover.md): Khung nổi gắn với một phần tử, chứa nội dung tương tác nhỏ.
- [Tooltip](./components/tooltip.md): Chú thích ngắn hiện khi rê chuột hoặc focus vào phần tử. Cần `TooltipProvider` ở gốc app.

## Components: Layout

- [Accordion](./components/accordion.md): Các mục thu gọn và mở rộng, để chứa nội dung dài trong không gian hẹp.
- [Card](./components/card.md): Khung gom một nhóm nội dung liên quan: tiêu đề, mô tả, nội dung và chân.
- [ScrollArea](./components/scroll-area.md): Vùng cuộn với thanh cuộn theo style của design system.
- [Tabs](./components/tabs.md): Chia nội dung thành các tab ngang hàng.

## Components: Navigation

- [Breadcrumb](./components/breadcrumb.md): Đường dẫn cho biết trang hiện tại nằm ở đâu trong cấu trúc.
- [Pagination](./components/pagination.md): Chuyển trang cho danh sách hoặc bảng dài.
- [Sidebar](./components/sidebar.md): Thanh điều hướng bên của app: nhóm mục, mục con, thu gọn và bố cục trang đi kèm.
- [SimpleSidebar](./components/simple-sidebar.md): Sidebar gọn, dựng từ một mảng dữ liệu thay vì ghép từng phần.
- [Steps](./components/steps.md): Các bước của một quy trình và bước đang làm.

## Components: Feedback

- [Alert](./components/alert.md): Thông báo nổi bật trong trang: thông tin, thành công, cảnh báo hoặc lỗi.
- [Progress](./components/progress.md): Thanh tiến trình khi biết hoặc chưa biết thời gian còn lại.
- [Skeleton](./components/skeleton.md): Khối giữ chỗ trong lúc nội dung đang tải.
- [Toast](./components/toast.md): Thông báo ngắn hiện ở góc màn hình, gọi bằng hàm `toast()`. Cần `Toaster` ở gốc app.

## Components: Data Display

- [DataTable](./components/table.md): Bảng dữ liệu có sắp xếp, lọc, chọn hàng, mở rộng hàng và phân trang.
- [VirtualList](./components/virtual-list.md): Danh sách rất dài nhưng chỉ render phần đang nhìn thấy.

## Components: Patterns

- [App header](./components/app-header.md): Hàng tiêu đề trên nội dung của app, ghép từ Breadcrumb, Select, Input, Button và Tabs. Là cách ghép component để tham khảo, không phải component xuất từ thư viện.

## Icons: Getting Started

- [Introduction](./icons.md): Hai bộ icon Phosphor và Iconsax dạng component React, mỗi cỡ mang sẵn độ dày nét theo thiết kế.

## Icons: Icon sets

- [Phosphor](./icons/phosphor.md): 1.512 icon Phosphor nét chỉnh được, ba kiểu line, duotone và fill. Tìm theo tên, bấm vào icon để chép dòng import.
- [Iconsax](./icons/iconsax.md): 993 icon Iconsax (Vuesax) với ba kiểu linear, bold và bulk, kèm bảng đổi tên layer Figma sang component. Tìm theo tên, bấm vào icon để chép dòng import.

## Editor: Getting Started

- [Introduction](./editor.md): @coreds/tiptap là bộ editor Tiptap v3 dựng trên @coreds/ui, có 4 template dùng ngay.
- [Installation](./editor/installation.md): Cài @coreds/tiptap, import stylesheet, rồi thêm template vào app bằng CLI.

## Editor: Templates

- [Simple](./editor/simple.md): Editor có thanh công cụ cố định phía trên, cho nội dung cơ bản.
- [Notion-like](./editor/notion-like.md): Editor dạng khối như Notion: menu lệnh /, kéo-thả khối, bảng, nhắc tên, emoji và thanh định dạng nổi.
- [Chat box](./editor/chat-box.md): Ô soạn tin nhắn gọn: Enter để gửi, emoji, nhắc tên và đính ảnh.
- [Rich text box](./editor/rich-text-box.md): Ô soạn thảo nhỏ gọn có thanh công cụ gắn liền, dùng trong form; có biến thể kèm nút Gửi.

