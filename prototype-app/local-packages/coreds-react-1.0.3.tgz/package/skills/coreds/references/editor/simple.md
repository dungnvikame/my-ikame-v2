# Simple

> Editor có thanh công cụ cố định phía trên, cho nội dung cơ bản.

## Features

- Thanh công cụ cố định: heading, danh sách, trích dẫn, khối code.
- Định dạng chữ: đậm, nghiêng, gạch, gạch chân, tô sáng, link, chỉ số trên/dưới.
- Căn lề trái, giữa, phải, đều.
- Chèn ảnh.
- Dùng được trên màn hình điện thoại.

## Usage

```bash
npx @coreds/tiptap add simple
```

```tsx
import { SimpleEditor } from "@coreds/tiptap/components/tiptap-templates/simple/simple-editor"

export function Editor() {
  return <SimpleEditor onUpdate={(json) => console.log(json)} />
}
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `initialContent` | `Content` | — |
| `onUpdate` | `((json: JSONContent) => void)` | — |
| `onEditorReady` | `((editor: Editor) => void)` | — |
| `onError` | `((error: Error, feature: string) => void)` | — |
| `uploadFn` | `UploadFunction` | — |
| `readOnly` | `boolean` | — |
| `placeholder` | `string` | — |
| `extensionOverrides` | `Extensions` | — |
