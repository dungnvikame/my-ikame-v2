# Chat box

> Ô soạn tin nhắn gọn: Enter để gửi, emoji, nhắc tên và đính ảnh.

## Features

- Enter để gửi, Shift+Enter để xuống dòng.
- Ba kiểu hiển thị qua `variant`: `collapsible` (mặc định, viên thuốc mở ra khi focus), `expanded` (luôn mở), `compact` (luôn là viên thuốc, chỉ cao thêm theo nội dung).
- Emoji, nhắc tên, đính ảnh; thanh công cụ định dạng tuỳ chọn.

## Usage

```bash
npx @coreds/tiptap add chat-box
```

```tsx
import { ChatBoxEditor } from "@coreds/tiptap/components/tiptap-templates/chat-box/chat-box-editor"

export function Composer() {
  return (
    <ChatBoxEditor
      emoji
      mention
      imageUpload
      placeholder="Nhập tin nhắn…"
      onSend={({ text, images }) => sendMessage(text, images)}
    />
  )
}
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `onSend` | `((content: { json: JSONContent; html: string; text: string; images: File[]; }) => void)` | — |  |
| `toolbar` | `boolean` | — |  |
| `emoji` | `boolean` | — |  |
| `imageUpload` | `boolean` | — |  |
| `mention` | `boolean` | — |  |
| `variant` | `"collapsible" \| "compact" \| "expanded"` | `"collapsible"` | How the composer sits at rest. - `collapsible` — a pill that unfolds into the full composer on focus - `expanded` — open from the start, with the action row on its own line - `compact` — the pill, permanently: the actions stay inside it and it never unfolds, growing only as far as the content needs |
| `initialContent` | `Content` | — |  |
| `onUpdate` | `((json: JSONContent) => void)` | — |  |
| `onEditorReady` | `((editor: Editor) => void)` | — |  |
| `onError` | `((error: Error, feature: string) => void)` | — |  |
| `uploadFn` | `UploadFunction` | — |  |
| `readOnly` | `boolean` | — |  |
| `placeholder` | `string` | — |  |
| `extensionOverrides` | `Extensions` | — |  |
