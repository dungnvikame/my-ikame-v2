# Notion-like

> Editor dạng khối như Notion: menu lệnh /, kéo-thả khối, bảng, nhắc tên, emoji và thanh định dạng nổi.

## Features

- Gõ `/` để mở menu lệnh, rê chuột vào lề trái để kéo-thả hoặc mở menu của khối.
- Bôi đen chữ để hiện thanh định dạng nổi; đổi kiểu khối bằng "Turn into".
- Bảng có tay cầm hàng/cột, chèn, xoá, gộp ô, đổi kích thước.
- Nhắc tên bằng `@`, chèn emoji bằng `:`.
- Dán thông minh: làm sạch HTML, dán ảnh và tự tải lên qua `uploadFn`.
- Sơ đồ diagrams.net, Mermaid, biểu đồ, callout, nhúng, chia cột, file.
- Tìm và thay thế, mục lục nổi, thanh công cụ cảm ứng, chế độ chỉ đọc.
- Cộng tác thời gian thực bằng Yjs (tuỳ chọn).

## Usage

```bash
npx @coreds/tiptap add notion-like
```

```tsx
import { NotionEditor } from "@/tiptap/notion-like-editor"

export function DocumentEditor() {
  return (
    <NotionEditor
      initialContent={{ type: "doc", content: [{ type: "paragraph" }] }}
      uploadFn={uploadFile}
      onUpdate={saveDocument}
    />
  )
}
```

## Feature flags

`features` nhận từng cờ dưới đây, mặc định tất cả đều bật. Cờ khai báo trong `features` thắng các prop cũ đã ngừng dùng (`showHeader`, `includeAiFeatures`…).

```tsx
<NotionEditor features={{ ai: false, floatingToc: false }} />
```

| Prop | Type | Default |
| --- | --- | --- |
| `ai` (required) | `boolean` | — |
| `cleanPaste` (required) | `boolean` | — |
| `collaboration` (required) | `boolean` | — |
| `diagramsNet` (required) | `boolean` | — |
| `dragAutoScroll` (required) | `boolean` | — |
| `findReplace` (required) | `boolean` | — |
| `floatingToc` (required) | `boolean` | — |
| `header` (required) | `boolean` | — |
| `mentions` (required) | `boolean` | — |
| `outlineTable` (required) | `boolean` | — |
| `pasteImages` (required) | `boolean` | — |
| `smartPaste` (required) | `boolean` | — |
| `tableOfContents` (required) | `boolean` | — |

## Collaboration

```tsx
<NotionEditor
  initialContent={initialDocument}
  collaboration={{
    document: ydoc,
    provider: websocketProvider,
    user: { name: currentUser.name, color: currentUser.color },
  }}
/>
```

Nội dung ban đầu chỉ được đưa vào tài liệu Yjs khi tài liệu chung còn trống, kể cả sau khi provider báo `synced`.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `room` | `string` | — | Legacy document identifier. Kept for compatibility; networking is adapter-driven. |
| `content` (deprecated) | `Content` | — |  |
| `onDocumentUpdate` (deprecated) | `((json: JSONContent) => void)` | — |  |
| `collaboration` | `NotionCollaborationConfig` | — |  |
| `showHeader` (deprecated) | `boolean` | — |  |
| `showFloatingToc` (deprecated) | `boolean` | — |  |
| `includeAiFeatures` (deprecated) | `boolean` | — |  |
| `includeMentionFeatures` (deprecated) | `boolean` | — |  |
| `features` | `Partial<NotionEditorFeatures>` | — | Explicit keys override their deprecated shorthand prop equivalents. |
| `slashMenuConfig` | `SlashMenuConfig` | — |  |
| `initializingFallback` | `ReactNode` | — |  |
| `initialContent` | `Content` | — |  |
| `onUpdate` | `((json: JSONContent) => void)` | — |  |
| `onEditorReady` | `((editor: Editor) => void)` | — |  |
| `onError` | `((error: Error, feature: string) => void)` | — |  |
| `uploadFn` | `UploadFunction` | — |  |
| `readOnly` | `boolean` | — |  |
| `placeholder` | `string` | — |  |
| `extensionOverrides` | `Extensions` | — |  |
