# Installation

> Cài @coreds/tiptap, import stylesheet, rồi thêm template vào app bằng CLI.

### Trỏ scope `@coreds` về registry

Editor dùng chung registry với các gói khác. App đã có dòng này trong `.npmrc` thì bỏ qua bước này; chưa có thì xem [Installation](../docs/installation.md).

```ini title=".npmrc"
@coreds:registry=https://gitlab.ikameglobal.com/api/v4/projects/2163/packages/npm/
```

### Cài gói

App chưa dùng Core DS:

```bash tab="npm"
npm install @coreds/tiptap @coreds/ui @coreds/icons
```

```bash tab="pnpm"
pnpm add @coreds/tiptap @coreds/ui @coreds/icons
```

```bash tab="yarn"
yarn add @coreds/tiptap @coreds/ui @coreds/icons
```

App đã dùng `@coreds/react`: gói này ghim `@coreds/ui` và `@coreds/icons` đúng version của nó. Cài hai gói đó ở version khác thì app có hai bản của mỗi gói, nặng gấp đôi và CSS nạp hai lần. Xem version rồi cài cùng số:

```bash
npm ls @coreds/react
npm install @coreds/tiptap @coreds/ui@0.3.2 @coreds/icons@0.3.2
```

Thay `0.3.2` bằng version `npm ls` in ra. Bỏ qua bước này cũng được: lệnh `add` ở bước cuối tự cài `@coreds/ui` và `@coreds/icons` đúng version của `@coreds/react`, và cảnh báo nếu app đang có bản lệch.

### Import stylesheet

Ở file vào của app. Stylesheet của design system đứng trước:

```tsx
import "@coreds/ui/style.css"
import "@coreds/tiptap/styles.css"
```

App dùng `@coreds/react` thì giữ `import "@coreds/react/style.css"` đang có thay cho dòng đầu. Hai file có cùng nội dung, import cả hai là nạp CSS hai lần.

### Bọc app bằng provider

Editor dùng `Tooltip` và `toast`, nên gốc app cần `TooltipProvider` và `Toaster`. App dùng `@coreds/react` thì import từ `@coreds/react`, cùng một component:

```tsx
import { Toaster, TooltipProvider } from "@coreds/ui"

export function App({ children }: { children: React.ReactNode }) {
  return (
    <TooltipProvider>
      {children}
      <Toaster />
    </TooltipProvider>
  )
}
```

### Thêm template

```bash
npx @coreds/tiptap add notion-like
```

Lệnh này tạo trong app một file bọc mỏng quanh template. Phần thân template nằm trong gói, nên nâng cấp `@coreds/tiptap` là nhận bản sửa lỗi; đừng chép code template vào app. `npx @coreds/tiptap list` liệt kê các template có sẵn.

## Versions

Các gói `@tiptap/*` được ghim đúng `3.14.0`. Nâng Tiptap cùng lúc với `@coreds/tiptap`, đừng trộn bản Tiptap khác trong cùng app. Hỗ trợ React 18 và 19.

`@coreds/tiptap` nhận mọi bản cùng major của `@coreds/ui` và `@coreds/icons` (vd. mọi bản `1.x`), nên nâng design system lên bản minor, patch không bắt nâng editor. Editor và `@coreds/ui` dùng chung một bản `radix-ui` (`^1.6.2`); app cài thêm `radix-ui` thì giữ trong khoảng này để không có hai bản Radix.
