# Rich text box

> Ô soạn thảo nhỏ gọn có thanh công cụ gắn liền, dùng trong form; có biến thể kèm nút Gửi.

## Features

- Thanh công cụ gắn liền ô soạn: heading, danh sách, định dạng chữ, căn lề.
- Chèn ảnh và bảng.
- Giới hạn chiều cao bằng `minHeight` / `maxHeight`, phần dư cuộn bên trong.
- Biến thể `composer` có nút Gửi: `onSend` nhận JSON, HTML và chữ thuần; khi ảnh đang tải, lần gửi đi vào `onSendBlocked`.

## Usage

```bash
npx @coreds/tiptap add rich-text-box
```

```tsx
import { RichTextBox } from "@coreds/tiptap/components/tiptap-templates/rich-text-box/rich-text-box-editor"

export function Description() {
  return <RichTextBox placeholder="Mô tả công việc…" minHeight={240} maxHeight={320} />
}
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `content` (deprecated) | `Content` | — |  |
| `onSend` | `((payload: RichTextBoxSubmitPayload) => unknown)` | — | Called when the user sends (Send button or Ctrl/Cmd+Enter). Return `false` to keep the content: the kit does not clear, and the content, selection and any running upload NodeViews are left untouched (the caller owns clearing, e.g. after a successful save via `payload.editor.commands.clearContent(true)`). Any other return value — `undefined`, `true`, a Promise (not awaited) — clears the editor exactly as in 0.12.0. Typed `unknown` rather than `void \| boolean` so callbacks that 0.12.0 accepted, such as `(payload) => mutation.mutateAsync(payload)`, still typecheck. Not called while uploads are in flight — those attempts go to `onSendBlocked` instead. |
| `onSendBlocked` | `((reason: RichTextBoxSendBlockedReason) => void)` | — | Called when a send is attempted (Ctrl/Cmd+Enter or a programmatic send path) while blocked — currently only while an upload is in flight (`reason === "uploading"`). The Send button is disabled while uploading so pointer clicks never reach it; `onSend` is not called and the content is kept. |
| `variant` | `"composer" \| "field"` | — |  |
| `minHeight` | `string \| number` | — |  |
| `maxHeight` | `string \| number` | — | Caps how tall the box grows. Past this the content area scrolls and the toolbar stays in place. Left unset, the box keeps growing with its content. |
| `className` | `string` | — |  |
| `editorClassName` | `string` | — |  |
| `sendOnModEnter` | `boolean` | — |  |
| `tableControls` | `boolean \| RichTextBoxTableControlsConfig` | — |  |
| `initialContent` | `Content` | — |  |
| `onUpdate` | `((json: JSONContent) => void)` | — |  |
| `onEditorReady` | `((editor: Editor) => void)` | — |  |
| `onError` | `((error: Error, feature: string) => void)` | — |  |
| `uploadFn` | `UploadFunction` | — |  |
| `readOnly` | `boolean` | — |  |
| `placeholder` | `string` | — |  |
| `extensionOverrides` | `Extensions` | — |  |
