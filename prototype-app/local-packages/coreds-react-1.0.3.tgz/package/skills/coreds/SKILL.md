---
name: coreds
description: Build React UI with Core DS, the team's shared design system (@coreds/react, @coreds/ui, @coreds/icons, @coreds/tiptap). Use when a project depends on @coreds/* or the user asks to build screens, forms, tables or editors "bằng Core DS" / "dùng Core DS": choosing components and props, design tokens (bg_primary, text_secondary, radius_12, body_s…), themes and dark mode, icons, and the Tiptap editor templates.
---

# Core DS

Core DS là design system React của team: 40 component dựng trên Radix và Tailwind, icon Phosphor và Iconsax, editor Tiptap, sáu theme. Tài liệu đầy đủ nằm trong `references/`, là bản Markdown của trang docs, có code ví dụ và bảng props sinh từ type. Bản online ở https://ui.ikameglobal.com (mục lục cho AI: https://ui.ikameglobal.com/llms.txt).

## Tra cứu

Đọc tài liệu của component trước khi dùng nó lần đầu; đừng đoán prop.

Skill này đi kèm gói `@coreds/react` (cài bằng `npx @coreds/react skill`). App đã nâng `@coreds/react` mà skill chưa cài lại thì bản khớp version nằm ở `node_modules/@coreds/react/skills/coreds/`.

- Mục lục mọi trang: `references/index.md`.
- Component: `references/components/<id>.md`, id viết kebab-case (`button`, `date-picker`, `dropdown-menu`). Danh sách theo nhóm: `references/components.md`.
- Token và quy tắc style: `references/docs/foundations/` (`colors.md`, `design-tokens.md`, `typography.md`, `spacing-radius.md`, `x-factor.md`, `states.md`, `menu.md`, `empty-states.md`).
- Icon: cách dùng ở `references/icons.md`, tên mọi icon ở `references/icons/phosphor.md` và `references/icons/iconsax.md`.
- Editor: `references/editor/installation.md` và một file cho mỗi template (`simple`, `notion-like`, `chat-box`, `rich-text-box`).
- Tìm nhanh bằng grep, ví dụ prop của một component: `grep -n "^| \`" references/components/select.md`; tên icon: `grep -o "[A-Za-z]*Calendar[A-Za-z]*Icon" references/icons/phosphor.md`.

## Setup trong app

Bỏ qua bước nào app đã có.

1. `.npmrc` ở gốc app (không chứa bí mật, commit cùng code):
   ```ini
   @coreds:registry=https://gitlab.ikameglobal.com/api/v4/projects/2163/packages/npm/
   ```
2. `npm install @coreds/react` (cần React 18 hoặc 19).
3. Import CSS một lần ở file vào của app: `import "@coreds/react/style.css"`.
4. Bọc app bằng `TooltipProvider` và đặt `<Toaster />` (cần cho `Tooltip` và `toast()`), cả hai import từ `@coreds/react`.

Chi tiết: `references/docs/installation.md`.

## Quy tắc khi viết UI

- **Import:** component, hook (`useTheme`, `useDarkMode`), `toast` và `cn` từ `@coreds/react`. Icon từ `@coreds/react/icons` (Phosphor) hoặc `@coreds/react/icons/iconsax`; tên có hậu tố `Icon` (`PlusIcon`, `CaretDownIcon`).
- **Dùng component có sẵn:** Button, Input, Select, Modal, Drawer, Popover, Tooltip, Toast, Table, Tabs, DatePicker… Không dựng lại bằng `div` và class Tailwind.
- **Màu, viền, bóng:** chỉ dùng class token (`bg_primary`, `bg_secondary`, `text_primary`, `text_secondary`, `fg_accent_primary`, `border_secondary`, `shadow_m`) hoặc `var(--ds-*)`. Không dùng màu Tailwind (`bg-white`, `text-gray-900`) hay mã hex: chúng không đổi theo theme.
- **Chọn token theo vai trò, không theo màu đang thấy.** Chữ trên nền màu dùng `fg_on_*` tương ứng, không gán cứng màu trắng.
- **Chữ:** `headline_xl` → `headline_xs` cho tiêu đề, `body_xl` → `body_xxs` cho nội dung, thêm `font_semibold` để đậm vừa.
- **Hover và nhấn:** trộn từ đúng token nền đang dùng, ví dụ `bg_button_primary hover:state_bg_button_primary_soft active:state_bg_button_primary_medium`. Viết `hover:bg_*` không có tác dụng.
- **Bo góc:** `radius_2`, `radius_4`, `radius_6`, `radius_8`, `radius_12`, `radius_16`, `radius_24`, `radius_round`. Lớp ngoài tròn hơn lớp trong.
- **Ghi đè:** muốn ghi đè bo góc hoặc bóng có sẵn của component thì thêm `!` vào class (`rounded-none!`).
- **Khoảng cách:** thang Tailwind, bội số 4px (`gap-2`, `p-4`). Tránh giá trị lẻ như `px-[13px]`.
- **Kích cỡ control:** chọn bằng prop `size` (`xs | s | m | l | xl` cho Button, Input, Select…). Chiều cao, padding, bo góc đi theo `size`; không chỉnh lại bằng `h-*`, `px-*`.
- **Icon:** `size` là `xs | s | m | l` (12/16/20/24px), mỗi cỡ có sẵn độ dày nét. Màu dùng `icon_primary`, `icon_secondary`, `icon_tertiary` hoặc `fg_success`, `fg_warning`, `fg_error`, `fg_info`.
- **Theme:** `light` (mặc định), `high-contrast-light`, `olive`, `dark`, `deep-forest`, `sunset`. Đổi bằng `useTheme()` (`setTheme`, `themes`); chỉ cần sáng/tối thì dùng `useDarkMode()`. Không dùng cả hai hook cùng lúc.
- **Hệ số X:** muốn một vùng thoáng và bo tròn hơn thì đặt `--ds-x` (vd. `1.2`) trên phần tử bọc, không chỉnh `h-*`, `px-*` của từng control. Theme `creative-studio` (riêng phòng Creative, bật bằng `useTheme({ availableThemes: [creativeStudioTheme] })`) đã đặt sẵn `--ds-x: 1.125`.

## Editor

Cài `@coreds/tiptap` kèm `@coreds/ui` và `@coreds/icons`, import `@coreds/ui/style.css` trước `@coreds/tiptap/styles.css`. App đã dùng `@coreds/react` thì `@coreds/ui`, `@coreds/icons` phải đúng version của `@coreds/react` (lệch là app có hai bản), và giữ `@coreds/react/style.css` thay cho `@coreds/ui/style.css`. Thêm template bằng CLI (CLI tự cài ui, icons đúng version đó), rồi import từ file nó tạo:

```bash
npx @coreds/tiptap add notion-like
```

Không chép code template vào app: phần thân nằm trong gói để nâng cấp nhận được bản sửa lỗi. Prop và feature flag của từng template: `references/editor/<template>.md`.

## Trước khi báo xong

- Không còn màu Tailwind, mã hex hay `rounded-*`/`h-*` ghi đè lên control của Core DS.
- Mở thử ở theme `dark`: chữ, viền, nền vẫn đọc được.
- Icon có `aria-label` khi đứng một mình trong nút (`<Button size="icon-s" aria-label="Xoá">`).
