# @coreds/icons

Two icon sets as tree-shakeable React components, both with **pixel-precise stroke width as a
prop**: **1,512 Phosphor glyphs** in line, duotone and fill, and **993 Vuesax/Iconsax glyphs** in
linear, bold and bulk. Sits alongside `@coreds/ui` as its own package, shares its version, and is
also re-exported by `@coreds/react` as `@coreds/react/icons`.

The two sets share glyph names (`WalletIcon`, `HomeIcon`, `SettingIcon`…), so they never share a
namespace — Phosphor is the package root, Vuesax is the `/iconsax` subpath:

```tsx
import { WalletIcon } from "@coreds/icons"          // Phosphor
import { WalletIcon as VsWallet } from "@coreds/icons/iconsax"  // Vuesax
```

## Why this exists

`ui-kit` drew its glyphs from `@phosphor-icons/react`. That package renders each glyph as a
**filled path**, so its six weights are six separate drawings and `stroke-width` has nothing to
act on — you get four thicknesses, take them or leave them.

Phosphor also publishes the same artwork as **stroke-drawn SVG**. This package generates from the
line and duotone SVG sources and keeps the strokes editable, so a size can carry the exact stroke
width the design specifies, and that thickness stays put however the icon is scaled:

```tsx
import { CaretDownIcon } from "@coreds/icons"

<CaretDownIcon size="s" />                                    // 16px box, 1.25px stroke
<CaretDownIcon size="l" />                                    // 24px box, 1.5px stroke
<CaretDownIcon className="h-8 w-8" strokeWidth={1} />         // exactly 1px, whatever the box
<CaretDownIcon size="l" variant="duotone" />                  // 1.5px + 20% fill
<CaretDownIcon size="m" variant="fill" />                     // solid, no stroke
```

Fill is the one variant that cannot come from a stroke width — it is separate solid artwork, so it
ships as its own drawing and ignores `strokeWidth`.

## Install

No token is needed. Point the `@coreds` scope at the GitLab registry once per app, in the `.npmrc`
at the app root (commit it — it holds no secret), then install:

```ini
@coreds:registry=https://gitlab.ikameglobal.com/api/v4/projects/2163/packages/npm/
```

```
npm install @coreds/icons
```

## Importing from CommonJS

The package ships ESM only, but both entry points also answer to `require()`:

```js
const { CaretDownIcon } = require("@coreds/icons")
const { WalletIcon } = require("@coreds/icons/iconsax")
```

There is no second CJS build — the `require` condition points at the same ESM files, and Node
loads them directly. That works from **Node 20.19 / 22.12** onward; on older Node a `require()`
of this package throws `ERR_REQUIRE_ESM`. Bundlers and browser code are unaffected: they take the
`import` condition as before.

Worth knowing: a tool that reads the `require` condition and then parses the file as CJS itself —
rather than handing it to Node — will still choke on the ESM syntax. Jest without ESM support is
the usual example.

## Upgrading from 0.2.0

`weight` is now `strokeWidth`, and `size` accepts a named size. This is the breaking part of 0.3.0:

```diff
-<BellIcon size={24} weight={1.5} />
+<BellIcon size="l" />
```

Pass `strokeWidth` only where a size's own stroke is wrong for the case.

## Props

Both sets take the same three props and share one size scale; only the `variant` union differs.

**Sizes** — `SIZES`, exported from both entry points

| Name | Box | Stroke |
|---|---|---|
| `xs` | 12px | 0.9 |
| `s` | 16px | 1.25 |
| `m` | 20px | 1.25 |
| `l` | 24px | 1.5 |

Stroke is a function of size, not a second axis to tune: pick a size and the right thickness comes
with it. For the Vuesax set, `l` is exactly what Iconsax draws natively.

**Phosphor** — `@coreds/icons`

| Prop | Type | Default | Notes |
|---|---|---|---|
| `size` | `SizeName \| number \| string` | `"1em"` | `xs` \| `s` \| `m` \| `l`, or any number/string passed to width/height. A Tailwind `h-4 w-4` overrides it. |
| `strokeWidth` | `number` | from `size` | Escape hatch, in CSS pixels, for the rare case that must deviate. Ignored by `variant="fill"`. |
| `variant` | `"line" \| "duotone" \| "fill"` | `"line"` | Duotone adds a secondary 20%-opacity fill behind the same line; fill is solid artwork with no stroke. |
| …rest | `SVGProps<SVGSVGElement>` | — | `className`, `aria-hidden`, `onClick`, ref, etc. |

**Vuesax** — `@coreds/icons/iconsax`

| Prop | Type | Default | Notes |
|---|---|---|---|
| `size` | `SizeName \| number \| string` | `"1em"` | Same as above. |
| `strokeWidth` | `number` | from `size` | Same as above. Ignored by `bold` and `bulk`. |
| `variant` | `"linear" \| "bold" \| "bulk"` | `"linear"` | `linear` is stroke-drawn; `bold` and `bulk` are solid. |
| …rest | `SVGProps<SVGSVGElement>` | — | Same as above. |

When the box comes from CSS rather than the `size` prop, there is no size-specific stroke to apply,
so the stroke falls back to `s` (1.25).

Colour comes from `currentColor`, so pair an icon with a ui-kit token class
(`icon_primary` / `icon_secondary` / `icon_tertiary`) rather than a colour prop.

`vector-effect="non-scaling-stroke"` keeps that visible thickness stable at every rendered size.

## Migrating from @phosphor-icons/react

Names match Phosphor's own, plus the `Icon` suffix it adopted in v2.1:

```diff
-import { CaretDown, Check } from "@phosphor-icons/react"
+import { CaretDownIcon, CheckIcon } from "@coreds/icons"
```

Two differences to know about:

* **Duotone and fill are variants, not weights.** Use `variant="duotone"` / `variant="fill"`
  instead of `weight="duotone"` / `weight="fill"`. Duotone's line still responds to the size's
  stroke; fill has no line to respond with.
* **The heavier weights are interpolated, not hand-drawn.** Phosphor redraws fine details at bold
  for 434 of the 1,512 glyphs; here, bold is the regular geometry with a thicker stroke. For the
  other 1,077 the output is identical to Phosphor's.

## The Vuesax set and the Figma file

The design source is the Core DS 1.1 Figma page **“Icon source: Vuesax”** (`8167:1058`), which
holds 888 glyphs in five styles; this package ships three of them — `broken` and `twotone` are
deliberately left out. The artwork here does **not** come from that page — it
is rendered from `iconsax-react@0.0.8`, which keeps Iconsax's original v1 names, typos and all
(`play-cricle`, `mini-music-sqaure`, `buliding`). Two consequences worth knowing:

* **Coverage is 864 of 888 Figma names.** 800 match a component name directly, 64 need an alias
  (mostly crypto glyphs, where Figma writes `bitcoin-(btc)` and upstream writes `Bitcoin`), and
  **24 are unresolved** — see `scripts/data/figma-coverage.json` for the list. They were left
  unmapped on purpose: guessing which upstream glyph a Figma name means would silently put the
  wrong drawing behind the right name.
* **The paths are optimised, not identical.** Same shapes, different path data. If a designer has
  edited a glyph inside the Figma file, that edit is not here.

`ICONSAX_FIGMA_ALIASES` maps a Figma layer name to its component name, so a spec that says
`vuesax/linear/bitcoin-(btc)` can be resolved without a human in the loop:

```tsx
import { ICONSAX_FIGMA_ALIASES } from "@coreds/icons/iconsax"

ICONSAX_FIGMA_ALIASES["bitcoin-(btc)"] // "BitcoinIcon"
```

The set also carries 105 glyphs the Figma page does not have — upstream ships 993 in total.

## Regenerating

`npm run icons` runs both generators. `npm run icons:phosphor` reads `svg/*.svg`,
`svg-duotone/*.svg` and `svg-fill/*.svg`, then writes
`src/icons/*.tsx`. It turns each `stroke-width` into a non-scaling CSS-pixel value and every
literal colour into `currentColor`. Seven glyphs (`DotIcon`, `NumpadIcon` and five `DotsX`
siblings) are pure filled dots with no stroke — `strokeWidth` does nothing there either.

The `svg/` and `svg-duotone/` directories are Phosphor's stroke-drawn line and duotone exports;
`svg-fill/` is `@phosphor-icons/core@2.1.1`'s `assets/fill`. All MIT licensed — see
`LICENSE-phosphor`.

`npm run icons:iconsax` does the same for `svg-iconsax/{linear,bold,bulk}/*.svg`,
writing `src/icons-iconsax/*.tsx`, `src/iconsax-aliases.ts` and the coverage report. Both
generators share the SVG-to-JSX transform in `scripts/lib/svg-to-jsx.mjs`.

`svg-iconsax/` was rendered from `iconsax-react@0.0.8` (MIT), one flat SVG per style.

Every variant of a glyph lives in that glyph's one component file, so an icon carries artwork it
may never draw. Measured over the built output:

| Set | Variants | Avg raw | Avg gzipped |
|---|---|---|---|
| Phosphor | 3 | 3,179 B | 831 B |
| Vuesax | 3 | 2,735 B | 1,008 B |

For Phosphor that is +467 B raw / +182 B gzipped per icon versus the line-and-duotone build it
replaced. Tree-shaking is still per-icon: importing 40 icons pulls 40 files, not 2,505.

`_parked-brand/` holds 51 iKame-specific SVGs (logos, mascots, reactions, empty states) from an
earlier pass. They are not part of this package's build; they need a home of their own.
